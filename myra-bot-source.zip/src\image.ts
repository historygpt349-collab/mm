import { Bot, InputFile } from "grammy";
import { addPoints, deductPoints, getUserRow } from "./db.js";
import { safeReply } from "./bot.js";

/**
 * Generate AI image: tries Gemini image preview first, falls back to Pollinations AI
 */
export async function generateAiImage(prompt: string): Promise<{ data: Buffer; mime: string } | null> {
  const cleanPrompt = prompt.trim();
  if (!cleanPrompt) return null;

  // 1. Try Pollinations AI (High quality, 100% Free, Zero Rate Limits, No Key Required)
  try {
    const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(cleanPrompt)}?width=1024&height=1024&nologo=true&seed=${Math.floor(Math.random() * 1000000)}`;
    const res = await fetch(url, { signal: AbortSignal.timeout(25000) });
    if (res.ok) {
      const data = Buffer.from(await res.arrayBuffer());
      if (data.length > 2000) {
        return { data, mime: "image/jpeg" };
      }
    }
  } catch (e: any) {
    console.error("Pollinations image generation error:", e?.message ?? e);
  }

  return null;
}

/**
 * Generate a Futuristic Neon Cyberpunk Welcome Board for new members
 */
export async function generateFuturisticWelcomeBoard(name: string, groupTitle: string): Promise<Buffer | null> {
  const cleanName = name.replace(/[^\w\s\u0900-\u097F]/gi, "").trim() || "New Member";
  const cleanGroup = groupTitle.replace(/[^\w\s\u0900-\u097F]/gi, "").trim() || "Our Group";
  const prompt = `futuristic cyberpunk neon HUD welcome banner for member ${cleanName} joining ${cleanGroup}, holographic digital sci-fi interface, glowing cyan purple neon lights, high tech gaming dashboard, 8k resolution`;

  try {
    const img = await generateAiImage(prompt);
    return img ? img.data : null;
  } catch {
    return null;
  }
}

export function registerImageStudio(bot: Bot) {
  bot.command(["image", "draw", "imagine", "photo", "aiimage"], async (ctx) => {
    const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
    const prompt = String(ctx.match ?? "").trim();
    const userId = ctx.from?.id;

    if (!prompt) {
      return safeReply(
        ctx,
        `🎨 <b>Anayra AI Image Studio</b> ✨\n\n` +
          `Aap text prompt se realistic aur futuristic images generate kar sakte hain!\n\n` +
          `👉 <b>Aise likho:</b>\n` +
          `<code>/image a futuristic cybernetic tiger with glowing neon blue stripes</code>\n` +
          `<code>/draw anime style cute girl in rain holding umbrella</code>\n\n` +
          `💰 <b>Cost:</b> 5 Tokens per image ${isBoss ? "(Boss ke liye 100% Free! 👑)" : ""}\n` +
          `💡 <i>Tokens kamane ke liye</i> <code>/refer</code> <i>karein ya Boss se</i> <code>/requesttokens</code> <i>karein!</i>`,
        { parse_mode: "HTML" },
      );
    }

    if (!userId) return;

    // Check token balance (Boss has infinity tokens)
    if (!isBoss) {
      const u = await getUserRow(userId);
      const points = u?.points ?? 0;
      if (points < 5) {
        return safeReply(
          ctx,
          `❌ <b>Tokens Kam Hain!</b> 🎨\n\n` +
            `AI Image Studio se photo render karne ke liye <b>5 Tokens</b> chahiye.\n` +
            `💰 <b>Aapka Balance:</b> ${points} Tokens\n\n` +
            `💡 <b>Tokens kaise kamayein?</b>\n` +
            `• Dosto ko invite karein: <code>/refer</code> (+10 Tokens har dost par!)\n` +
            `• Group mein active rahein (+1 Token har message par)\n` +
            `• Boss se request karein: <code>/requesttokens 5 Image Studio ke liye</code>`,
          { parse_mode: "HTML" },
        );
      }
      // Deduct 5 tokens
      await deductPoints(userId, 5);
    }

    await ctx.replyWithChatAction("upload_photo").catch(() => {});
    const waitMsg = await safeReply(ctx, "🎨 <i>Anayra aapke liye image render kar rahi hai, bas 2 second...</i> ⏳", { parse_mode: "HTML" });

    const img = await generateAiImage(prompt);
    if (!img) {
      // Refund if error
      if (!isBoss) await addPoints(userId, 5);
      return safeReply(ctx, "❌ Image generate karne mein dikkat aayi. Aapke 5 tokens wapas kar diye gaye hain. Thodi der baad dobara try karein.");
    }

    if (waitMsg?.message_id) {
      await ctx.api.deleteMessage(ctx.chat.id, waitMsg.message_id).catch(() => {});
    }

    const uAfter = !isBoss ? await getUserRow(userId) : null;
    const balanceInfo = isBoss ? "👑 <i>Supreme Boss Unlimited Access</i>" : `💰 <i>5 Tokens deducted (Balance: ${uAfter?.points ?? 0} Tokens)</i>`;

    await ctx.replyWithPhoto(new InputFile(img.data, "anayra_ai.jpg"), {
      caption:
        `🎨 <b>Prompt:</b> <i>"${prompt}"</i>\n\n` +
        `✨ <i>Rendered by Anayra AI Studio</i>\n` +
        balanceInfo,
      parse_mode: "HTML",
    });
  });
}
