import type { Bot, Context } from "grammy";
import { chatAllowed } from "./gate.js";

// /anime (AniList) and group notes. Groups and DMs.

const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

// ---------- anime ----------
const ANILIST = `query ($q: String, $type: MediaType) {
  Media(search: $q, type: $type, sort: SEARCH_MATCH) {
    title { romaji english } format status episodes chapters averageScore genres description(asHtml: false)
    startDate { year } coverImage { large } siteUrl
  }
}`;

async function anilist(q: string, type: "ANIME" | "MANGA") {
  try {
    const res = await fetch("https://graphql.anilist.co", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query: ANILIST, variables: { q, type } }),
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) return null;
    return ((await res.json()) as any)?.data?.Media ?? null;
  } catch {
    return null;
  }
}

export function registerExtras(bot: Bot) {
  const grp = (names: string | string[], fn: (ctx: Context, arg: string) => Promise<unknown>) =>
    bot.command(names, async (ctx, next) => {
      if (!chatAllowed(ctx)) return next();
      await fn(ctx, String(ctx.match ?? "").trim());
    });

  grp(["anime", "manga"], async (ctx, arg) => {
    const manga = ctx.message?.text?.startsWith("/manga");
    if (!arg) return void (await ctx.reply(`Jaise: /${manga ? "manga" : "anime"} naruto`));
    await ctx.replyWithChatAction("typing").catch(() => {});
    const m = await anilist(arg, manga ? "MANGA" : "ANIME");
    if (!m) return void (await ctx.reply(`"${arg}" nahi mila 🥺`));
    const title = m.title.english || m.title.romaji;
    const desc = String(m.description ?? "").replace(/<[^>]+>/g, "").replace(/\s+/g, " ").trim().slice(0, 350);
    const caption =
      `<b>${esc(title)}</b>${m.title.romaji && m.title.romaji !== title ? ` (${esc(m.title.romaji)})` : ""}\n` +
      `⭐ ${m.averageScore ? m.averageScore + "/100" : "n/a"}  ·  ${esc(String(m.format ?? ""))}  ·  ${esc(String(m.status ?? ""))}\n` +
      `${manga ? "📖 Chapters" : "📺 Episodes"}: ${m.episodes ?? m.chapters ?? "?"}${m.startDate?.year ? `  ·  ${m.startDate.year}` : ""}\n` +
      `🏷️ ${esc((m.genres ?? []).slice(0, 5).join(", "))}\n\n${esc(desc)}${desc.length >= 350 ? "..." : ""}\n\n<a href="${esc(m.siteUrl)}">AniList par dekho</a>`;
    try {
      await ctx.replyWithPhoto(m.coverImage.large, { caption, parse_mode: "HTML" });
    } catch {
      await ctx.reply(caption, { parse_mode: "HTML", link_preview_options: { is_disabled: true } });
    }
  });
}

export const EXTRAS_MENU = [
  { command: "anime", description: "Anime ki jaankari: /anime naruto" },
  { command: "notes", description: "Group ke saved notes" },
];
