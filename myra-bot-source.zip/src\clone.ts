import { Bot, type Context } from "grammy";
import { addClone, deductPoints, listClones, userClones, type BotClone } from "./db.js";
import { chatReply, speak, toOggOpus } from "./ai.js";
import { SYSTEM_PROMPT } from "./persona.js";

const activeBots = new Map<number, Bot>();

/** Start a cloned bot instance with Anayra's brain and features */
export async function launchCloneInstance(clone: BotClone): Promise<boolean> {
  if (activeBots.has(clone.botId)) return true;
  try {
    const cloneBot = new Bot(clone.token);
    await cloneBot.api.deleteWebhook({ drop_pending_updates: false }).catch(() => {});

    cloneBot.command("start", (ctx) => {
      const name = ctx.from?.first_name ?? "dost";
      return ctx.reply(
        `💖 <b>Hii ${name}!</b>\n\n` +
          `Main <b>@${clone.username}</b> hoon, Anayra AI engine par based aapki personal AI girlfriend & group guardian! ✨\n\n` +
          `💬 Mujhse baatein karne ke liye kuch bhi likhein!\n` +
          `👑 <i>Cloned via Anayra Bot Engine</i>`,
        { parse_mode: "HTML" },
      );
    });

    cloneBot.on("message:text", async (ctx) => {
      if (ctx.message.text.startsWith("/")) return;
      if (ctx.chat.type !== "private" && !ctx.message.text.includes(`@${clone.username}`) && ctx.message.reply_to_message?.from?.id !== ctx.me.id) {
        return;
      }
      await ctx.replyWithChatAction("typing").catch(() => {});
      const reply = await chatReply(ctx.chat.id, ctx.message.text, "", false, undefined, ctx.from?.id);
      await ctx.reply(reply).catch(() => {});
    });

    cloneBot.catch((err) => console.error(`Clone @${clone.username} error:`, err.message ?? err));

    cloneBot.start({
      onStart: (info) => console.log(`🤖 Cloned Bot @${info.username} is running!`),
    });

    activeBots.set(clone.botId, cloneBot);
    return true;
  } catch (e: any) {
    console.error(`Failed to launch clone @${clone.username}:`, e?.message ?? e);
    return false;
  }
}

/** Initialize all previously created clones on startup */
export async function initAllClones() {
  const clones = await listClones();
  console.log(`🤖 Loading ${clones.length} active bot clone(s)...`);
  for (const c of clones) {
    await launchCloneInstance(c);
  }
}

export function registerCloner(bot: Bot) {
  bot.command(["clone", "createbot", "newbot"], async (ctx) => {
    const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
    const token = String(ctx.match ?? "").trim();

    if (!token || !/^\d{8,12}:[A-Za-z0-9_-]{35}$/.test(token)) {
      return ctx.reply(
        `🤖 <b>Bot Cloner / Creator Feature</b> ⚡\n\n` +
          `Aap Anayra ki tarah apni <b>khud ki personal AI bot</b> bana sakte hain!\n\n` +
          `📋 <b>Steps:</b>\n` +
          `1. Telegram par @BotFather ke paas jayein.\n` +
          `2. <code>/newbot</code> command bhejkar apna bot banayein aur Token copy karein.\n` +
          `3. Yahan bhejain: <code>/clone &lt;BOT_TOKEN&gt;</code>\n\n` +
          `🎁 <b>Cost:</b> 100% FREE for everyone! (Boss Hukum)\n` +
          `⚡ <i>Aapki bot Anayra ki tarah AI chat aur group features handle karegi!</i>`,
        { parse_mode: "HTML" },
      );
    }

    // Verify token with Telegram API
    let botInfo: any;
    try {
      const res = await fetch(`https://api.telegram.org/bot${token}/getMe`);
      const data: any = await res.json();
      if (!data?.ok) {
        return ctx.reply("❌ <b>Invalid Bot Token!</b> Please @BotFather se sahi token copy karein.", { parse_mode: "HTML" });
      }
      botInfo = data.result;
    } catch {
      return ctx.reply("❌ Telegram connection failed. Token check karein.", { parse_mode: "HTML" });
    }

    const cloneData: BotClone = {
      token,
      botId: botInfo.id,
      username: botInfo.username,
      title: botInfo.first_name,
      ownerId: ctx.from!.id,
      ownerName: ctx.from!.first_name,
      createdAt: Date.now(),
    };

    await addClone(cloneData);
    const launched = await launchCloneInstance(cloneData);

    return ctx.reply(
      `🎉 <b>CONGRATULATIONS! BOT CLONING SUCCESSFUL!</b> 🤖\n\n` +
        `✅ <b>Bot Name:</b> ${botInfo.first_name}\n` +
        `🔗 <b>Username:</b> @${botInfo.username}\n` +
        `👤 <b>Owner:</b> ${ctx.from!.first_name}\n` +
        `⚡ <b>Status:</b> ${launched ? "LIVE & RUNNING 24/7" : "Configured"}\n\n` +
        `Aap ab @${botInfo.username} par jakar /start kar sakte hain aur apne groups me add kar sakte hain!`,
      { parse_mode: "HTML" },
    );
  });

  bot.command(["myclones", "mybots"], async (ctx) => {
    const clones = await userClones(ctx.from!.id);
    if (!clones.length) {
      return ctx.reply(
        "🤖 Aapke paas abhi koi active bot clone nahi hai.\nApna bot banane ke liye <code>/clone &lt;token&gt;</code> chalao!",
        { parse_mode: "HTML" },
      );
    }
    const lines = clones.map((c, i) => `${i + 1}. <b>${c.title}</b> — @${c.username} (ID: <code>${c.botId}</code>)`);
    return ctx.reply(`🤖 <b>Aapke Active Cloned Bots:</b>\n\n${lines.join("\n")}`, { parse_mode: "HTML" });
  });
}
