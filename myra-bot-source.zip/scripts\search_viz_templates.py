import sys
import subprocess
import json
import re

def search_viz(query="phonk"):
    clean_q = query.replace('"', '').replace("'", "").strip()
    search_term = f"ytsearch4:avee player template {clean_q} viz download link"
    cmd = ["python", "-m", "yt_dlp", "--dump-json", search_term]
    
    try:
        p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8", timeout=25)
    except Exception as e:
        print(json.dumps([]))
        return

    results = []
    for line in p.stdout.strip().split("\n"):
        if not line:
            continue
        try:
            data = json.loads(line)
            title = data.get("title", "")
            desc = data.get("description", "")
            web_url = data.get("webpage_url", "")
            channel = data.get("uploader", "")
            thumb = data.get("thumbnail", "")
            
            # Find all URLs in description
            urls = re.findall(r"(https?://[^\s\"\'<>]+)", desc)
            
            # Filter for download / cloud drive links
            dl_urls = []
            for u in urls:
                u_clean = u.rstrip(".,)]\"'")
                u_lower = u_clean.lower()
                if any(k in u_lower for k in [
                    "mediafire.com", "drive.google.com", "mega.nz", "mega.io", 
                    "dropbox.com", "t.me/", ".viz", ".zip", "download", "linktr.ee"
                ]):
                    if u_clean not in dl_urls:
                        dl_urls.append(u_clean)
            
            results.append({
                "title": title,
                "channel": channel,
                "url": web_url,
                "thumbnail": thumb,
                "download_links": dl_urls[:4],
                "all_links": urls[:6]
            })
        except Exception:
            continue

    print(json.dumps(results))

if __name__ == "__main__":
    q = "phonk car"
    if len(sys.argv) > 1:
        q = " ".join(sys.argv[1:])
    search_viz(q)
