import { delKey, getJSON, getMany, listKeys, setJSON } from "./store.js";

// Users, chats, joins and daily member-count snapshots, stored as Netlify Blobs:
//   u/<userId>  user + points   c/<chatId>  group   j/<groupId>/<ts>-<userId>  join   s/<groupId>/<day>  snapshot
const now = () => Math.floor(Date.now() / 1000);
const DAY = 86400;
const today = () => new Date().toISOString().slice(0, 10);

type TgUser = { id: number; first_name?: string; username?: string; language_code?: string };

export type UserRow = {
  id: number; first_name: string | null; username: string | null;
  first_seen: number; last_seen: number; messages: number; dm_started: number;
  verified: number; verified_at: number | null;
  points: number; referred_by: number | null; ref_rewarded: number;
  act_day: string; act_pts: number;
  lang?: string | null; // Telegram app language; Telegram never reveals a user's country
  vip?: number; // 1 = Group VIP Member Badge active
  vip_reaction?: string | null; // Auto reaction emoji (💎, ⚡, 🔥, etc.)
  mood?: string | null; // romantic, teasing, caring, savage
  is_infinity?: number; // 1 = Unlimited Infinity Tokens
};
export type ChatRow = {
  id: number; title: string | null; type: string; added_at: number; last_seen: number;
  status?: "active" | "removed"; // whether Myra is still in the chat (set from my_chat_member and checked in /stats)
  role?: "admin" | "member";
  removed_at?: number;
  username?: string | null; // public @username, for a t.me link
  link?: string | null; // invite link Telegram reports to the bot (private groups)
  members?: number; // member count when /stats last looked
};

const getUser = (id: number) => getJSON<UserRow>(`u/${id}`);
const putUser = (u: UserRow) => setJSON(`u/${u.id}`, u);
const allUsers = async () => getMany<UserRow>(await listKeys("u/"));

export async function touchUser(u: TgUser, opts: { message?: boolean; dm?: boolean } = {}) {
  const t = now();
  const row: UserRow = (await getUser(u.id)) ?? {
    id: u.id, first_name: null, username: null, first_seen: t, last_seen: t, messages: 0, dm_started: 0,
    verified: 0, verified_at: null, points: 0, referred_by: null, ref_rewarded: 0, act_day: "", act_pts: 0,
  };
  row.first_name = u.first_name ?? null;
  row.username = u.username ?? null;
  row.lang = u.language_code ?? row.lang ?? null;
  row.last_seen = t;
  if (opts.message) row.messages += 1;
  if (opts.dm) row.dm_started = 1;

  // Auto claim pending token grant if Boss sent tokens before this user was registered
  if (u.username) {
    const cleanU = u.username.replace(/^@/, "").toLowerCase();
    const pendingKey = `pending_grant/${cleanU}`;
    try {
      const pending = await getJSON<{ amount: number | "infinity"; grantedBy: number }>(pendingKey);
      if (pending) {
        if (pending.amount === "infinity") {
          row.points = 999999999;
          row.is_infinity = 1;
        } else {
          row.points = (row.points || 0) + Number(pending.amount);
        }
        await delKey(pendingKey);
      }
    } catch {}
  }

  await putUser(row);
}

export const getUserRow = (id: number) => getUser(id);

/** Looks a person up by @username among everyone Myra has seen (Telegram cannot resolve user names for bots). */
export async function findUserByUsername(username: string) {
  const n = username.replace(/^@/, "").toLowerCase();
  return (await allUsers()).find((u) => u.username?.toLowerCase() === n) ?? null;
}

export async function touchChat(c: { id: number; title?: string; type: string; username?: string }) {
  const t = now();
  const old = await getJSON<ChatRow>(`c/${c.id}`);
  // An update from the chat means Myra is in it, so a "removed" mark from earlier is no longer true.
  await setJSON(`c/${c.id}`, {
    ...old, id: c.id, title: c.title ?? old?.title ?? null, type: c.type, added_at: old?.added_at ?? t, last_seen: t,
    username: c.username ?? old?.username, status: "active", removed_at: undefined,
  });
}

/** Records that Myra was added to / removed from a chat (my_chat_member) or found gone when /stats checked. */
export async function setChatStatus(
  c: { id: number; title?: string | null; type: string },
  status: "active" | "removed",
  role?: "admin" | "member",
) {
  const t = now();
  const old = await getJSON<ChatRow>(`c/${c.id}`);
  if (old?.status === status && (status === "removed" || old.role === role)) return;
  await setJSON(`c/${c.id}`, {
    ...old, id: c.id, title: c.title ?? old?.title ?? null, type: c.type, added_at: old?.added_at ?? t, last_seen: old?.last_seen ?? t,
    status, role: status === "active" ? role ?? old?.role : undefined,
    removed_at: status === "removed" ? old?.removed_at ?? t : undefined,
  });
}

/** Link and size details learned while Myra could still see the chat. */
export async function setChatInfo(id: number, info: { username?: string | null; link?: string | null; members?: number }) {
  const old = await getJSON<ChatRow>(`c/${id}`);
  if (old) await setJSON(`c/${id}`, { ...old, ...Object.fromEntries(Object.entries(info).filter(([, v]) => v !== undefined)) });
}

export async function allChats() {
  return getMany<ChatRow>(await listKeys("c/"));
}

/** How many people opened the live voice page (a link is made per chat, valid for a day). */
export async function liveStats() {
  const [people, tokens] = await Promise.all([
    listKeys("tc/"),
    listKeys("t/").then((k) => getMany<{ chatId: number; at: number }>(k)),
  ]);
  const since = Date.now() - 24 * 3600_000;
  return { total: people.length, last24h: new Set(tokens.filter((x) => x.at > since).map((x) => x.chatId)).size };
}

export async function markVerified(userId: number) {
  const u = await getUser(userId);
  if (!u) return;
  u.verified = 1;
  u.verified_at ??= now();
  await putUser(u);
}

export async function recordJoin(groupId: number, userId: number) {
  await setJSON(`j/${groupId}/${now()}-${userId}`, 1);
}

export async function snapshot(groupId: number, members: number) {
  await setJSON(`s/${groupId}/${today()}`, { members });
}

export async function overview() {
  const t = now();
  const [users, chats] = await Promise.all([allUsers(), listKeys("c/").then((k) => getMany<ChatRow>(k))]);
  const count = (f: (u: UserRow) => boolean) => users.filter(f).length;
  return {
    total: users.length,
    dm: count((u) => u.dm_started === 1),
    verified: count((u) => u.verified === 1),
    verifiedToday: count((u) => (u.verified_at ?? 0) >= t - DAY),
    active24h: count((u) => u.last_seen >= t - DAY),
    active7d: count((u) => u.last_seen >= t - 7 * DAY),
    active30d: count((u) => u.last_seen >= t - 30 * DAY),
    new24h: count((u) => u.first_seen >= t - DAY),
    new7d: count((u) => u.first_seen >= t - 7 * DAY),
    messages: users.reduce((s, u) => s + u.messages, 0),
    groups: chats.filter((c) => (c.type === "group" || c.type === "supergroup") && c.status !== "removed").length,
  };
}

/** Users per Telegram app language (the closest thing to "where from" Telegram exposes), biggest first. */
export async function languageStats() {
  const n = new Map<string, number>();
  for (const u of await allUsers()) n.set(u.lang ?? "?", (n.get(u.lang ?? "?") ?? 0) + 1);
  return [...n].sort((a, b) => b[1] - a[1]);
}

/** People who opened the live voice page, per country (Netlify geo-locates the visit). Key g/<chatId>. */
export async function countryStats() {
  const n = new Map<string, number>();
  for (const g of await getMany<{ country: string }>(await listKeys("g/"))) n.set(g.country, (n.get(g.country) ?? 0) + 1);
  return [...n].sort((a, b) => b[1] - a[1]);
}

export async function topUsers(limit = 5) {
  return (await allUsers())
    .filter((u) => u.messages > 0)
    .sort((a, b) => b.messages - a.messages)
    .slice(0, limit)
    .map(({ id, first_name, username, messages }) => ({ id, first_name, username, messages }));
}

export async function groupGrowth(groupId: number) {
  const t = now();
  const joinTimes = (await listKeys(`j/${groupId}/`)).map((k) => Number(k.split("/").pop()!.split("-")[0]));
  const weekAgoDay = new Date(Date.now() - 7 * DAY * 1000).toISOString().slice(0, 10);
  const snapKey = (await listKeys(`s/${groupId}/`)).sort().find((k) => k.split("/").pop()! >= weekAgoDay);
  const base = snapKey ? await getJSON<{ members: number }>(snapKey) : null;
  return {
    joins24h: joinTimes.filter((x) => x >= t - DAY).length,
    joins7d: joinTimes.filter((x) => x >= t - 7 * DAY).length,
    baseline7d: base?.members ?? null,
  };
}

// ---------- points + referrals ----------
export const REF_POINTS = 15; // referrer, 15 tokens per invited friend
export const WELCOME_POINTS = 5; // invited friend gets 5 welcome tokens
export const DAILY_ACTIVITY_CAP = 50; // max "chatting in the group" points per user per day

export async function addPoints(userId: number, delta: number): Promise<number> {
  let u = await getUser(userId);
  if (!u) {
    await touchUser({ id: userId });
    u = await getUser(userId);
  }
  if (!u) return 0;
  u.points = Math.max(0, u.points + delta);
  await putUser(u);
  return u.points;
}

export async function setPoints(userId: number, amount: number): Promise<number> {
  let u = await getUser(userId);
  if (!u) {
    await touchUser({ id: userId });
    u = await getUser(userId);
  }
  if (!u) return 0;
  u.points = Math.max(0, amount);
  await putUser(u);
  return u.points;
}

/** Remember who invited this user and credit points immediately. */
export async function setReferrer(userId: number, referrerId: number): Promise<boolean> {
  if (userId === referrerId) return false;
  let [u, ref] = await Promise.all([getUser(userId), getUser(referrerId)]);
  if (!u) {
    await touchUser({ id: userId });
    u = await getUser(userId);
  }
  if (!u || !ref || u.referred_by !== null) return false;
  u.referred_by = referrerId;
  await putUser(u);
  await rewardReferral(userId);
  return true;
}

/** Pays the referrer and the invited friend a single time. */
export async function rewardReferral(userId: number) {
  const u = await getUser(userId);
  if (!u || u.referred_by === null || u.ref_rewarded) return null;
  u.ref_rewarded = 1;
  u.verified = 1;
  u.points += WELCOME_POINTS;
  await putUser(u);
  await addPoints(u.referred_by, REF_POINTS);
  return { referrer: u.referred_by, name: u.first_name ?? u.username ?? String(userId), refPoints: REF_POINTS, welcomePoints: WELCOME_POINTS };
}

/** Rewards inviter when they add members directly to a Telegram group */
export async function rewardGroupMemberAdd(
  groupId: number,
  inviterId: number,
  addedUsers: { id: number; is_bot?: boolean; first_name?: string; username?: string }[]
): Promise<{ inviterTotal: number; rewardedCount: number; pointsEarned: number }> {
  let rewardedCount = 0;
  for (const u of addedUsers) {
    if (u.id === inviterId || u.is_bot) continue;
    let existing = await getUser(u.id);
    if (!existing) {
      await touchUser({ id: u.id, first_name: u.first_name, username: u.username });
      existing = await getUser(u.id);
    }
    if (existing && existing.referred_by === null) {
      existing.referred_by = inviterId;
      existing.ref_rewarded = 1;
      existing.points += WELCOME_POINTS;
      await putUser(existing);
      rewardedCount++;
    }
  }

  const pointsEarned = rewardedCount * REF_POINTS;
  const inviterTotal = pointsEarned > 0 ? await addPoints(inviterId, pointsEarned) : ((await getUser(inviterId))?.points ?? 0);
  return { inviterTotal, rewardedCount, pointsEarned };
}

/** Claim daily free token bonus */
export async function claimDailyBonus(userId: number): Promise<{ ok: boolean; balance: number; reason?: string; streak: number; bonus: number }> {
  let u = await getUser(userId);
  if (!u) {
    await touchUser({ id: userId });
    u = await getUser(userId);
  }
  if (!u) return { ok: false, balance: 0, reason: "Account nahi mila", streak: 0, bonus: 0 };

  const lastClaim = await getJSON<{ date: string; streak: number }>(`daily_bonus/${userId}`);
  const curDay = today();

  if (lastClaim && lastClaim.date === curDay) {
    return {
      ok: false,
      balance: u.points,
      reason: "Aap aaj ka bonus pehle hi claim kar chuke hain! Kal dobara aana 😊",
      streak: lastClaim.streak,
      bonus: 0,
    };
  }

  let streak = 1;
  if (lastClaim) {
    const yesterday = new Date(Date.now() - 86400 * 1000).toISOString().slice(0, 10);
    if (lastClaim.date === yesterday) {
      streak = (lastClaim.streak || 1) + 1;
    }
  }

  const bonus = 10;
  u.points += bonus;
  await putUser(u);
  await setJSON(`daily_bonus/${userId}`, { date: curDay, streak });

  return { ok: true, balance: u.points, streak, bonus };
}

/** Checks if daily free bonus is ready to be claimed */
export async function canClaimDailyBonus(userId: number): Promise<boolean> {
  const lastClaim = await getJSON<{ date: string }>(`daily_bonus/${userId}`);
  return !lastClaim || lastClaim.date !== today();
}

/** Boss Royal Token Grant: can grant 1 to 1 Crore or Infinity to any user by ID or @username */
export async function grantBossTokens(
  target: string | number,
  amount: number | "infinity",
  grantedBy: number
): Promise<{
  ok: boolean;
  status: "granted" | "pending";
  userId?: number;
  username: string;
  amount: number | "infinity";
  newBalance: number | "infinity";
}> {
  // 1. If numeric user ID
  if (typeof target === "number" || /^\d{5,}$/.test(String(target).trim())) {
    const id = Number(target);
    let u = await getUser(id);
    if (!u) {
      await touchUser({ id });
      u = await getUser(id);
    }
    if (u) {
      if (amount === "infinity") {
        u.points = 999999999;
        u.is_infinity = 1;
        await putUser(u);
        return { ok: true, status: "granted", userId: u.id, username: u.username ? `@${u.username}` : (u.first_name || String(u.id)), amount: "infinity", newBalance: "infinity" };
      } else {
        u.points = (u.points || 0) + amount;
        await putUser(u);
        return { ok: true, status: "granted", userId: u.id, username: u.username ? `@${u.username}` : (u.first_name || String(u.id)), amount, newBalance: u.points };
      }
    }
  }

  // 2. If username string (with or without @)
  const clean = String(target).replace(/^@/, "").trim().toLowerCase();
  const existing = await findUserByUsername(clean);
  if (existing) {
    if (amount === "infinity") {
      existing.points = 999999999;
      existing.is_infinity = 1;
      await putUser(existing);
      return { ok: true, status: "granted", userId: existing.id, username: `@${existing.username || clean}`, amount: "infinity", newBalance: "infinity" };
    } else {
      existing.points = (existing.points || 0) + amount;
      await putUser(existing);
      return { ok: true, status: "granted", userId: existing.id, username: `@${existing.username || clean}`, amount, newBalance: existing.points };
    }
  }

  // 3. Not seen yet in DB: store as pending grant so as soon as they interact, tokens auto-credit!
  await setJSON(`pending_grant/${clean}`, {
    username: clean,
    amount,
    grantedBy,
    grantedAt: Date.now(),
  });

  return {
    ok: true,
    status: "pending",
    username: `@${clean}`,
    amount,
    newBalance: amount,
  };
}

/** +1 point for chatting in a required group, up to DAILY_ACTIVITY_CAP per day. */
export async function activityPoint(userId: number): Promise<boolean> {
  const u = await getUser(userId);
  if (!u) return false;
  const day = today();
  if (u.act_day !== day) {
    u.act_day = day;
    u.act_pts = 0;
  }
  if (u.act_pts >= DAILY_ACTIVITY_CAP) return false;
  u.act_pts += 1;
  u.points += 1;
  await putUser(u);
  return true;
}

export async function profile(userId: number) {
  const users = await allUsers();
  const u = users.find((x) => x.id === userId);
  if (!u) return { points: 0, rank: null as number | null, referrals: 0, pending: 0, vip: false, vip_reaction: null, mood: "normal", is_infinity: false };
  return {
    points: u.points,
    rank: u.points > 0 ? users.filter((x) => x.points > u.points).length + 1 : null,
    referrals: users.filter((x) => x.referred_by === userId && x.ref_rewarded === 1).length,
    pending: users.filter((x) => x.referred_by === userId && x.ref_rewarded === 0).length,
    vip: u.vip === 1,
    vip_reaction: u.vip_reaction ?? null,
    mood: u.mood ?? "normal",
    is_infinity: !!u.is_infinity || u.points >= 999999999,
  };
}

export async function buyVip(userId: number, cost = 50): Promise<{ ok: boolean; reason?: string; balance: number }> {
  const u = await getUser(userId);
  if (!u) return { ok: false, reason: "Account nahi mila", balance: 0 };
  if (u.points < cost) return { ok: false, reason: `Tokens kam hain! Chahiye: ${cost}, Aapke paas: ${u.points}`, balance: u.points };
  u.points -= cost;
  u.vip = 1;
  await putUser(u);
  return { ok: true, balance: u.points };
}

export async function buyReaction(userId: number, emoji = "💎", cost = 0): Promise<{ ok: boolean; reason?: string; balance: number }> {
  let u = await getUser(userId);
  if (!u) {
    await touchUser({ id: userId });
    u = await getUser(userId);
  }
  if (!u) return { ok: false, reason: "Account nahi mila", balance: 0 };
  if (cost > 0 && u.points < cost) {
    return { ok: false, reason: `Tokens kam hain! Chahiye: ${cost}, Aapke paas: ${u.points}`, balance: u.points };
  }
  if (cost > 0) {
    u.points -= cost;
  }
  u.vip_reaction = emoji;
  await putUser(u);
  return { ok: true, balance: u.points };
}

export async function setReaction(userId: number, emoji: string): Promise<boolean> {
  const res = await buyReaction(userId, emoji, 0);
  return res.ok;
}

// ---------- Welcome Pass & Token Requests ----------
export async function hasWelcomePass(chatId: number): Promise<boolean> {
  return (await getJSON<boolean>(`wp/${chatId}`)) === true;
}

export async function grantWelcomePass(chatId: number): Promise<boolean> {
  await setJSON(`wp/${chatId}`, true);
  return true;
}

export async function buyWelcomePass(chatId: number, userId: number, cost = 20): Promise<{ ok: boolean; reason?: string; balance: number }> {
  const isBoss = process.env.OWNER_ID && String(userId) === String(process.env.OWNER_ID);
  if (isBoss) {
    await grantWelcomePass(chatId);
    return { ok: true, balance: 999999 };
  }
  let u = await getUser(userId);
  if (!u) {
    await touchUser({ id: userId });
    u = await getUser(userId);
  }
  if (!u) return { ok: false, reason: "Account nahi mila", balance: 0 };
  if (u.points < cost) {
    return { ok: false, reason: `Tokens kam hain! Welcome Pass ke liye ${cost} Tokens chahiye, aapke paas ${u.points} Tokens hain.`, balance: u.points };
  }
  u.points -= cost;
  await putUser(u);
  await grantWelcomePass(chatId);
  return { ok: true, balance: u.points };
}

export type TokenRequest = {
  id: string;
  userId: number;
  userName: string;
  amount: number;
  reason?: string;
  status: "pending" | "approved" | "rejected";
  createdAt: number;
};

export async function createTokenRequest(userId: number, userName: string, amount: number, reason?: string): Promise<TokenRequest> {
  const id = `tr_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const req: TokenRequest = {
    id,
    userId,
    userName,
    amount,
    reason,
    status: "pending",
    createdAt: Date.now(),
  };
  await setJSON(`tr/${id}`, req);
  return req;
}

export async function getTokenRequest(id: string): Promise<TokenRequest | null> {
  return getJSON<TokenRequest>(`tr/${id}`);
}

export async function resolveTokenRequest(id: string, status: "approved" | "rejected"): Promise<TokenRequest | null> {
  const req = await getTokenRequest(id);
  if (!req || req.status !== "pending") return null;
  req.status = status;
  await setJSON(`tr/${id}`, req);
  if (status === "approved") {
    await addPoints(req.userId, req.amount);
  }
  return req;
}

// Girlfriend Mood is 100% Free as Boss instructed
export async function setMood(userId: number, mood: string): Promise<{ ok: boolean; reason?: string; balance: number }> {
  let u = await getUser(userId);
  if (!u) {
    await touchUser({ id: userId });
    u = await getUser(userId);
  }
  if (!u) return { ok: false, reason: "Account nahi mila", balance: 0 };
  u.mood = mood;
  await putUser(u);
  return { ok: true, balance: u.points };
}

export async function deductPoints(userId: number, amount: number): Promise<boolean> {
  const u = await getUser(userId);
  if (!u || u.points < amount) return false;
  u.points -= amount;
  await putUser(u);
  return true;
}

// ---------- Bot Clones Storage ----------
export type BotClone = {
  token: string;
  botId: number;
  username: string;
  title?: string;
  ownerId: number;
  ownerName?: string;
  createdAt: number;
};

export async function addClone(clone: BotClone) {
  await setJSON(`clone/${clone.botId}`, clone);
  const list = (await getJSON<number[]>("clones_list")) ?? [];
  if (!list.includes(clone.botId)) {
    list.push(clone.botId);
    await setJSON("clones_list", list);
  }
}

export async function listClones(): Promise<BotClone[]> {
  const list = (await getJSON<number[]>("clones_list")) ?? [];
  const clones = await Promise.all(list.map((id) => getJSON<BotClone>(`clone/${id}`)));
  return clones.filter(Boolean) as BotClone[];
}

export async function userClones(userId: number): Promise<BotClone[]> {
  const all = await listClones();
  return all.filter((c) => c.ownerId === userId);
}

export async function leaderboard(limit = 10) {
  return (await allUsers())
    .filter((u) => u.points > 0)
    .sort((a, b) => b.points - a.points || a.id - b.id)
    .slice(0, limit)
    .map(({ id, first_name, username, points }) => ({ id, first_name, username, points }));
}
