import { spawn, spawnSync } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { createServer } from "node:http";
import { join, resolve } from "node:path";
import { pathToFileURL } from "node:url";

const ROOT = resolve(import.meta.dirname, "..");
const OUT = join(ROOT, ".build-bot");

console.log("⚡ Compiling TypeScript for bot runner...");
rmSync(OUT, { recursive: true, force: true });
const tsc = spawnSync("npx", ["tsc", "-p", "tsconfig.test.json", "--outDir", OUT], { cwd: ROOT, stdio: "inherit", shell: true });
if (tsc.status !== 0) {
  console.error("TypeScript compilation failed.");
  process.exit(tsc.status ?? 1);
}

mkdirSync(OUT, { recursive: true });
writeFileSync(join(OUT, "package.json"), JSON.stringify({ type: "module" }));

const PORT = Number(process.env.PORT) || 3000;
const { addPoints, getUserRow } = await import(pathToFileURL(join(OUT, "src/db.js")).href);

// Start HTTP server for WebApp
const server = createServer(async (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") {
    res.writeHead(204);
    res.end();
    return;
  }

  const parsedUrl = new URL(req.url || "/", `http://localhost:${PORT}`);
  const pathname = parsedUrl.pathname;

  if (pathname === "/api/claim-reward" && req.method === "POST") {
    let body = "";
    req.on("data", (chunk) => { body += chunk; });
    req.on("end", async () => {
      try {
        const data = JSON.parse(body || "{}");
        const uid = Number(data.userId);
        const tokens = Math.max(1, Math.min(50, Number(data.tokens) || 10));
        if (!uid) {
          res.writeHead(400, { "Content-Type": "application/json" });
          res.end(JSON.stringify({ ok: false, reason: "missing userId" }));
          return;
        }
        const newBal = await addPoints(uid, tokens);
        res.writeHead(200, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ ok: true, balance: newBal, tokensCredited: tokens }));
      } catch (e) {
        res.writeHead(500, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ ok: false, error: String(e) }));
      }
    });
    return;
  }

  if (pathname === "/api/user-profile" && req.method === "GET") {
    const uid = Number(parsedUrl.searchParams.get("userId"));
    if (!uid) {
      res.writeHead(400, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ ok: false, reason: "missing userId" }));
      return;
    }
    const u = await getUserRow(uid);
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ ok: true, points: u?.points ?? 0, username: u?.username, name: u?.first_name }));
    return;
  }

  let urlPath = pathname === "/" ? "/index.html" : pathname;
  let filePath = join(ROOT, "public", urlPath.replace(/^\//, ""));
  if (!existsSync(filePath)) {
    filePath = join(ROOT, "public", "index.html");
  }

  if (existsSync(filePath)) {
    const ext = filePath.split(".").pop();
    const mime = ext === "html" ? "text/html" : ext === "js" ? "application/javascript" : ext === "css" ? "text/css" : ext === "json" ? "application/json" : "text/plain";
    res.writeHead(200, { "Content-Type": `${mime}; charset=utf-8` });
    res.end(readFileSync(filePath));
  } else {
    res.writeHead(404, { "Content-Type": "text/plain" });
    res.end("Not Found");
  }
});

server.listen(PORT, () => {
  console.log(`🌐 Local WebApp Server running on http://localhost:${PORT}`);
});

// Establish live public HTTPS tunnel if needed
function establishTunnel(port) {
  return new Promise((resolve) => {
    console.log("🔗 Connecting live HTTPS tunnel for Telegram WebApp...");
    let resolved = false;

    const ssh = spawn("ssh", [
      "-o", "StrictHostKeyChecking=no",
      "-o", "ServerAliveInterval=20",
      "-R", `80:localhost:${port}`,
      "nokey@localhost.run"
    ], { stdio: ["ignore", "pipe", "pipe"] });

    const handleOutput = (d) => {
      const text = d.toString();
      const m = text.match(/https:\/\/[a-zA-Z0-9-]+\.lhr\.life/);
      if (m && !resolved) {
        resolved = true;
        resolve({ url: m[0], proc: ssh });
      }
    };

    ssh.stdout.on("data", handleOutput);
    ssh.stderr.on("data", handleOutput);

    ssh.on("close", () => {
      if (!resolved) {
        resolved = true;
        resolve({ url: null, proc: null });
      }
    });

    setTimeout(() => {
      if (!resolved) {
        resolved = true;
        resolve({ url: null, proc: ssh });
      }
    }, 7000);
  });
}

let publicUrl = process.env.PUBLIC_URL ? process.env.PUBLIC_URL.trim() : "";
if (!publicUrl || publicUrl.includes("myra-bot-88823.netlify.app") || publicUrl.includes("localhost")) {
  const tunnel = await establishTunnel(PORT);
  if (tunnel.url) {
    publicUrl = tunnel.url;
    process.env.PUBLIC_URL = tunnel.url;
    console.log(`✨ Live Public HTTPS Tunnel established: ${tunnel.url}`);
  } else {
    console.warn("⚠️ Tunnel timed out, falling back to local port.");
  }
} else {
  console.log(`🌐 Using configured PUBLIC_URL: ${publicUrl}`);
}

console.log("🚀 Loading bot instance with WebApp URL:", process.env.PUBLIC_URL || `http://localhost:${PORT}`);
const { bot, registerMenus, initClones } = await import(pathToFileURL(join(OUT, "src/bot.js")).href);

async function main() {
  try {
    await bot.api.deleteWebhook({ drop_pending_updates: false });
    console.log("🧹 Previous Webhook cleared.");
  } catch (e) {
    console.warn("deleteWebhook warning:", e?.message ?? e);
  }

  try {
    await registerMenus();
    console.log("📋 Menus and commands registered.");
  } catch (e) {
    console.warn("registerMenus warning:", e?.message ?? e);
  }

  if (typeof initClones === "function") {
    try {
      await initClones();
      console.log("🤖 Cloned bot instances initialized.");
    } catch (e) {
      console.warn("initClones warning:", e?.message ?? e);
    }
  }

  const me = await bot.api.getMe();
  console.log(`\n======================================================`);
  console.log(`💖 Bot @${me.username} (${me.first_name}) is LIVE and LISTENING!`);
  console.log(`🕹️ Comfy Slippy Bot Arcade WebApp: ${process.env.PUBLIC_URL || `http://localhost:${PORT}`}/index.html`);
  console.log(`💬 Open Telegram and send /start or click Menu to play!`);
  console.log(`======================================================\n`);

  await bot.start({
    onStart: (info) => {
      console.log(`✅ Connected as @${info.username}. Bot is running smoothly.`);
    },
  });
}

main().catch((err) => {
  console.error("Fatal error:", err);
  process.exit(1);
});
