import test from "node:test";
import assert from "node:assert/strict";
import { findVerifiedApk, isApkIntent, formatApkCard, APK_CHANNELS, VERIFIED_MOD_APKS } from "../src/apk.js";
import { VIZ_CHANNELS } from "../src/viz.js";
import { BOSS_REACTIONS, PREMIUM_AUTO_REACTIONS } from "../src/bot.js";

// Official Telegram Bot API allowed reaction emojis
const TELEGRAM_ALLOWED_REACTION_EMOJIS = new Set([
  "👍", "👎", "❤️", "🔥", "🥰", "👏", "😁", "🤔", "🤯", "😱", "🤬", "😢",
  "🎉", "🤩", "🤮", "💩", "🙏", "👌", "🕊", "🤡", "🥱", "🥴", "😍", "🐳",
  "❤️‍🔥", "🌚", "🌭", "💯", "🤣", "⚡", "🍌", "🏆", "💔", "🤨", "😐", "🍓",
  "🍾", "💋", "🖕", "😈", "😴", "😭", "🤓", "👻", "👨‍💻", "👀", "🎃", "🙈",
  "😇", "😨", "🤝", "✍️", "🤗", "🫡", "🎅", "🎄", "☃️", "💅", "🤪", "🗿",
  "🆒", "💘", "🙉", "🦄", "😘", "💊", "🙊", "😎", "👾", "🤷‍♂️", "🤷", "🤷‍♀️", "😡",
]);

test("Auto-Reactions: all BOSS_REACTIONS and PREMIUM_AUTO_REACTIONS are 100% legal in Telegram Bot API", () => {
  for (const emoji of BOSS_REACTIONS) {
    assert.ok(
      TELEGRAM_ALLOWED_REACTION_EMOJIS.has(emoji),
      `BOSS reaction '${emoji}' must be supported by Telegram Bot API`,
    );
  }
  for (const emoji of PREMIUM_AUTO_REACTIONS) {
    assert.ok(
      TELEGRAM_ALLOWED_REACTION_EMOJIS.has(emoji),
      `PREMIUM reaction '${emoji}' must be supported by Telegram Bot API`,
    );
  }
});

test("findVerifiedApk: resolves Gold Motion, Avee Player, CapCut, Games & Utilities", () => {
  assert.equal(findVerifiedApk("gold motion")?.id, "gold_motion");
  assert.equal(findVerifiedApk("alight motion")?.id, "gold_motion");
  assert.equal(findVerifiedApk("GoldMotion")?.id, "gold_motion");
  assert.equal(findVerifiedApk("avee player")?.id, "avee_player_pro");
  assert.equal(findVerifiedApk("capcut")?.id, "capcut_pro");
  assert.equal(findVerifiedApk("kinemaster")?.id, "kinemaster_pro");
  assert.equal(findVerifiedApk("subway surfers")?.id, "subway_surfers");
  assert.equal(findVerifiedApk("roblox")?.id, "roblox_mod");
  assert.equal(findVerifiedApk("remini")?.id, "remini_pro");
  assert.equal(findVerifiedApk("spotify")?.id, "spotify_premium");
  assert.equal(findVerifiedApk("netflix")?.id, "onstream_vip");
  assert.equal(findVerifiedApk("unknown_random_app_xyz"), null);
});

test("isApkIntent: detects APK, mod, and app queries in Hindi & English", () => {
  assert.ok(isApkIntent("mujhe gold motion chahiye"));
  assert.ok(isApkIntent("alight motion ka mod apk chahiye"));
  assert.ok(isApkIntent("subway surfers mod do"));
  assert.ok(isApkIntent("roblox mod menu"));
  assert.ok(isApkIntent("/apk capcut"));
  assert.ok(isApkIntent("modded apk bhejo"));
  assert.ok(!isApkIntent("kya haal hai kahan ho"));
});

test("formatApkCard: formats rich card with security status and direct buttons", () => {
  const item = VERIFIED_MOD_APKS.find((a) => a.id === "gold_motion")!;
  const card = formatApkCard(item, true, [{ title: "Alight Motion Gold v5.0", channel: "@liteapks", postUrl: "https://t.me/liteapks/100" }]);
  assert.ok(card.text.includes("Gold Motion Edition"));
  assert.ok(card.text.includes("100% VirusTotal Clean"));
  assert.ok(card.text.includes("No Watermark"));
  assert.ok(card.text.includes("Supreme Boss Special Request"));
  assert.ok(card.reply_markup);
});

test("Channels Config: Visualizer and APK channels are properly configured", () => {
  assert.ok(VIZ_CHANNELS.includes("Phonkyworlds"));
  assert.ok(VIZ_CHANNELS.includes("BLUE_PHONK_23"));
  assert.ok(VIZ_CHANNELS.includes("Shadow_Phonk_Editz1"));
  assert.ok(VIZ_CHANNELS.includes("MR_PHONK_99"));

  const apkNames = APK_CHANNELS.map((c) => c.username);
  assert.ok(apkNames.includes("modplays_official"));
  assert.ok(apkNames.includes("liteapks"));
  assert.ok(apkNames.includes("CutAnonArmy"));
  assert.ok(apkNames.includes("primetechlibrary"));
});
