import test from "node:test";
import assert from "node:assert/strict";
import {
  buyReaction,
  buyWelcomePass,
  hasWelcomePass,
  createTokenRequest,
  getTokenRequest,
  resolveTokenRequest,
  addPoints,
  touchUser,
  getUserRow,
  rewardGroupMemberAdd,
  claimDailyBonus,
} from "../src/db.js";
import { pointsText, shopText } from "../src/referral.js";

test("buyReaction: 100% Free - sets reaction emoji without deducting tokens", async () => {
  const userId = 99881122;
  await touchUser({ id: userId });
  await addPoints(userId, 50);

  const res = await buyReaction(userId, "🔥", 0);
  assert.equal(res.ok, true);
  assert.equal(res.balance, 50); // no tokens deducted

  const u = await getUserRow(userId);
  assert.equal(u?.vip_reaction, "🔥");
  assert.equal(u?.points, 50);
});

test("Welcome Pass: buyWelcomePass deducts 20 tokens and unlocks group pass", async () => {
  const userId = 99881133;
  const chatId = -10099881133;
  await touchUser({ id: userId });
  await addPoints(userId, 30);

  assert.equal(await hasWelcomePass(chatId), false);

  const res = await buyWelcomePass(chatId, userId, 20);
  assert.equal(res.ok, true);
  assert.equal(res.balance, 10);
  assert.equal(await hasWelcomePass(chatId), true);

  // Insufficient tokens for second purchase
  const res2 = await buyWelcomePass(-10099881134, userId, 20);
  assert.equal(res2.ok, false);
  assert.match(res2.reason!, /Tokens kam hain/);
});

test("Token Request: create, retrieve, approve and reject flows", async () => {
  const userId = 99881144;
  await touchUser({ id: userId });
  const initialUser = await getUserRow(userId);
  const initialPoints = initialUser?.points ?? 0;

  const req = await createTokenRequest(userId, "TestUser", 25, "Testing tokens");
  assert.ok(req.id.startsWith("tr_"));
  assert.equal(req.status, "pending");
  assert.equal(req.amount, 25);

  const fetched = await getTokenRequest(req.id);
  assert.equal(fetched?.id, req.id);

  // Approve request
  const approved = await resolveTokenRequest(req.id, "approved");
  assert.equal(approved?.status, "approved");

  const uAfter = await getUserRow(userId);
  assert.equal(uAfter?.points, initialPoints + 25);

  // Once resolved, cannot resolve again
  const reResolve = await resolveTokenRequest(req.id, "rejected");
  assert.equal(reResolve, null);
});

test("rewardGroupMemberAdd: credits +15 tokens per member to inviter and +5 welcome tokens to new member", async () => {
  const inviterId = 99881155;
  const newMember1 = { id: 99881156, is_bot: false, first_name: "Rahul" };
  const newMember2 = { id: 99881157, is_bot: false, first_name: "Amit" };
  const botMember = { id: 99881158, is_bot: true, first_name: "SomeBot" };

  await touchUser({ id: inviterId });
  const inviterInit = (await getUserRow(inviterId))?.points ?? 0;

  const res = await rewardGroupMemberAdd(-1001234567, inviterId, [newMember1, newMember2, botMember]);
  assert.equal(res.rewardedCount, 2); // only human members counted
  assert.equal(res.pointsEarned, 30); // 2 * 15

  const inviterAfter = await getUserRow(inviterId);
  assert.equal(inviterAfter?.points, inviterInit + 30);

  const m1 = await getUserRow(newMember1.id);
  assert.equal(m1?.points, 5); // 5 welcome tokens
});

test("claimDailyBonus: allows 1 claim per 24h and increments streak", async () => {
  const userId = 99881166;
  await touchUser({ id: userId });

  const c1 = await claimDailyBonus(userId);
  assert.equal(c1.ok, true);
  assert.equal(c1.bonus, 10);
  assert.equal(c1.streak, 1);

  // Second claim immediately should fail
  const c2 = await claimDailyBonus(userId);
  assert.equal(c2.ok, false);
  assert.match(c2.reason!, /pehle hi claim kar chuke hain/);
});

test("pointsText: Boss gets Infinity Tokens card, user gets token breakdown", async () => {
  process.env.OWNER_ID = "8974234249";
  const bossText = await pointsText(8974234249);
  assert.match(bossText, /ROYAL CREATOR & OWNER DOMAIN/);
  assert.match(bossText, /INFINITY TOKENS/);

  const userText = await pointsText(12345678);
  assert.match(userText, /Aapka Wallet & Profile Status/);
  assert.match(userText, /100% FREE FEATURES/);
  assert.match(userText, /PREMIUM TOKEN STORE/);
});

test("parseTokenAmount: correctly parses numbers, crore, lakh, k, and infinity", async () => {
  const { parseTokenAmount } = await import("../src/bot.js");
  assert.equal(parseTokenAmount("5000"), 5000);
  assert.equal(parseTokenAmount("1 lakh"), 100000);
  assert.equal(parseTokenAmount("5 lakh"), 500000);
  assert.equal(parseTokenAmount("1 crore"), 10000000);
  assert.equal(parseTokenAmount("50k"), 50000);
  assert.equal(parseTokenAmount("infinity"), "infinity");
  assert.equal(parseTokenAmount("inf"), "infinity");
  assert.equal(parseTokenAmount("unlimited"), "infinity");
});

test("grantBossTokens: grants tokens to existing user, new pending user, and handles infinity", async () => {
  const { grantBossTokens } = await import("../src/db.js");
  const bossId = 8974234249;

  // 1. Existing user by username
  const u1Id = 99881177;
  await touchUser({ id: u1Id, username: "rohit_gamer" });
  const res1 = await grantBossTokens("@rohit_gamer", 100000, bossId);
  assert.equal(res1.ok, true);
  assert.equal(res1.status, "granted");
  assert.equal(res1.newBalance, 100000);

  // 2. Grant Infinity Tokens
  const resInf = await grantBossTokens("@rohit_gamer", "infinity", bossId);
  assert.equal(resInf.ok, true);
  assert.equal(resInf.newBalance, "infinity");

  // 3. Pending grant for user not yet seen in DB
  const resPending = await grantBossTokens("@new_friend_xyz", 50000, bossId);
  assert.equal(resPending.ok, true);
  assert.equal(resPending.status, "pending");

  // When user joins / sends message, pending tokens automatically claim
  const newUserId = 99881188;
  await touchUser({ id: newUserId, username: "new_friend_xyz" });
  const userRow = await getUserRow(newUserId);
  assert.equal(userRow?.points, 50000);
});


