import { spawnSync } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, readdirSync, unlinkSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { Bot, InputFile } from "grammy";
import { chatAllowed } from "./gate.js";
import { safeReply } from "./bot.js";
import { searchPhonk } from "./phonk.js";

const TMP_DIR = join(process.cwd(), ".tmp-audio");
if (!existsSync(TMP_DIR)) mkdirSync(TMP_DIR, { recursive: true });

export type AudioExtractResult = {
  data: Buffer;
  title: string;
  artist: string;
  thumbnailUrl?: string;
  duration: number;
};

/** Parse seconds from strings like "30", "00:45", "1:20" */
export function parseTimeInSeconds(val?: string | number): number {
  if (val === undefined || val === null) return 0;
  if (typeof val === "number") return Math.max(0, val);
  const s = String(val).trim();
  if (!s) return 0;
  if (/^\d+$/.test(s)) return Math.max(0, parseInt(s, 10));
  const parts = s.split(":").map(Number);
  if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
    return Math.max(0, parts[0] * 60 + parts[1]);
  }
  if (parts.length === 3 && !isNaN(parts[0]) && !isNaN(parts[1]) && !isNaN(parts[2])) {
    return Math.max(0, parts[0] * 3600 + parts[1] * 60 + parts[2]);
  }
  return 0;
}

/**
 * Download & extract audio from YouTube (via URL or search query) and cut to max 30s
 */
export async function extractAndCutYouTubeAudio(
  queryOrUrl: string,
  startSeconds = 0,
  durationSeconds = 30,
): Promise<AudioExtractResult | null> {
  const target = queryOrUrl.trim();
  if (!target) return null;

  // Max duration capped at 30 seconds as instructed by Boss
  const duration = Math.min(30, Math.max(1, durationSeconds || 30));
  const start = Math.max(0, startSeconds || 0);

  const isUrl = /^https?:\/\/(www\.)?(youtube\.com|youtu\.be|music\.youtube\.com)/i.test(target);
  const sourceParam = isUrl ? target : `ytsearch1:${target}`;
  const id = `cut_${Date.now()}_${Math.floor(Math.random() * 100000)}`;
  const outTemplate = join(TMP_DIR, `${id}.%(ext)s`);
  const finalMp3 = join(TMP_DIR, `${id}_trimmed.mp3`);

  try {
    // 1. Run yt-dlp to download best audio and get metadata
    const dl = spawnSync(
      "python",
      [
        "-m",
        "yt_dlp",
        "--no-warnings",
        "--no-simulate",
        "--print",
        "%(title)s",
        "--print",
        "%(uploader)s",
        "--print",
        "%(thumbnail)s",
        "-f",
        "ba[ext=m4a]/ba/b",
        "-o",
        outTemplate,
        sourceParam,
      ],
      { encoding: "utf-8", timeout: 45000 },
    );

    if (dl.status !== 0 || !dl.stdout) {
      console.warn("yt-dlp error:", dl.stderr || dl.stdout);
      return null;
    }

    const lines = dl.stdout.trim().split("\n").map((s) => s.trim());
    const title = lines[0] || target;
    const artist = lines[1] || "YouTube Audio";
    const thumbnailUrl = lines[2] && lines[2].startsWith("http") ? lines[2] : undefined;

    // 2. Find downloaded file
    const matched = readdirSync(TMP_DIR).filter((f) => f.startsWith(id) && !f.includes("_trimmed.mp3"));
    if (!matched.length) return null;
    const downloadedPath = join(TMP_DIR, matched[0]);

    // 3. Cut audio using ffmpeg with exact start and max 30s duration
    const cut = spawnSync(
      "ffmpeg",
      [
        "-y",
        "-ss",
        String(start),
        "-t",
        String(duration),
        "-i",
        downloadedPath,
        "-c:a",
        "libmp3lame",
        "-b:a",
        "192k",
        "-metadata",
        `title=${title}`,
        "-metadata",
        `artist=${artist}`,
        finalMp3,
      ],
      { timeout: 20000 },
    );

    // Clean up input file
    try {
      unlinkSync(downloadedPath);
    } catch {}

    if (cut.status !== 0 || !existsSync(finalMp3)) {
      console.error("ffmpeg cut error:", cut.stderr?.toString().slice(0, 200));
      return null;
    }

    const data = readFileSync(finalMp3);
    try {
      unlinkSync(finalMp3);
    } catch {}

    return {
      data,
      title,
      artist,
      thumbnailUrl,
      duration,
    };
  } catch (e: any) {
    console.error("extractAndCutYouTubeAudio exception:", e?.message ?? e);
    return null;
  }
}

/**
 * Trim any local/Telegram audio buffer to at most 30 seconds
 */
export function cutAudioBuffer(buffer: Buffer, startSeconds = 0, durationSeconds = 30): Buffer | null {
  const duration = Math.min(30, Math.max(1, durationSeconds || 30));
  const start = Math.max(0, startSeconds || 0);
  const id = `buf_${Date.now()}_${Math.floor(Math.random() * 100000)}`;
  const inPath = join(TMP_DIR, `${id}_in.bin`);
  const outPath = join(TMP_DIR, `${id}_out.mp3`);

  try {
    writeFileSync(inPath, buffer);
    const cut = spawnSync(
      "ffmpeg",
      ["-y", "-ss", String(start), "-t", String(duration), "-i", inPath, "-c:a", "libmp3lame", "-b:a", "192k", outPath],
      { timeout: 15000 },
    );

    try {
      unlinkSync(inPath);
    } catch {}

    if (cut.status !== 0 || !existsSync(outPath)) return null;
    const res = readFileSync(outPath);
    try {
      unlinkSync(outPath);
    } catch {}
    return res;
  } catch (e: any) {
    console.error("cutAudioBuffer error:", e?.message ?? e);
    return null;
  }
}

export function registerAudioEngine(bot: Bot) {
  // Command: /cut or /trim [start] [duration] (works on replied audio, voice, or video)
  bot.command(["cut", "trim", "audiocut"], async (ctx) => {
    if (!chatAllowed(ctx)) return;
    const replyMsg = ctx.message?.reply_to_message;
    const args = String(ctx.match ?? "").trim().split(/\s+/).filter(Boolean);
    const startSec = parseTimeInSeconds(args[0] ?? 0);
    const durationSec = Math.min(30, parseTimeInSeconds(args[1] ?? 30) || 30);

    const audioObj = replyMsg?.audio || replyMsg?.voice || replyMsg?.video;
    if (!audioObj) {
      return safeReply(
        ctx,
        `✂️ <b>Telegram Audio Cutter (Max 30s Cut)</b> 🎵\n\n` +
          `Kisi bhi audio, voice note ya video par reply karke likho:\n` +
          `👉 <code>/cut</code> — Pehle 30 seconds ka audio cut karega\n` +
          `👉 <code>/cut 15</code> — 15th second se shuru karke 30s cut karega\n` +
          `👉 <code>/cut 00:45 20</code> — 45s se shuru karke 20s ka audio cut karega!\n\n` +
          `⚡ <i>Audio file ke roop mein direct Telegram par deliver hoga!</i>`,
        { parse_mode: "HTML" },
      );
    }

    await ctx.replyWithChatAction("record_voice").catch(() => {});
    const waitMsg = await safeReply(ctx, "✂️ <i>Audio trim kiya ja raha hai (Max 30s cut)...</i> ⏳", { parse_mode: "HTML" });

    try {
      const file = await ctx.api.getFile(audioObj.file_id);
      const url = `https://api.telegram.org/file/bot${bot.token}/${file.file_path}`;
      const res = await fetch(url);
      const inBuffer = Buffer.from(await res.arrayBuffer());

      const cutData = cutAudioBuffer(inBuffer, startSec, durationSec);
      if (waitMsg?.message_id) await ctx.api.deleteMessage(ctx.chat.id, waitMsg.message_id).catch(() => {});

      if (!cutData) {
        return safeReply(ctx, "❌ Audio cut karne mein dikkat aayi. Format check karein.");
      }

      const origTitle = (audioObj as any).title || "Trimmed Audio";
      const origArtist = (audioObj as any).performer || ctx.from?.first_name || "Anayra Audio";

      await ctx.replyWithAudio(new InputFile(cutData, `${origTitle}.mp3`), {
        title: `${origTitle} (30s Cut)`,
        performer: origArtist,
        duration: durationSec,
        caption: `✂️ <b>Audio Cut Successful!</b> 🎵\n⏱️ <b>Trim:</b> ${startSec}s se lekar ${startSec + durationSec}s tak (Duration: ${durationSec}s)`,
        parse_mode: "HTML",
      });
    } catch (e: any) {
      console.error("cut command error:", e?.message ?? e);
      return safeReply(ctx, "❌ Audio download/trimming fail ho gayi.");
    }
  });

  // Command: /ytaudio or /ytdl or /ytmp3 <url|query> [start] [duration]
  bot.command(["ytaudio", "ytdl", "ytmp3", "yt"], async (ctx) => {
    if (!chatAllowed(ctx)) return;
    const parts = String(ctx.match ?? "").trim().split(/\s+/).filter(Boolean);
    if (!parts.length) {
      return safeReply(
        ctx,
        `🎧 <b>YouTube 30s Audio Extractor</b> ⚡\n\n` +
          `YouTube link ya gaane ka naam likhein:\n` +
          `👉 <code>/ytaudio https://youtu.be/...</code>\n` +
          `👉 <code>/ytaudio Close Eyes DVRST</code>\n` +
          `👉 <code>/ytaudio Close Eyes DVRST 30 30</code> (30th sec se 30s cut)\n\n` +
          `⚡ <i>Hamesha direct 30s MP3 audio file bhejega, video nahi!</i>`,
        { parse_mode: "HTML" },
      );
    }

    // Check if last two args are numbers (start & duration)
    let startSec = 0;
    let durationSec = 30;
    let queryParts = [...parts];

    if (queryParts.length >= 3 && /^\d+$/.test(queryParts[queryParts.length - 1]) && /^\d+$/.test(queryParts[queryParts.length - 2])) {
      durationSec = Math.min(30, parseInt(queryParts.pop()!, 10) || 30);
      startSec = parseInt(queryParts.pop()!, 10) || 0;
    } else if (queryParts.length >= 2 && /^\d+$/.test(queryParts[queryParts.length - 1])) {
      startSec = parseInt(queryParts.pop()!, 10) || 0;
    }
    const query = queryParts.join(" ");

    await ctx.replyWithChatAction("record_voice").catch(() => {});
    const waitMsg = await safeReply(ctx, `🎵 <i>YouTube se audio nikaal kar 30s cut kiya ja raha hai: "${query}"...</i> ⏳`, { parse_mode: "HTML" });

    const result = await extractAndCutYouTubeAudio(query, startSec, durationSec);

    if (waitMsg?.message_id) {
      await ctx.api.deleteMessage(ctx.chat.id, waitMsg.message_id).catch(() => {});
    }

    if (!result) {
      // Fallback to searchPhonk
      const fb = await searchPhonk(query);
      if (fb?.previewUrl) {
        return ctx.replyWithAudio(fb.previewUrl, {
          title: fb.title,
          performer: fb.artist,
          duration: 30,
          caption: `🎵 <b>${fb.title}</b> — ${fb.artist}\n⚡ <i>30s Preview Audio (Direct)</i>`,
          parse_mode: "HTML",
        });
      }
      return safeReply(ctx, `❌ YouTube par audio nahi mil saka ya download fail ho gaya: "${query}"`);
    }

    await ctx.replyWithAudio(new InputFile(result.data, `${result.title.replace(/[^\w\s-]/g, "")}.mp3`), {
      title: result.title,
      performer: result.artist,
      duration: result.duration,
      thumbnail: result.thumbnailUrl ? new InputFile({ url: result.thumbnailUrl }) : undefined,
      caption:
        `🎧 <b>${result.title}</b>\n` +
        `👤 <b>Artist:</b> ${result.artist}\n` +
        `⏱️ <b>Trimmed Clip:</b> ${startSec}s - ${startSec + result.duration}s (Max 30s cut)\n` +
        `⚡ <i>Audio file extracted from YouTube</i>`,
      parse_mode: "HTML",
    });
  });
}
