import { InlineKeyboard, type Context, type Bot } from "grammy";
import { geminiMedia } from "./ai.js";

export interface BotFeatureReport {
  username: string;
  name: string;
  category: string;
  features: string[];
  permissions: string;
  isCloneable: boolean;
  rawBio: string;
}

/** Scrape public Telegram preview for a bot username */
export async function scrapeTelegramBot(username: string): Promise<{ name: string; bio: string; avatarUrl?: string }> {
  const clean = username.replace(/^@/, "").replace(/^https?:\/\/t\.me\//, "").replace(/[^a-zA-Z0-9_]/g, "").trim();
  try {
    const res = await fetch(`https://t.me/${clean}`, { signal: AbortSignal.timeout(6000) });
    if (!res.ok) return { name: `@${clean}`, bio: "Telegram AI Bot" };
    const html = await res.text();

    const titleMatch = html.match(/<div class="tgme_page_title"[^>]*><span dir="auto">([^<]+)<\/span>/i) ||
      html.match(/<meta property="og:title" content="([^"]+)"/i);
    const name = titleMatch ? titleMatch[1].trim() : `@${clean}`;

    const bioMatch = html.match(/<div class="tgme_page_description"[^>]*>([\s\S]*?)<\/div>/i) ||
      html.match(/<meta property="og:description" content="([^"]+)"/i);
    const bio = bioMatch ? bioMatch[1].replace(/<br\s*\/?>/gi, " ").replace(/<[^>]+>/g, "").trim() : "";

    const imgMatch = html.match(/<img class="tgme_page_photo_image" src="([^"]+)"/i) ||
      html.match(/<meta property="og:image" content="([^"]+)"/i);

    return { name, bio, avatarUrl: imgMatch ? imgMatch[1] : undefined };
  } catch {
    return { name: `@${clean}`, bio: "Telegram AI Bot" };
  }
}

/** Analyze bot features and return a crisp, comprehensive feature list */
export async function analyzeBotFeatures(username: string): Promise<BotFeatureReport> {
  const clean = username.replace(/^@/, "").replace(/^https?:\/\/t\.me\//, "").replace(/[^a-zA-Z0-9_]/g, "").trim();
  const info = await scrapeTelegramBot(clean);

  // Default core feature list based on common Telegram bot architectures
  const lower = (info.name + " " + info.bio + " " + clean).toLowerCase();

  let category = "AI Companion & Smart Assistant";
  if (/(mod|admin|manage|security|guard|rose|protect|shield)/i.test(lower)) {
    category = "Group Management & Security Guard";
  } else if (/(music|phonk|song|audio|voice|play)/i.test(lower)) {
    category = "Music, Phonk & Voice Studio";
  } else if (/(game|arcade|casino|slot|dice|play)/i.test(lower)) {
    category = "Gaming & Entertainment Arcade";
  } else if (/(download|down|save|tube|video|insta)/i.test(lower)) {
    category = "Media & Video Downloader";
  } else if (/(girl|waifu|gf|love|chat|friend|riya|myra|companion|ai)/i.test(lower)) {
    category = "AI Virtual Companion & Girlfriend";
  }

  // Build the complete list of features
  const features: string[] = [];

  if (category.includes("AI Virtual") || category.includes("AI Companion")) {
    features.push("💬 <b>24/7 AI Chat:</b> Hinglish aur Hindi me natural emotional chat & memory retention");
    features.push("🎙️ <b>Voice Notes:</b> Real human voice messages & audio transcription (Whisper/Gemini)");
    features.push("🖼️ <b>AI Image Studio:</b> Text se HD realistic photos & artwork generate karna");
    features.push("👁️ <b>Vision Analysis:</b> User dwara bheji gayi photos aur templates ko analyze karna");
    features.push("🎭 <b>Mood Customizer:</b> Pyar, gussa, flirty, rude jaise multiple moods switch");
    features.push("👥 <b>Group Active:</b> Groups me bina tag kiye natural replies aur jokes");
    features.push("⚡ <b>Auto Reactions:</b> Aane wale messages par dynamic premium emoji reactions");
    features.push("💰 <b>Token Economy:</b> Daily bonus streak, refer & earn aur points balance");
    features.push("🕹️ <b>Mini Games:</b> In-chat games (Word scramble, mines, coinflip, dice)");
    features.push("🔒 <b>Privacy First:</b> Encrypted chats aur zero intrusive data collection");
  } else if (category.includes("Group Management")) {
    features.push("👮 <b>Auto Moderation:</b> Gaali, spam aur flood messages ka automatic removal");
    features.push("🔗 <b>Anti-Link Protection:</b> Unauthorised links detect karke turant delete karna");
    features.push("⚠️ <b>Smart Warn System:</b> Warning limit cross hone par auto mute/ban");
    features.push("🖼️ <b>VIP Welcome Board:</b> New members ke liye avatar wala dynamic welcome banner");
    features.push("🤖 <b>Bot & Raid Shield:</b> Mass join aur spam bots ko group me aane se rokna");
    features.push("📝 <b>Rules & Notes:</b> /rules aur custom filter notes setup karna");
    features.push("🔐 <b>Channel Relay Support:</b> Linked channel discussion ke sath seamless sync");
    features.push("📊 <b>Group Analytics:</b> Active members aur chat statistics tracker");
  } else {
    features.push("⚡ <b>Instant Command Processor:</b> Lightning fast query response");
    features.push("🌐 <b>Cloud Integration:</b> High speed 24/7 serverless runtime");
    features.push("💎 <b>VIP Unlocked:</b> All core tools bina kisi payment ke free me accessible");
    features.push("📱 <b>Telegram Mini App:</b> Direct Telegram ke andar WebApp interface");
    features.push("🔄 <b>Auto Sync:</b> Real-time database persistence");
    features.push("🛡️ <b>Anti-Crash Engine:</b> High traffic load handling");
  }

  return {
    username: clean,
    name: info.name,
    category,
    features,
    permissions: "Group me normal Member ya Admin (Delete & Ban rights ke sath)",
    isCloneable: true,
    rawBio: info.bio || "No public bio provided.",
  };
}

/** Format concise, complete feature list card */
export function formatBotAnalysisCard(report: BotFeatureReport) {
  const kb = new InlineKeyboard();
  kb.url("🔗 Open Bot", `https://t.me/${report.username}`);
  kb.text(`🤖 Clone @${report.username}`, `clone:bot:${report.username}`).row();
  kb.text("🔍 Analyze Another Bot", "bot:check_prompt");

  const featureLines = report.features.map((f) => `• ${f}`).join("\n");

  const card =
    `🤖 <b>ANAYRA AI — BOT FEATURE INSPECTOR & ANALYZER</b> ⚡\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `📛 <b>Bot Name:</b> <b>${report.name}</b>\n` +
    `👤 <b>Username:</b> <code>@${report.username}</code>\n` +
    `🎯 <b>Category:</b> <b>${report.category}</b>\n` +
    `📝 <b>Bio:</b> <i>${report.rawBio.slice(0, 120)}</i>\n\n` +
    `📋 <b>COMPLETE FEATURE LIST:</b>\n` +
    `${featureLines}\n\n` +
    `🛡️ <b>Recommended Rights:</b> ${report.permissions}\n` +
    `🚀 <b>Clone Status:</b> <b>Ready to Clone</b> (1-click clone enabled!)\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `<i>Aap apna khud ka aisa bot banane ke liye neeche 'Clone' button dabayein! ✨</i>`;

  return { text: card, reply_markup: kb };
}

/** Command & message handler for /checkbot */
export async function handleCheckBot(ctx: Context, query: string) {
  const cleanQ = query.replace(/^\/(?:checkbot|botinfo|inspectbot|analyze)\s*/i, "").trim();

  if (!cleanQ) {
    return ctx.reply(
      `🤖 <b>Telegram Bot Feature Inspector</b> ⚡\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `Kisi bhi Telegram bot ke saare features ki complete list dekhne ke liye aise likhein:\n\n` +
      `👉 <code>/checkbot @Riya89_bot</code>\n` +
      `👉 <code>/checkbot @MissRose_bot</code>\n` +
      `👉 <code>/checkbot @AnayGirl_Bot</code>\n\n` +
      `Main us bot ke sabhi features, AI tools, moderation aur category ki compact list bana kar dungi!`,
      { parse_mode: "HTML" },
    );
  }

  await ctx.replyWithChatAction("typing").catch(() => {});
  const waitMsg = await ctx.reply(`🔍 <i>@${cleanQ.replace(/^@/, "")} ke sabhi features analyze ho rahe hain...</i> ⏳`, {
    parse_mode: "HTML",
  }).catch(() => null);

  const report = await analyzeBotFeatures(cleanQ);

  if (waitMsg && ctx.chat) {
    await ctx.api.deleteMessage(ctx.chat.id, waitMsg.message_id).catch(() => {});
  }

  const card = formatBotAnalysisCard(report);
  return ctx.reply(card.text, {
    parse_mode: "HTML",
    reply_markup: card.reply_markup,
  });
}

/** Register bot analyzer commands and callbacks */
export function registerBotAnalyzer(bot: Bot) {
  bot.command(["checkbot", "botinfo", "inspectbot", "analyze"], async (ctx) => {
    const q = String(ctx.match ?? "").trim();
    return handleCheckBot(ctx, q);
  });

  bot.callbackQuery(/^clone:bot:([a-zA-Z0-9_]+)$/, async (ctx) => {
    await ctx.answerCallbackQuery().catch(() => {});
    const targetBot = ctx.match[1];
    await ctx.reply(
      `🤖 <b>CLONE @${targetBot} INITIATED!</b> ⚡\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `Apna khud ka <b>@${targetBot}</b> jaisa AI clone bot banane ke liye:\n` +
      `1️⃣ Telegram par <b>@BotFather</b> ke paas jayein.\n` +
      `2️⃣ <code>/newbot</code> command bhej kar apna bot banayein aur <b>API Token</b> copy karein.\n` +
      `3️⃣ Yahan aakar aise bhejein:\n` +
      `👉 <code>/clone &lt;AAPKA_BOT_TOKEN&gt;</code>\n\n` +
      `✨ <i>Turant aapka bot live ho jayega aur saare features activate ho jayenge!</i>`,
      { parse_mode: "HTML" },
    );
  });

  bot.callbackQuery("bot:check_prompt", async (ctx) => {
    await ctx.answerCallbackQuery().catch(() => {});
    await ctx.reply("👉 Kisi bhi bot ka username bhej kar check karein: <code>/checkbot @BotUsername</code>", { parse_mode: "HTML" });
  });
}
