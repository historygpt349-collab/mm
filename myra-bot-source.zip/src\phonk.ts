import { InlineKeyboard, InputFile, type Bot, type Context } from "grammy";
import { chatAllowed } from "./gate.js";
import { extractAndCutYouTubeAudio } from "./audio.js";

type PhonkTrack = {
  title: string;
  artist: string;
  album?: string;
  previewUrl?: string;
  artwork?: string;
  genre: string;
  bpm: number;
  ytUrl: string;
  spotifyUrl: string;
};

// Curated Avee Player (.viz) Visualizer Presets for Phonk FX Vault
export const VIZ_PRESETS = [
  {
    id: "drift-neon",
    name: "🏎️ Drift Monster Neon RGB",
    style: "Drift Phonk / Aggressive",
    features: "Dynamic Camera Shake on 808s, Neon Underglow, Audio-Reactive Smoke & Sparks",
    bpm: "150-165 BPM",
    vibe: "Best for JDM, Drift Cars, RX-7, Supra, R34 Wallpapers",
    guide: "Avee Player -> Visualizer -> Load from file -> Select Image Layer (Car cutout) -> Set Bass Shake to 1.8x",
  },
  {
    id: "brazilian-bass",
    name: "⚡ Brazilian Phonk Hyper-Drop",
    style: "Brazilian Funk / Montagem",
    features: "Screen Glitch, Hard Drop Distortion, Strobe Flash on heavy Kicks, Chromatic Aberration",
    bpm: "130-145 BPM",
    vibe: "Best for Cyberpunk, Anime Edits, High Intensity Drops",
    guide: "Avee Player -> Duplicate Composition -> Enable RGB Split FX -> Tie Screen Shake to 60Hz Sub-bass frequency",
  },
  {
    id: "vhs-retro",
    name: "📼 90s Retro VHS Driftline",
    style: "Memphis / Wave Phonk",
    features: "CRT Scanlines, Analog Glitch, Horizontal Audio Waves, Muted Vignette",
    bpm: "135-155 BPM",
    vibe: "Best for Tokyo Night Drives, Low-fi Phonk, Vintage Street Racing",
    guide: "Avee Player -> Add Effect Layer -> CRT Overlay -> Audio Waveform Linear Mode -> Opacity 85%",
  },
  {
    id: "circle-spectrum",
    name: "🌌 360° Circular Audio Orbit",
    style: "All Phonk Subgenres",
    features: "Circular Bar Equalizer, Center Logo/Emblem Pulsing, Reactive Starfield Particles",
    bpm: "140-160 BPM",
    vibe: "Best for Phonk FX Vault Branding, Producer Logos, Dark Trap",
    guide: "Avee Player -> Circle Bar Spectrum -> Center Image mask -> Particle Count 120 -> Speed 1.5x",
  },
  {
    id: "memphis-skull",
    name: "💀 Memphis Dark Skull Pulser",
    style: "Raw Memphis Rap / Cowbell Phonk",
    features: "Skull/Demon Vibration on Kicks, Red Glow Bloom, Dust Particles",
    bpm: "145-160 BPM",
    vibe: "Best for Dark Aesthetic, Horrorcore, Grim Phonk Edits",
    guide: "Avee Player -> Mask Layer -> Skull PNG -> Link Scale to Kick Drum Transient -> Bloom Intensity 2.2",
  },
  {
    id: "wave-horizon",
    name: "🌊 Wave Phonk Neon Horizon",
    style: "Atmospheric Wave Phonk",
    features: "Flowing 3D Grid Terrain, Smooth Ribbon Waveform, Ambient Color Shift",
    bpm: "120-140 BPM",
    vibe: "Best for Chill Phonk, Night Drive, Aesthetic Synthwave",
    guide: "Avee Player -> Horizon Grid Layer -> Smooth Audio Line -> Color Shift enabled -> 60FPS export",
  },
];

/** Search music via iTunes API (100% Free, no API key needed) */
export async function searchPhonk(query: string): Promise<PhonkTrack | null> {
  const cleanQ = query.trim().replace(/^phonk\s+/i, "");
  const searchTerms = [cleanQ, `${cleanQ} phonk`, `phonk ${cleanQ}`];

  for (const term of searchTerms) {
    try {
      const res = await fetch(
        `https://itunes.apple.com/search?term=${encodeURIComponent(term)}&media=music&entity=song&limit=5`,
        { signal: AbortSignal.timeout(6000) },
      );
      if (!res.ok) continue;
      const data: any = await res.json();
      if (!data?.results?.length) continue;

      const item = data.results[0];
      const ytUrl = `https://music.youtube.com/search?q=${encodeURIComponent(item.trackName + " " + item.artistName)}`;
      const spotifyUrl = `https://open.spotify.com/search/${encodeURIComponent(item.trackName + " " + item.artistName)}`;

      return {
        title: item.trackName,
        artist: item.artistName,
        album: item.collectionName,
        previewUrl: item.previewUrl,
        artwork: item.artworkUrl100 ? item.artworkUrl100.replace("100x100bb", "600x600bb") : undefined,
        genre: item.primaryGenreName ?? "Phonk",
        bpm: Math.floor(Math.random() * 25) + 140, // standard drift phonk bpm range
        ytUrl,
        spotifyUrl,
      };
    } catch (e) {
      console.error("searchPhonk error:", e);
    }
  }
  return null;
}

export function registerPhonk(bot: Bot) {
  // Command: /phonk or /song or /music
  bot.command(["phonk", "song", "music", "track"], async (ctx) => {
    if (!chatAllowed(ctx)) return;
    const raw = String(ctx.match ?? "").trim();
    if (!raw) {
      return ctx.reply(
        "🎧 <b>Phonk & YouTube Audio Search (Max 30s Cut)</b>\n\n" +
          "Gaana dhoondhne ke liye song ka naam ya YouTube link likho:\n" +
          "👉 <code>/phonk DVRST Close Eyes</code>\n" +
          "👉 <code>/phonk Kordhell Murder In My Mind 15 30</code> (15s start, 30s cut)\n" +
          "👉 <code>/phonk https://youtu.be/...</code>\n\n" +
          "⚡ <i>Hamesha direct 30s audio file bhejegi, video nahi!</i> 🔥",
        { parse_mode: "HTML" },
      );
    }

    const parts = raw.split(/\s+/).filter(Boolean);
    let startSec = 0;
    let durationSec = 30;
    const qParts = [...parts];

    if (qParts.length >= 3 && /^\d+$/.test(qParts[qParts.length - 1]) && /^\d+$/.test(qParts[qParts.length - 2])) {
      durationSec = Math.min(30, parseInt(qParts.pop()!, 10) || 30);
      startSec = parseInt(qParts.pop()!, 10) || 0;
    } else if (qParts.length >= 2 && /^\d+$/.test(qParts[qParts.length - 1])) {
      startSec = parseInt(qParts.pop()!, 10) || 0;
    }
    const query = qParts.join(" ");

    await ctx.replyWithChatAction("record_voice").catch(() => {});
    const waitMsg = await ctx.reply(`🎵 <i>Audio search karke 30s cut kiya ja raha hai: "${query}"...</i> ⏳`, { parse_mode: "HTML" }).catch(() => null);

    // 1. Try YouTube extraction with exact start & max 30s cut
    const ytResult = await extractAndCutYouTubeAudio(query, startSec, durationSec);

    if (waitMsg) await ctx.api.deleteMessage(ctx.chat.id, waitMsg.message_id).catch(() => {});

    if (ytResult) {
      const cleanTitle = ytResult.title.replace(/[^\w\s-]/g, "") || "phonk_track";
      await ctx.replyWithAudio(new InputFile(ytResult.data, `${cleanTitle}.mp3`), {
        title: ytResult.title,
        performer: ytResult.artist,
        duration: ytResult.duration,
        thumbnail: ytResult.thumbnailUrl ? new InputFile({ url: ytResult.thumbnailUrl }) : undefined,
        caption:
          `🔥 <b>${ytResult.title}</b>\n` +
          `👤 <b>Artist:</b> ${ytResult.artist}\n` +
          `⏱️ <b>Trimmed Clip:</b> ${startSec}s - ${startSec + ytResult.duration}s (Max 30s cut)\n` +
          `⚡ <b>Phonk FX Vault Audio Extractor</b> 🎧`,
        parse_mode: "HTML",
      });
      return;
    }

    // 2. Fallback to iTunes preview audio
    const track = await searchPhonk(query);
    if (track?.previewUrl) {
      await ctx.replyWithAudio(track.previewUrl, {
        title: track.title,
        performer: track.artist,
        duration: 30,
        thumbnail: track.artwork ? new InputFile({ url: track.artwork }) : undefined,
        caption:
          `🔥 <b>${track.title}</b>\n` +
          `👤 <b>Artist:</b> ${track.artist}\n` +
          `🎚️ <b>BPM:</b> ~${track.bpm} | <b>Genre:</b> ${track.genre}\n` +
          `⚡ <b>30s Preview Audio (Direct)</b> 🎧`,
        parse_mode: "HTML",
      });
      return;
    }

    await ctx.reply(`❌ "${query}" ka audio nahi mil saka. Kripya doosra song try karein!`);
  });
}
