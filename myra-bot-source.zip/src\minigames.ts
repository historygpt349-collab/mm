import { Bot, Context, InlineKeyboard } from "grammy";
import { addPoints, claimDailyBonus, getUserRow } from "./db.js";
import { safeReply } from "./bot.js";

// In-chat Flappy Bird Active Sessions: Map<chatId:userId, FlappySession>
type FlappySession = {
  userId: number;
  score: number;
  birdY: number; // 0 to 4
  pipes: { x: number; gapY: number }[]; // x: 0 to 7
  won: boolean;
  ended: boolean;
};
const activeFlappy = new Map<string, FlappySession>();

function renderFlappyBoard(s: FlappySession): string {
  const WIDTH = 9;
  const HEIGHT = 5;
  const grid: string[][] = Array.from({ length: HEIGHT }, () => Array(WIDTH).fill("⬛"));

  // Draw pipes
  for (const p of s.pipes) {
    if (p.x >= 0 && p.x < WIDTH) {
      for (let y = 0; y < HEIGHT; y++) {
        if (y !== p.gapY) {
          grid[y][p.x] = "🟩";
        }
      }
    }
  }

  // Draw bird
  const bx = 2;
  const by = Math.max(0, Math.min(HEIGHT - 1, s.birdY));
  grid[by][bx] = "🤖";

  const rows = grid.map((r) => r.join("")).join("\n");
  return (
    `🚀 <b>FLAPPY CYBER BIRD (स्लिपी बॉर्ड)</b> ⚡\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `${rows}\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `🏆 <b>Pipes Cleared:</b> <b>${s.score} / 10</b>\n` +
    `💰 <b>Target:</b> 10 Pipes paar karo aur <b>+10 Tokens</b> pao!\n` +
    (s.won ? `🎉 <b>CHAMPION! 10 Pipes paar ho gaye! +10 Tokens mil gaye! 💎</b>\n` : "") +
    (s.ended && !s.won ? `💥 <b>CRASHED!</b> Pipe se takkar ho gayi! Dobara koshish karein!\n` : "")
  );
}

export const getCyberArcadeUrl = () => {
  const base = (process.env.PUBLIC_URL || "https://myra-bot-88823.netlify.app").replace(/\/$/, "");
  return `${base}/index.html`;
};

function flappyKeyboard(s: FlappySession, isPrivate = true) {
  if (s.ended || s.won) {
    const kb = new InlineKeyboard().text("🔁 Play Again", `flp:restart:${s.userId}`);
    if (isPrivate) {
      kb.webApp("🕹️ Slippy Bot Arcade", getCyberArcadeUrl());
    } else {
      kb.text("📱 Fullscreen WebApp", "game:webapp");
    }
    return kb;
  }
  return new InlineKeyboard()
    .text("🚀 FLAP (Jump)", `flp:flap:${s.userId}`)
    .text("⏩ GLIDE", `flp:glide:${s.userId}`)
    .row()
    .text("❌ Exit Game", `flp:exit:${s.userId}`);
}

const TRIVIA_QUESTIONS = [
  {
    q: "Phonk music ka origin kahan hua tha?",
    opts: ["Memphis, Tennessee", "Tokyo, Japan", "Berlin, Germany", "London, UK"],
    ans: 0,
  },
  {
    q: "Avee Player mein visualizer file ka extension kya hota hai?",
    opts: [".viz", ".mp3", ".json", ".wav"],
    ans: 0,
  },
  {
    q: "Drift Phonk mein kaunsa musical instrument sabse iconic hota hai?",
    opts: ["Cowbell (808)", "Violin", "Flute", "Sitar"],
    ans: 0,
  },
  {
    q: "Cyberpunk genre ka primary visual color theme kya hai?",
    opts: ["Neon Blue & Pink", "Black & White", "Brown & Yellow", "Plain Grey"],
    ans: 0,
  },
  {
    q: "Telegram bots kis language se message communicate karte hain?",
    opts: ["HTTPS / Bot API", "Bluetooth", "FM Radio", "SMS"],
    ans: 0,
  },
];

// Minesweeper Session: Map<chatId:userId, MinesSession>
type MinesSession = {
  userId: number;
  bombs: Set<number>;
  revealed: Set<number>;
  pot: number;
  ended: boolean;
};
const activeMines = new Map<string, MinesSession>();

function renderMinesKeyboard(s: MinesSession, revealAll = false) {
  const kb = new InlineKeyboard();
  for (let i = 0; i < 9; i++) {
    let label = "❓";
    if (s.revealed.has(i)) {
      label = s.bombs.has(i) ? "💥" : "💎";
    } else if (revealAll) {
      label = s.bombs.has(i) ? "💥" : "💎";
    }
    kb.text(label, s.ended ? "noop" : `mine:cell:${i}:${s.userId}`);
    if (i % 3 === 2) kb.row();
  }
  if (!s.ended && s.pot > 0) {
    kb.text(`💰 Cash Out (+${s.pot} Tokens)`, `mine:cash:${s.userId}`).row();
  } else if (s.ended) {
    kb.text("🔁 Play Again", "game:mines").row();
  }
  return kb;
}

// Secret Number Vault Session: Map<chatId:userId, GuessSession>
type GuessSession = {
  userId: number;
  target: number;
  triesLeft: number;
  ended: boolean;
};
const activeGuess = new Map<string, GuessSession>();

function renderGuessKeyboard(s: GuessSession) {
  const kb = new InlineKeyboard();
  for (let i = 1; i <= 9; i++) {
    kb.text(`${i}`, s.ended ? "noop" : `guess:num:${i}:${s.userId}`);
    if (i % 3 === 0) kb.row();
  }
  if (s.ended) {
    kb.text("🔁 Play Again", "game:guess").row();
  }
  return kb;
}

// Scramble Word List
const SCRAMBLE_WORDS = [
  "PHONK", "DRIFT", "CYBER", "VISUAL", "MEMPHIS",
  "COWBELL", "SYNTH", "AVEE", "BASS", "TEMPO", "GROOVE", "NIGHT"
];

export function registerMiniGames(bot: Bot) {
  // 1. FREE DAILY BONUS (/claim, /bonus, /daily, /free, /dailyreward)
  bot.command(["claim", "bonus", "daily", "free", "dailyreward", "dailybonus"], async (ctx) => {
    const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
    if (isBoss) {
      return safeReply(
        ctx,
        `👑 <b>Supreme Boss Unlimited Treasury</b> ⚡\n\n` +
          `Aapke paas pehle se hi <b>∞ INFINITY TOKENS</b> hain, mere Maalik Boss! 🌹`,
        { parse_mode: "HTML" },
      );
    }

    const res = await claimDailyBonus(ctx.from!.id);
    if (!res.ok) {
      return safeReply(ctx, `⏳ <b>Daily Bonus:</b> ${res.reason}\n\nCheck balance: <code>/points</code>`, { parse_mode: "HTML" });
    }

    return safeReply(
      ctx,
      `🎉 <b>DAILY TOKEN BONUS CLAIMED!</b> 🎁\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `💰 <b>Bonus Credited:</b> <b>+${res.bonus} Tokens</b>\n` +
        `🔥 <b>Daily Streak:</b> ${res.streak} Day(s)\n` +
        `💎 <b>Total Balance:</b> ${res.balance} Tokens\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `<i>Kal phir aana aur agla bonus claim karna! Mauj karo! ✨</i>`,
      { parse_mode: "HTML" },
    );
  });

  // 2. IN-CHAT FLAPPY CYBER BIRD (/flappy, /bird)
  bot.command(["flappy", "bird", "slippy"], async (ctx) => {
    const userId = ctx.from!.id;
    const sessionKey = `${ctx.chat.id}:${userId}`;

    const session: FlappySession = {
      userId,
      score: 0,
      birdY: 2,
      pipes: [
        { x: 5, gapY: 2 },
        { x: 8, gapY: 3 },
      ],
      won: false,
      ended: false,
    };
    activeFlappy.set(sessionKey, session);

    const isPrivate = ctx.chat?.type === "private";
    await safeReply(ctx, renderFlappyBoard(session), {
      parse_mode: "HTML",
      reply_markup: flappyKeyboard(session, isPrivate),
    });
  });

  // 3. FLAPPY BUTTON CALLBACKS (Flap, Glide, Restart)
  bot.callbackQuery(/^flp:(flap|glide|restart|exit):(\d+)$/, async (ctx) => {
    const action = ctx.match[1];
    const targetUserId = Number(ctx.match[2]);

    if (ctx.from.id !== targetUserId) {
      return ctx.answerCallbackQuery("Ye aapka game nahi hai! Naya game shuru karne ke liye /flappy likhein.");
    }
    await ctx.answerCallbackQuery();

    const sessionKey = `${ctx.chat!.id}:${targetUserId}`;
    let s = activeFlappy.get(sessionKey);

    if (action === "restart" || !s) {
      s = {
        userId: targetUserId,
        score: 0,
        birdY: 2,
        pipes: [
          { x: 5, gapY: 2 },
          { x: 8, gapY: 3 },
        ],
        won: false,
        ended: false,
      };
      activeFlappy.set(sessionKey, s);
      const isPriv = ctx.chat?.type === "private";
      try {
        await ctx.editMessageText(renderFlappyBoard(s), { parse_mode: "HTML", reply_markup: flappyKeyboard(s, isPriv) });
      } catch {}
      return;
    }

    if (action === "exit") {
      activeFlappy.delete(sessionKey);
      try {
        await ctx.editMessageText("⏹️ <b>Flappy Bird Game band kar diya gaya.</b> Dobara khelne ke liye /flappy dabayein!", { parse_mode: "HTML" });
      } catch {}
      return;
    }

    if (s.ended || s.won) return;

    // Movement: Flap jumps up, Glide falls down with gravity
    if (action === "flap") {
      s.birdY = Math.max(0, s.birdY - 1);
    } else {
      s.birdY = Math.min(4, s.birdY + 1);
    }

    // Move pipes left
    for (const p of s.pipes) {
      p.x -= 1;
    }

    // Check collision or passed
    const birdX = 2;
    for (const p of s.pipes) {
      if (p.x === birdX) {
        if (s.birdY !== p.gapY) {
          // Crashed into pipe
          s.ended = true;
          break;
        } else {
          // Passed gap safely!
          s.score += 1;
          if (s.score >= 10 && !s.won) {
            s.won = true;
            s.ended = true;
            await addPoints(targetUserId, 10);
          }
        }
      }
    }

    // Remove offscreen pipes and spawn new ones
    s.pipes = s.pipes.filter((p) => p.x >= 0);
    if (!s.pipes.some((p) => p.x >= 6)) {
      const randomGap = Math.floor(Math.random() * 3) + 1; // 1, 2, or 3
      s.pipes.push({ x: 8, gapY: randomGap });
    }

    const isPriv = ctx.chat?.type === "private";
    try {
      await ctx.editMessageText(renderFlappyBoard(s), { parse_mode: "HTML", reply_markup: flappyKeyboard(s, isPriv) });
    } catch {}
  });

  // 4. LUCKY CYBER DICE (/dice, /roll)
  bot.command(["dice", "roll"], async (ctx) => {
    const userId = ctx.from!.id;
    const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);

    const d1 = Math.floor(Math.random() * 6) + 1;
    const d2 = Math.floor(Math.random() * 6) + 1;
    const d3 = Math.floor(Math.random() * 6) + 1;
    const total = d1 + d2 + d3;

    const won = total >= 12 || (d1 === d2 && d2 === d3);
    let rewardText = "";

    if (won) {
      const newBal = isBoss ? "∞ INFINITY" : await addPoints(userId, 10);
      rewardText =
        `🎉 <b>JEET GAYE! LUCKY ROLL!</b> ⚡\n` +
        `💰 <b>+10 Tokens</b> aapke wallet mein add ho gaye!\n` +
        `💎 <b>New Balance:</b> ${newBal} Tokens`;
    } else {
      rewardText = `Thoda chook gaye! 12+ total aane par 10 Tokens milte hain! Phir se try karein: <code>/dice</code>`;
    }

    return safeReply(
      ctx,
      `🎲 <b>CYBER LUCKY DICE ROLL</b> 🎲\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `🎯 <b>Results:</b> [ <b>${d1}</b> ] + [ <b>${d2}</b> ] + [ <b>${d3}</b> ]\n` +
        `📊 <b>Total Score:</b> <b>${total}</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `${rewardText}`,
      { parse_mode: "HTML" },
    );
  });

  // 5. CYBER TRIVIA SPEED QUIZ (/quiz, /trivia)
  bot.command(["quiz", "trivia"], async (ctx) => {
    const qIndex = Math.floor(Math.random() * TRIVIA_QUESTIONS.length);
    const item = TRIVIA_QUESTIONS[qIndex];

    const kb = new InlineKeyboard();
    item.opts.forEach((opt, idx) => {
      kb.text(opt, `qz:${qIndex}:${idx}:${ctx.from!.id}`).row();
    });

    return safeReply(
      ctx,
      `🧠 <b>CYBER SPEED TRIVIA</b> ⚡\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `❓ <b>Sawal:</b> <i>"${item.q}"</i>\n\n` +
        `💰 <i>Sahi jawab par <b>+10 Tokens</b> milenge! Neeche choose karein:</i>`,
      { parse_mode: "HTML", reply_markup: kb },
    );
  });

  bot.callbackQuery(/^qz:(\d+):(\d+):(\d+)$/, async (ctx) => {
    const qIndex = Number(ctx.match[1]);
    const chosen = Number(ctx.match[2]);
    const targetUserId = Number(ctx.match[3]);

    if (ctx.from.id !== targetUserId) {
      return ctx.answerCallbackQuery("Ye sawal aapke liye nahi tha! Naya sawal pane ke liye /quiz dabayein.");
    }
    await ctx.answerCallbackQuery();

    const item = TRIVIA_QUESTIONS[qIndex];
    if (!item) return;

    if (chosen === item.ans) {
      const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
      const newBal = isBoss ? "∞ INFINITY" : await addPoints(targetUserId, 10);
      try {
        await ctx.editMessageText(
          `🎉 <b>BILKUL SAHI JAWAB!</b> 🧠⚡\n\n` +
            `Sawal: <i>"${item.q}"</i>\n` +
            `Sahi Jawab: <b>${item.opts[item.ans]}</b> ✅\n\n` +
            `💰 <b>+10 Tokens</b> aapke account mein jud gaye!\n` +
            `💎 <b>Wallet:</b> ${newBal} Tokens\n\n` +
            `<i>Aur sawalon ke liye:</i> <code>/quiz</code>`,
          { parse_mode: "HTML" },
        );
      } catch {}
    } else {
      try {
        await ctx.editMessageText(
          `❌ <b>GALAT JAWAB!</b>\n\n` +
            `Sawal: <i>"${item.q}"</i>\n` +
            `Sahi Jawab tha: <b>${item.opts[item.ans]}</b>\n\n` +
            `<i>Koyi baat nahi, dobara koshish karein:</i> <code>/quiz</code>`,
          { parse_mode: "HTML" },
        );
      } catch {}
    }
  });

  // 6. CYBER SLOT MACHINE (/slot, /spin)
  const runSlotSpin = async (ctx: any, edit = false) => {
    const symbols = ["7️⃣", "💎", "👑", "⚡", "🍒", "🚀"];
    const r1 = symbols[Math.floor(Math.random() * symbols.length)];
    const r2 = symbols[Math.floor(Math.random() * symbols.length)];
    const r3 = symbols[Math.floor(Math.random() * symbols.length)];

    let win = 0;
    let title = "";
    if (r1 === r2 && r2 === r3) {
      if (r1 === "7️⃣") { win = 50; title = "🚨 <b>MEGA JACKPOT 777!</b> 🏆"; }
      else if (r1 === "💎" || r1 === "👑") { win = 25; title = "👑 <b>ROYAL DIAMOND MATCH!</b> 💎"; }
      else { win = 15; title = "✨ <b>TRIPLE SYMBOL MATCH!</b> 🎉"; }
    } else if (r1 === r2 || r2 === r3 || r1 === r3) {
      win = 5;
      title = "⚡ <b>LUCKY PAIR MATCH!</b> 🎁";
    } else {
      title = "<i>Thoda chook gaye! Ek baar aur koshish karein! 🎰</i>";
    }

    const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
    let newBal: any = null;
    if (win > 0) {
      newBal = isBoss ? "∞ INFINITY" : await addPoints(ctx.from.id, win);
    }

    const rewardMsg = win > 0
      ? `\n💰 <b>+${win} Tokens Credited!</b> (Balance: ${newBal} Tokens)`
      : "";

    const text =
      `🎰 <b>CYBER SLOT MACHINE</b> 🎰\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `       [  ${r1}  |  ${r2}  |  ${r3}  ]\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `${title}${rewardMsg}`;

    const kb = new InlineKeyboard()
      .text("🎰 Spin Again", `slot:spin:${ctx.from.id}`)
      .text("🎮 All Games", "game:hub");

    if (edit) {
      try {
        await ctx.editMessageText(text, { parse_mode: "HTML", reply_markup: kb });
      } catch {}
    } else {
      await safeReply(ctx, text, { parse_mode: "HTML", reply_markup: kb });
    }
  };

  bot.command(["slot", "spin"], async (ctx) => {
    await runSlotSpin(ctx, false);
  });
  bot.callbackQuery(/^slot:spin:(\d+)$/, async (ctx) => {
    if (ctx.from.id !== Number(ctx.match[1])) {
      return ctx.answerCallbackQuery("Ye aapka spin nahi hai! Naya spin shuru karein /slot se.");
    }
    await ctx.answerCallbackQuery();
    await runSlotSpin(ctx, true);
  });

  // 7. COIN FLIP (/flip, /coin, /headtail)
  bot.command(["flip", "coin", "headtail"], async (ctx) => {
    const kb = new InlineKeyboard()
      .text("🪙 Heads", `flip:h:${ctx.from!.id}`)
      .text("🦅 Tails", `flip:t:${ctx.from!.id}`)
      .row()
      .text("🎮 All Games", "game:hub");
    return safeReply(
      ctx,
      `🪙 <b>CYBER COIN FLIP</b> ⚡\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `Choose karein: <b>Heads</b> ya <b>Tails</b>?\n` +
        `💰 Sahi prediction par <b>+10 Tokens</b> milenge! 💎`,
      { parse_mode: "HTML", reply_markup: kb },
    );
  });

  bot.callbackQuery(/^flip:(h|t|retry):(\d+)$/, async (ctx) => {
    const act = ctx.match[1];
    const targetUserId = Number(ctx.match[2]);
    if (ctx.from.id !== targetUserId) {
      return ctx.answerCallbackQuery("Ye aapka toss nahi hai! /flip dabayein.");
    }
    await ctx.answerCallbackQuery();

    if (act === "retry") {
      const kb = new InlineKeyboard()
        .text("🪙 Heads", `flip:h:${targetUserId}`)
        .text("🦅 Tails", `flip:t:${targetUserId}`)
        .row()
        .text("🎮 All Games", "game:hub");
      try {
        await ctx.editMessageText(
          `🪙 <b>CYBER COIN FLIP</b> ⚡\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `Choose karein: <b>Heads</b> ya <b>Tails</b>?\n` +
            `💰 Sahi prediction par <b>+10 Tokens</b> milenge! 💎`,
          { parse_mode: "HTML", reply_markup: kb },
        );
      } catch {}
      return;
    }

    const outcome = Math.random() < 0.5 ? "h" : "t";
    const won = act === outcome;
    const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
    const newBal = won ? (isBoss ? "∞ INFINITY" : await addPoints(targetUserId, 10)) : null;

    const resText = won
      ? `🎉 <b>JEET GAYE! +10 Tokens Credited!</b> (Balance: ${newBal} Tokens)`
      : `❌ <i>Thoda chook gaye! Toss ka result tha: <b>${outcome === "h" ? "🪙 Heads" : "🦅 Tails"}</b></i>`;

    const kb = new InlineKeyboard()
      .text("🔁 Flip Again", `flip:retry:${targetUserId}`)
      .text("🎮 All Games", "game:hub");

    try {
      await ctx.editMessageText(
        `🪙 <b>COIN FLIP RESULT:</b> ${outcome === "h" ? "🪙 HEADS" : "🦅 TAILS"} ⚡\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `Aapki choice thi: <b>${act === "h" ? "Heads" : "Tails"}</b>\n\n` +
          `${resText}`,
        { parse_mode: "HTML", reply_markup: kb },
      );
    } catch {}
  });

  // 8. ROCK PAPER SCISSORS (/rps, /stone)
  bot.command(["rps", "stone"], async (ctx) => {
    const kb = new InlineKeyboard()
      .text("🪨 Rock", `rps:r:${ctx.from!.id}`)
      .text("📄 Paper", `rps:p:${ctx.from!.id}`)
      .text("✂️ Scissors", `rps:s:${ctx.from!.id}`)
      .row()
      .text("🎮 All Games", "game:hub");
    return safeReply(
      ctx,
      `🪨 <b>ROCK - PAPER - SCISSORS</b> ✂️\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `Apna move choose karein!\n` +
        `💰 Bot ko harane par <b>+10 Tokens</b> milenge! 💎`,
      { parse_mode: "HTML", reply_markup: kb },
    );
  });

  bot.callbackQuery(/^rps:(r|p|s|retry):(\d+)$/, async (ctx) => {
    const act = ctx.match[1];
    const targetUserId = Number(ctx.match[2]);
    if (ctx.from.id !== targetUserId) {
      return ctx.answerCallbackQuery("Ye aapka match nahi hai! /rps dabayein.");
    }
    await ctx.answerCallbackQuery();

    if (act === "retry") {
      const kb = new InlineKeyboard()
        .text("🪨 Rock", `rps:r:${targetUserId}`)
        .text("📄 Paper", `rps:p:${targetUserId}`)
        .text("✂️ Scissors", `rps:s:${targetUserId}`)
        .row()
        .text("🎮 All Games", "game:hub");
      try {
        await ctx.editMessageText(
          `🪨 <b>ROCK - PAPER - SCISSORS</b> ✂️\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `Apna move choose karein!\n` +
            `💰 Bot ko harane par <b>+10 Tokens</b> milenge! 💎`,
          { parse_mode: "HTML", reply_markup: kb },
        );
      } catch {}
      return;
    }

    const moves = ["r", "p", "s"];
    const botMove = moves[Math.floor(Math.random() * moves.length)];
    const names: Record<string, string> = { r: "🪨 Rock", p: "📄 Paper", s: "✂️ Scissors" };

    let outcome: "win" | "draw" | "lose";
    if (act === botMove) outcome = "draw";
    else if ((act === "r" && botMove === "s") || (act === "p" && botMove === "r") || (act === "s" && botMove === "p")) outcome = "win";
    else outcome = "lose";

    const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
    const newBal = outcome === "win" ? (isBoss ? "∞ INFINITY" : await addPoints(targetUserId, 10)) : null;

    let resMsg = "";
    if (outcome === "win") resMsg = `🎉 <b>CONGRATULATIONS! AAP JEET GAYE!</b> ⚡\n💰 <b>+10 Tokens Credited!</b> (Balance: ${newBal} Tokens)`;
    else if (outcome === "draw") resMsg = `🤝 <b>MATCH DRAW HO GAYA!</b> Dono ne same move chuna!`;
    else resMsg = `🤖 <b>Bot Jeet Gayi!</b> Phir se koshish karein!`;

    const kb = new InlineKeyboard()
      .text("🔁 Play Again", `rps:retry:${targetUserId}`)
      .text("🎮 All Games", "game:hub");

    try {
      await ctx.editMessageText(
        `🪨 <b>RPS BATTLE RESULT</b> ✂️\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `👤 <b>Aapka Move:</b> ${names[act]}\n` +
          `🤖 <b>Bot Ka Move:</b> ${names[botMove]}\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `${resMsg}`,
        { parse_mode: "HTML", reply_markup: kb },
      );
    } catch {}
  });

  // 9. CYBER MINESWEEPER (/mines, /bomb)
  bot.command(["mines", "bomb"], async (ctx) => {
    const userId = ctx.from!.id;
    const sessionKey = `${ctx.chat!.id}:${userId}`;
    const bombs = new Set<number>();
    while (bombs.size < 2) {
      bombs.add(Math.floor(Math.random() * 9));
    }
    const session: MinesSession = {
      userId,
      bombs,
      revealed: new Set(),
      pot: 0,
      ended: false,
    };
    activeMines.set(sessionKey, session);
    return safeReply(
      ctx,
      `💣 <b>CYBER MINESWEEPER (Bomb Defusal)</b> 💎\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `9 Cells mein se <b>2 Bombs 💥</b> chhupe hain aur <b>7 Crystals 💎</b>!\n` +
        `Har safe crystal par <b>+5 Tokens</b> pot mein judte hain.\n` +
        `Aap kisi bhi waqt <b>Cash Out</b> karke tokens le sakte hain!\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `💰 <b>Current Pot:</b> <b>0 Tokens</b>`,
      { parse_mode: "HTML", reply_markup: renderMinesKeyboard(session) },
    );
  });

  bot.callbackQuery(/^mine:(cell|cash):(\d+)(?::(\d+))?$/, async (ctx) => {
    const action = ctx.match[1];
    const targetUserId = action === "cell" ? Number(ctx.match[3]) : Number(ctx.match[2]);
    if (ctx.from.id !== targetUserId) {
      return ctx.answerCallbackQuery("Ye aapka Mines board nahi hai! Naya game shuru karein /mines se.");
    }
    await ctx.answerCallbackQuery();

    const sessionKey = `${ctx.chat!.id}:${targetUserId}`;
    const s = activeMines.get(sessionKey);
    if (!s || s.ended) return;

    if (action === "cash") {
      s.ended = true;
      const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
      const newBal = isBoss ? "∞ INFINITY" : await addPoints(targetUserId, s.pot);
      try {
        await ctx.editMessageText(
          `🎉 <b>CASH OUT SUCCESSFUL!</b> 💰⚡\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `Aapne safely <b>+${s.pot} Tokens</b> withdraw kar liye!\n` +
            `💎 <b>Wallet Balance:</b> ${newBal} Tokens\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `<i>Mauj karo aur dobara khelo!</i>`,
          { parse_mode: "HTML", reply_markup: renderMinesKeyboard(s, true) },
        );
      } catch {}
      return;
    }

    // Clicked cell
    const cellIdx = Number(ctx.match[2]);
    if (s.revealed.has(cellIdx)) return;

    if (s.bombs.has(cellIdx)) {
      // Hit a bomb!
      s.revealed.add(cellIdx);
      s.ended = true;
      s.pot = 0;
      try {
        await ctx.editMessageText(
          `💥 <b>BOOOOOM! BOMB DHAMAKA!</b> 💣\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `Aapka pair bomb par pad gaya! Saare pot tokens dharashayi ho gaye!\n` +
            `Dobara koshish karein aur smart cash out karein!`,
          { parse_mode: "HTML", reply_markup: renderMinesKeyboard(s, true) },
        );
      } catch {}
      return;
    }

    // Safe crystal!
    s.revealed.add(cellIdx);
    s.pot += 5;

    // Check if all 7 crystals opened
    if (s.revealed.size >= 7) {
      s.ended = true;
      const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
      const newBal = isBoss ? "∞ INFINITY" : await addPoints(targetUserId, 35);
      try {
        await ctx.editMessageText(
          `🏆 <b>ALL CRYSTALS FOUND! GRAND VICTORY!</b> 💎⚡\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `Aapne saare 7 Crystals dhoond liye bina kisi bomb ke!\n` +
            `💰 <b>+35 Tokens Credited!</b> (Balance: ${newBal} Tokens)\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━━━`,
          { parse_mode: "HTML", reply_markup: renderMinesKeyboard(s, true) },
        );
      } catch {}
      return;
    }

    try {
      await ctx.editMessageText(
        `💎 <b>SAFE CRYSTAL FOUND!</b> ✨\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `💰 <b>Current Pot:</b> <b>${s.pot} Tokens</b>\n` +
          `Agla cell chunein ya safe Cash Out karein!`,
        { parse_mode: "HTML", reply_markup: renderMinesKeyboard(s) },
      );
    } catch {}
  });

  // 10. SECRET NUMBER VAULT (/guess, /vault)
  bot.command(["guess", "vault"], async (ctx) => {
    const userId = ctx.from!.id;
    const sessionKey = `${ctx.chat!.id}:${userId}`;
    const target = Math.floor(Math.random() * 9) + 1; // 1 to 9
    const session: GuessSession = {
      userId,
      target,
      triesLeft: 3,
      ended: false,
    };
    activeGuess.set(sessionKey, session);
    return safeReply(
      ctx,
      `🔐 <b>CYBER VAULT: NUMBER GUESS</b> 🔢\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `Bot ne <b>1 se 9</b> ke beech ek secret number chuna hai!\n` +
        `Aapke paas <b>3 Tries</b> hain.\n` +
        `Sahi number guess karne par <b>+15 Tokens</b> milenge! 💎\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `🎯 <b>Tries Left:</b> 3\n` +
        `Neeche keypad se number choose karein:`,
      { parse_mode: "HTML", reply_markup: renderGuessKeyboard(session) },
    );
  });

  bot.callbackQuery(/^guess:num:(\d+):(\d+)$/, async (ctx) => {
    const chosen = Number(ctx.match[1]);
    const targetUserId = Number(ctx.match[2]);
    if (ctx.from.id !== targetUserId) {
      return ctx.answerCallbackQuery("Ye aapka vault nahi hai! Naya vault kholne ke liye /guess dabayein.");
    }
    await ctx.answerCallbackQuery();

    const sessionKey = `${ctx.chat!.id}:${targetUserId}`;
    const s = activeGuess.get(sessionKey);
    if (!s || s.ended) return;

    if (chosen === s.target) {
      s.ended = true;
      const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
      const newBal = isBoss ? "∞ INFINITY" : await addPoints(targetUserId, 15);
      try {
        await ctx.editMessageText(
          `🎉 <b>VAULT CRACKED! SAHI GUESS!</b> 🔓⚡\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `Secret code <b>[ ${s.target} ]</b> bilkul sahi tha!\n` +
            `💰 <b>+15 Tokens Credited!</b> (Balance: ${newBal} Tokens)\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━━━`,
          { parse_mode: "HTML", reply_markup: renderGuessKeyboard(s) },
        );
      } catch {}
      return;
    }

    s.triesLeft -= 1;
    if (s.triesLeft <= 0) {
      s.ended = true;
      try {
        await ctx.editMessageText(
          `🔒 <b>VAULT LOCKED! SAARI TRIES KHATAM!</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `Secret number tha: <b>[ ${s.target} ]</b>\n` +
            `Koyi baat nahi, dobara koshish karein: /guess`,
          { parse_mode: "HTML", reply_markup: renderGuessKeyboard(s) },
        );
      } catch {}
      return;
    }

    const hint = chosen < s.target ? "Secret number BADA hai (Higher ⬆️)!" : "Secret number CHHOTA hai (Lower ⬇️)!";
    try {
      await ctx.editMessageText(
        `🔐 <b>CYBER VAULT: HINT GIVEN!</b>\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `Aapka guess [ <b>${chosen}</b> ] tha.\n` +
          `💡 <i>${hint}</i>\n` +
          `🎯 <b>Tries Left:</b> <b>${s.triesLeft}</b>\n` +
          `Agla number choose karein:`,
        { parse_mode: "HTML", reply_markup: renderGuessKeyboard(s) },
      );
    } catch {}
  });

  // 11. CYBER WORD SCRAMBLE (/scramble, /wordgame)
  bot.command(["scramble", "wordgame"], async (ctx) => {
    const w = SCRAMBLE_WORDS[Math.floor(Math.random() * SCRAMBLE_WORDS.length)];
    const letters = w.split("");
    for (let i = letters.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [letters[i], letters[j]] = [letters[j], letters[i]];
    }
    const scrambled = letters.join(" ");

    const others = SCRAMBLE_WORDS.filter((x) => x !== w).sort(() => Math.random() - 0.5).slice(0, 3);
    const options = [w, ...others].sort(() => Math.random() - 0.5);

    const kb = new InlineKeyboard();
    options.forEach((opt) => {
      kb.text(opt, `scramble:ans:${opt === w ? "1" : "0"}:${w}:${ctx.from!.id}`).row();
    });
    kb.text("🎮 All Games", "game:hub");

    return safeReply(
      ctx,
      `🔤 <b>CYBER WORD SCRAMBLE</b> ⚡\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `In bikhare hue aksharon ko sahi word mein pehchano:\n\n` +
        `🔀 <b>[  ${scrambled}  ]</b>\n\n` +
        `💰 Sahi word chunne par <b>+10 Tokens</b> milenge!`,
      { parse_mode: "HTML", reply_markup: kb },
    );
  });

  bot.callbackQuery(/^scramble:ans:(1|0):(\w+):(\d+)$/, async (ctx) => {
    const isCorrect = ctx.match[1] === "1";
    const correctWord = ctx.match[2];
    const targetUserId = Number(ctx.match[3]);

    if (ctx.from.id !== targetUserId) {
      return ctx.answerCallbackQuery("Ye aapka scramble game nahi hai! /scramble dabayein.");
    }
    await ctx.answerCallbackQuery();

    const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
    const newBal = isCorrect ? (isBoss ? "∞ INFINITY" : await addPoints(targetUserId, 10)) : null;

    const resMsg = isCorrect
      ? `🎉 <b>BILKUL SAHI! WORD CRACKED!</b> ✅\nSahi Word: <b>${correctWord}</b>\n💰 <b>+10 Tokens Credited!</b> (Balance: ${newBal} Tokens)`
      : `❌ <b>GALAT WORD!</b>\nSahi Word tha: <b>${correctWord}</b>\nDobara koshish karein!`;

    const kb = new InlineKeyboard()
      .text("🔁 Next Word", "game:scramble")
      .text("🎮 All Games", "game:hub");

    try {
      await ctx.editMessageText(
        `🔤 <b>CYBER WORD SCRAMBLE RESULT</b>\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `${resMsg}`,
        { parse_mode: "HTML", reply_markup: kb },
      );
    } catch {}
  });

  // 12. ARCADE HUB (/play, /games, /arcade)
  const sendArcadeHub = async (ctx: any, edit = false) => {
    const isPrivate = ctx.chat?.type === "private";
    const botUser = ctx.me?.username || "AnayGirl_Bot";
    const url = getCyberArcadeUrl();

    const kb = new InlineKeyboard();
    if (isPrivate) {
      kb.webApp("🕹️ Open Comfy Slippy Bot Arcade (50 Levels)", url).row();
    } else {
      kb.url("🕹️ Open Comfy Slippy Bot Arcade (50 Levels)", `https://t.me/${botUser}?start=arcade`).row();
    }

    kb.text("🚀 Slippy Bird", "game:flappy")
      .text("🎰 Cyber Slot", "game:slot")
      .row()
      .text("🪙 Coin Flip", "game:flip")
      .text("🪨 Rock-Paper-Scissors", "game:rps")
      .row()
      .text("💣 Minesweeper", "game:mines")
      .text("🔐 Secret Vault", "game:guess")
      .row()
      .text("🎲 Lucky Dice", "game:dice")
      .text("🧠 Cyber Quiz", "game:quiz")
      .row()
      .text("🔤 Word Scramble", "game:scramble")
      .text("🎁 Daily +10 Bonus", "game:daily")
      .row();

    if (isPrivate) {
      kb.webApp("📱 Fullscreen Slippy Arcade", url);
    } else {
      kb.text("📱 Fullscreen WebApp Info", "game:webapp");
    }

    const text =
      `🕹️ <b>COMFY SLIPPY BOT ARCADE & FREE EARNINGS</b> ✨\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `Slippy Bot ke sath 6 alag-alag Mazedaar Brain & Arcade games khelein — har game ke <b>50 Levels</b>!\n\n` +
      `🔥 <b>6 SLIPPY ARCADE GAMES (50 LEVELS EACH):</b>\n` +
      `• 🚀 <b>Slippy Bird:</b> Bouncy flying adventure with 50 levels\n` +
      `• 🧩 <b>Slippy 2048 Fusion:</b> Smooth tile merging numbers puzzle\n` +
      `• 🧠 <b>Memory Matrix:</b> Chime memory sequence reflex\n` +
      `• ⚡ <b>Speed Math Rush:</b> Rapid-fire brain calculations\n` +
      `• 💎 <b>Crystal Vault:</b> Minesweeper crystal hunting & cash out\n` +
      `• 🐍 <b>Cozy Snake Rush:</b> Classic retro fruit-eating snake\n\n` +
      `🕹️ <b>IN-CHAT MINI GAMES:</b>\n` +
      `1. 🚀 <b>Slippy Bird (/flappy):</b> 10 Pipes paar karo = <b>+10 Tokens</b>\n` +
      `2. 🎰 <b>Cyber Slot (/slot):</b> 777 Jackpot par = <b>+50 Tokens</b>\n` +
      `3. 🪙 <b>Coin Flip (/flip):</b> Heads ya Tails jeeto = <b>+10 Tokens</b>\n` +
      `4. 🪨 <b>RPS Battle (/rps):</b> Bot ko harao = <b>+10 Tokens</b>\n` +
      `5. 💣 <b>Minesweeper (/mines):</b> Crystals chuno aur Cash Out = <b>+35 Tokens tak</b>\n` +
      `6. 🔐 <b>Secret Vault (/guess):</b> 1-9 Secret code crack = <b>+15 Tokens</b>\n` +
      `7. 🎲 <b>Lucky Dice (/dice):</b> 12+ score par = <b>+10 Tokens</b>\n` +
      `8. 🧠 <b>Cyber Quiz (/quiz):</b> Speed sawalon ke jawab = <b>+10 Tokens</b>\n` +
      `9. 🔤 <b>Word Scramble (/scramble):</b> Phonk words pehchano = <b>+10 Tokens</b>\n` +
      `10. 🎁 <b>Daily Bonus (/claim):</b> Har 24h mein free <b>+10 Tokens</b>\n` +
      `11. 💬 <b>Group Chat Activity:</b> Group me chat par <b>+1 Token</b> per msg\n\n` +
      `<i>Neeche diye button se WebApp ya In-Chat Game shuru karein:</i>`;

    if (edit) {
      try {
        await ctx.editMessageText(text, { parse_mode: "HTML", reply_markup: kb });
      } catch {}
    } else {
      await safeReply(ctx, text, { parse_mode: "HTML", reply_markup: kb });
    }
  };

  bot.command(["games", "arcade", "play"], async (ctx) => {
    await sendArcadeHub(ctx, false);
  });
  bot.callbackQuery(["game:hub", "menu:games"], async (ctx) => {
    await ctx.answerCallbackQuery();
    await sendArcadeHub(ctx, true);
  });

  // Direct arcade launchers
  bot.callbackQuery("game:slot", async (ctx) => {
    await ctx.answerCallbackQuery();
    await runSlotSpin(ctx, true);
  });
  bot.callbackQuery("game:flip", async (ctx) => {
    await ctx.answerCallbackQuery();
    const kb = new InlineKeyboard()
      .text("🪙 Heads", `flip:h:${ctx.from.id}`)
      .text("🦅 Tails", `flip:t:${ctx.from.id}`)
      .row()
      .text("🎮 All Games", "game:hub");
    try {
      await ctx.editMessageText(
        `🪙 <b>CYBER COIN FLIP</b> ⚡\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `Choose karein: <b>Heads</b> ya <b>Tails</b>?\n` +
          `💰 Sahi prediction par <b>+10 Tokens</b> milenge! 💎`,
        { parse_mode: "HTML", reply_markup: kb },
      );
    } catch {}
  });
  bot.callbackQuery("game:rps", async (ctx) => {
    await ctx.answerCallbackQuery();
    const kb = new InlineKeyboard()
      .text("🪨 Rock", `rps:r:${ctx.from.id}`)
      .text("📄 Paper", `rps:p:${ctx.from.id}`)
      .text("✂️ Scissors", `rps:s:${ctx.from.id}`)
      .row()
      .text("🎮 All Games", "game:hub");
    try {
      await ctx.editMessageText(
        `🪨 <b>ROCK - PAPER - SCISSORS</b> ✂️\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `Apna move choose karein!\n` +
          `💰 Bot ko harane par <b>+10 Tokens</b> milenge! 💎`,
        { parse_mode: "HTML", reply_markup: kb },
      );
    } catch {}
  });
  bot.callbackQuery("game:mines", async (ctx) => {
    await ctx.answerCallbackQuery();
    const userId = ctx.from.id;
    const sessionKey = `${ctx.chat!.id}:${userId}`;
    const bombs = new Set<number>();
    while (bombs.size < 2) {
      bombs.add(Math.floor(Math.random() * 9));
    }
    const session: MinesSession = {
      userId,
      bombs,
      revealed: new Set(),
      pot: 0,
      ended: false,
    };
    activeMines.set(sessionKey, session);
    try {
      await ctx.editMessageText(
        `💣 <b>CYBER MINESWEEPER (Bomb Defusal)</b> 💎\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `9 Cells mein se <b>2 Bombs 💥</b> chhupe hain aur <b>7 Crystals 💎</b>!\n` +
          `Har safe crystal par <b>+5 Tokens</b> pot mein judte hain.\n` +
          `Aap kisi bhi waqt <b>Cash Out</b> karke tokens le sakte hain!\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `💰 <b>Current Pot:</b> <b>0 Tokens</b>`,
        { parse_mode: "HTML", reply_markup: renderMinesKeyboard(session) },
      );
    } catch {}
  });
  bot.callbackQuery("game:guess", async (ctx) => {
    await ctx.answerCallbackQuery();
    const userId = ctx.from.id;
    const sessionKey = `${ctx.chat!.id}:${userId}`;
    const target = Math.floor(Math.random() * 9) + 1;
    const session: GuessSession = {
      userId,
      target,
      triesLeft: 3,
      ended: false,
    };
    activeGuess.set(sessionKey, session);
    try {
      await ctx.editMessageText(
        `🔐 <b>CYBER VAULT: NUMBER GUESS</b> 🔢\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `Bot ne <b>1 se 9</b> ke beech ek secret number chuna hai!\n` +
          `Aapke paas <b>3 Tries</b> hain.\n` +
          `Sahi number guess karne par <b>+15 Tokens</b> milenge! 💎\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `🎯 <b>Tries Left:</b> 3\n` +
          `Neeche keypad se number choose karein:`,
        { parse_mode: "HTML", reply_markup: renderGuessKeyboard(session) },
      );
    } catch {}
  });
  bot.callbackQuery("game:scramble", async (ctx) => {
    await ctx.answerCallbackQuery();
    const w = SCRAMBLE_WORDS[Math.floor(Math.random() * SCRAMBLE_WORDS.length)];
    const letters = w.split("");
    for (let i = letters.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [letters[i], letters[j]] = [letters[j], letters[i]];
    }
    const scrambled = letters.join(" ");
    const others = SCRAMBLE_WORDS.filter((x) => x !== w).sort(() => Math.random() - 0.5).slice(0, 3);
    const options = [w, ...others].sort(() => Math.random() - 0.5);

    const kb = new InlineKeyboard();
    options.forEach((opt) => {
      kb.text(opt, `scramble:ans:${opt === w ? "1" : "0"}:${w}:${ctx.from.id}`).row();
    });
    kb.text("🎮 All Games", "game:hub");

    try {
      await ctx.editMessageText(
        `🔤 <b>CYBER WORD SCRAMBLE</b> ⚡\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `In bikhare hue aksharon ko sahi word mein pehchano:\n\n` +
          `🔀 <b>[  ${scrambled}  ]</b>\n\n` +
          `💰 Sahi word chunne par <b>+10 Tokens</b> milenge!`,
        { parse_mode: "HTML", reply_markup: kb },
      );
    } catch {}
  });
  bot.callbackQuery("game:flappy", async (ctx) => {
    await ctx.answerCallbackQuery();
    const userId = ctx.from.id;
    const sessionKey = `${ctx.chat!.id}:${userId}`;
    const session: FlappySession = {
      userId,
      score: 0,
      birdY: 2,
      pipes: [
        { x: 5, gapY: 2 },
        { x: 8, gapY: 3 },
      ],
      won: false,
      ended: false,
    };
    activeFlappy.set(sessionKey, session);
    await safeReply(ctx, renderFlappyBoard(session), {
      parse_mode: "HTML",
      reply_markup: flappyKeyboard(session),
    });
  });

  bot.callbackQuery("game:dice", async (ctx) => {
    await ctx.answerCallbackQuery();
    const d1 = Math.floor(Math.random() * 6) + 1;
    const d2 = Math.floor(Math.random() * 6) + 1;
    const d3 = Math.floor(Math.random() * 6) + 1;
    const total = d1 + d2 + d3;
    const won = total >= 12 || (d1 === d2 && d2 === d3);
    const newBal = won ? await addPoints(ctx.from.id, 10) : null;

    const resText = won
      ? `🎉 <b>JEET GAYE! +10 Tokens Credited!</b> (Balance: ${newBal})`
      : `Thoda chook gaye! Total ${total} aaya. Phir try karein!`;

    await safeReply(
      ctx,
      `🎲 <b>Dice Roll:</b> [ ${d1} ] + [ ${d2} ] + [ ${d3} ] = <b>${total}</b>\n${resText}`,
      { parse_mode: "HTML" },
    );
  });

  bot.callbackQuery("game:quiz", async (ctx) => {
    await ctx.answerCallbackQuery();
    const qIndex = Math.floor(Math.random() * TRIVIA_QUESTIONS.length);
    const item = TRIVIA_QUESTIONS[qIndex];
    const kb = new InlineKeyboard();
    item.opts.forEach((opt, idx) => {
      kb.text(opt, `qz:${qIndex}:${idx}:${ctx.from.id}`).row();
    });
    await safeReply(
      ctx,
      `🧠 <b>CYBER SPEED TRIVIA</b> ⚡\n\n` +
        `❓ <i>"${item.q}"</i>\n\n` +
        `💰 <i>Sahi jawab par <b>+10 Tokens</b> milenge!</i>`,
      { parse_mode: "HTML", reply_markup: kb },
    );
  });

  bot.callbackQuery("game:daily", async (ctx) => {
    await ctx.answerCallbackQuery();
    const res = await claimDailyBonus(ctx.from.id);
    if (!res.ok) {
      return safeReply(ctx, `⏳ ${res.reason}`);
    }
    await safeReply(
      ctx,
      `🎁 <b>DAILY BONUS CLAIMED!</b>\n` +
        `💰 <b>+${res.bonus} Tokens</b> add ho gaye! (Balance: ${res.balance} Tokens, Streak: ${res.streak} Days) ✨`,
    );
  });

  bot.callbackQuery("game:webapp", async (ctx) => {
    await ctx.answerCallbackQuery();
    const url = getCyberArcadeUrl();
    const isPrivate = ctx.chat?.type === "private";
    const botUser = ctx.me?.username || "AnayGirl_Bot";

    const kb = new InlineKeyboard();
    if (isPrivate) {
      kb.webApp("🕹️ Open Comfy Slippy Bot Arcade (50 Levels)", url).row();
    } else {
      kb.url("🕹️ Open Comfy Slippy Bot Arcade (50 Levels)", `https://t.me/${botUser}?start=arcade`).row();
    }
    kb.text("🔙 Back to Games", "game:hub");

    await safeReply(
      ctx,
      `🕹️ <b>COMFY SLIPPY BOT ARCADE (WEBAPP)</b> ✨\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `Slippy Bot ke sath 6 alag-alag Mazedaar Brain & Arcade games khelein — har game ke <b>50 Levels</b>!\n\n` +
        `🔥 <b>6 SLIPPY ARCADE GAMES (50 LEVELS EACH):</b>\n` +
        `1. 🚀 <b>Slippy Bird:</b> 50 Levels of bouncy flying fun!\n` +
        `2. 🧩 <b>Slippy 2048 Fusion:</b> 50 Levels of number merging puzzle\n` +
        `3. 🧠 <b>Memory Matrix:</b> 50 Levels of musical pattern memory\n` +
        `4. ⚡ <b>Speed Math Rush:</b> 50 Levels of rapid mental arithmetic\n` +
        `5. 💎 <b>Crystal Vault:</b> 50 Levels of crystal hunting & cash out\n` +
        `6. 🐍 <b>Cozy Snake Rush:</b> 50 Levels of retro fruit-eating snake\n\n` +
        `💰 <b>Rewards:</b> Har level paar karne par tokens jeeto aur direct Anayra wallet mein claim karo!\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `<i>Neeche diye button par tap karke WebApp launch karein:</i>`,
      { parse_mode: "HTML", reply_markup: kb },
    );
  });

  bot.command(["app", "webapp", "slippy"], async (ctx) => {
    const url = getCyberArcadeUrl();
    const isPrivate = ctx.chat?.type === "private";
    const botUser = ctx.me?.username || "AnayGirl_Bot";

    const kb = new InlineKeyboard();
    if (isPrivate) {
      kb.webApp("🕹️ Open Comfy Slippy Bot Arcade (50 Levels)", url);
    } else {
      kb.url("🕹️ Open Comfy Slippy Bot Arcade (50 Levels)", `https://t.me/${botUser}?start=arcade`);
    }

    return safeReply(
      ctx,
      `🕹️ <b>COMFY SLIPPY BOT ARCADE (WEBAPP)</b> ✨\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `Real Telegram WebApp mein 6 alag-alag brain aur arcade games khel kar direct tokens jeetein!\n\n` +
        `1. 🚀 <b>Slippy Bird:</b> 50 Levels\n` +
        `2. 🧩 <b>Slippy 2048 Fusion:</b> 50 Levels\n` +
        `3. 🧠 <b>Memory Matrix:</b> 50 Levels\n` +
        `4. ⚡ <b>Speed Math Rush:</b> 50 Levels\n` +
        `5. 💎 <b>Crystal Vault:</b> 50 Levels\n` +
        `6. 🐍 <b>Cozy Snake Rush:</b> 50 Levels\n\n` +
        `<i>Neeche diye button se WebApp kholiye:</i>`,
      { parse_mode: "HTML", reply_markup: kb },
    );
  });

  // 13. TELEGRAM MINI APP DATA LISTENER (when player claims from WebApp)
  bot.on("message:web_app_data", async (ctx) => {
    try {
      const raw = ctx.message.web_app_data.data;
      const data = JSON.parse(raw);
      if (data.won) {
        const reward = Number(data.tokens) || 10;
        const newBal = await addPoints(ctx.from.id, reward);
        const gameTitles: Record<string, string> = {
          bird: "🚀 Slippy Bird",
          flappy: "🚀 Slippy Bird",
          simon: "🧠 Memory Matrix",
          math: "⚡ Speed Math Rush",
          g2048: "🧩 Slippy 2048 Fusion",
          mines: "💎 Crystal Vault",
          snake: "🐍 Cozy Snake Rush",
        };
        const title = gameTitles[data.game] || data.game;
        await safeReply(
          ctx,
          `🎉 <b>CONGRATULATIONS CHAMPION!</b> 🕹️✨\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `🎮 <b>Game:</b> ${title}\n` +
            `🏆 <b>Level:</b> ${data.level || data.score} Cleared!\n` +
            `💰 <b>Reward:</b> <b>+${reward} Tokens</b> credited to your wallet!\n` +
            `💎 <b>New Balance:</b> ${newBal} Tokens\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `<i>Aise hi agla level khele aur tokens kamate rahein!</i> 🎁`,
          { parse_mode: "HTML" },
        );
      }
    } catch (e) {
      console.error("web_app_data parse error:", e);
    }
  });
}

