import { InlineKeyboard, type Bot, type Context } from "grammy";
import {
  DAILY_ACTIVITY_CAP,
  REF_POINTS,
  WELCOME_POINTS,
  activityPoint,
  buyReaction,
  buyVip,
  buyWelcomePass,
  canClaimDailyBonus,
  createTokenRequest,
  deductPoints,
  getTokenRequest,
  leaderboard,
  profile,
  resolveTokenRequest,
  setMood,
  setReferrer,
} from "./db.js";

const who = (u: { first_name: string | null; username: string | null; id: number }) =>
  u.username ? `@${u.username}` : u.first_name ?? String(u.id);

export function referralLink(botUsername: string | undefined, userId: number) {
  return `https://t.me/${botUsername}?start=ref_${userId}`;
}

export async function referText(botUsername: string | undefined, userId: number) {
  const isBoss = process.env.OWNER_ID && String(userId) === String(process.env.OWNER_ID);
  const p = await profile(userId);
  return (
    `🎁 <b>Dosto ko Lao, Tokens Kamao!</b>\n\n` +
    `🔗 <b>Aapka Personal Referral Link:</b>\n` +
    `<code>${referralLink(botUsername, userId)}</code>\n\n` +
    `⚡ <b>Rules & Earning:</b>\n` +
    `• Jo bhi dost aapke link se judega, aapko <b>+${REF_POINTS} Tokens</b> milenge!\n` +
    `• Aapke dost ko bhi <b>+${WELCOME_POINTS} Welcome Tokens</b> milenge!\n` +
    `• Group me chat karne par har message par <b>+1 Token</b> (Daily limit: ${DAILY_ACTIVITY_CAP})!\n\n` +
    `👥 <b>Aapke Total Referrals:</b> ${p.referrals} dost\n` +
    `💰 <b>Aapka Token Balance:</b> ${isBoss ? "<b>∞ INFINITY TOKENS</b>" : `${p.points} Tokens`}\n\n` +
    `🛍️ <i>Tokens se features use karne ke liye</i> <code>/shop</code> <i>dabayein!</i>`
  );
}

export async function pointsText(userId: number) {
  const isBoss = process.env.OWNER_ID && String(userId) === String(process.env.OWNER_ID);
  if (isBoss) {
    return (
      `👑 <b>[ROYAL CREATOR & OWNER DOMAIN]</b> ⚡\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `👤 <b>Maalik:</b> Supreme Boss (ID: <code>${userId}</code>)\n` +
      `💰 <b>Token Balance:</b> <b>∞ INFINITY TOKENS</b>\n` +
      `⚡ <b>Privileges:</b> 100% Free Unlimited Access to ALL Features\n` +
      `👑 <b>Role:</b> Supreme Creator & Empire Owner\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `<i>🌹 Hukum kijiye Boss, aapka khazana aparampaar hai!</i>`
    );
  }
  const p = await profile(userId);
  const canClaim = await canClaimDailyBonus(userId);
  const bonusPrompt = canClaim
    ? `🎁 <b>DAILY FREE BONUS READY!</b>\n👉 <code>/claim</code> dabayein aur free <b>+10 Tokens</b> paayein! ✨\n\n`
    : `✅ <i>Aaj ka daily bonus claim ho chuka hai (Kal dobara milega).</i>\n\n`;

  const balanceDisplay = p.is_infinity ? "<b>∞ INFINITY TOKENS</b>" : `<b>${p.points} Tokens</b>`;

  return (
    `🏆 <b>Aapka Wallet & Profile Status</b>\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `💰 <b>Total Tokens:</b> ${balanceDisplay}\n` +
    `📈 <b>Leaderboard Rank:</b> ${p.rank ? "#" + p.rank : "Abhi rank nahi hai (tokens kamao!)"}\n` +
    `💎 <b>Auto Reaction:</b> ${p.vip_reaction ? p.vip_reaction : "Default (Free: /myreact)"}\n` +
    `🎭 <b>Anayra Mood:</b> ${p.mood}\n` +
    `👥 <b>Invited Friends:</b> ${p.referrals} log (+${p.referrals * REF_POINTS} Tokens earned)\n\n` +
    bonusPrompt +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `⭐ <b>PREMIUM TOKEN STORE (/shop):</b>\n` +
    `• 🎨 <b>AI Image Studio:</b> <code>/image &lt;prompt&gt;</code> — 5 Tokens\n` +
    `• 🖼️ <b>Group Welcome Board Pass:</b> <code>/buywelcome</code> — 20 Tokens (Lifetime automated cyberpunk banners!)\n` +
    `• 🤖 <b>Bot Cloner:</b> <code>/clone &lt;token&gt;</code> — 50 Tokens\n` +
    `• 💎 <b>VIP Member Badge:</b> <code>/buyvip</code> — 50 Tokens\n` +
    `• 📬 <b>Boss se Tokens Mangein:</b> <code>/requesttokens &lt;amount&gt; [reason]</code>\n\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `✨ <b>100% FREE FEATURES (Sabke Liye Free):</b>\n` +
    `• 💎 Auto Reaction: <code>/myreact &lt;emoji&gt;</code> (100% Free!)\n` +
    `• 🎧 Phonk Music Finder: <code>/phonk</code> (100% Free!)\n` +
    `• 🎨 Avee Player Visualizers: <code>/viz</code> (100% Free!)\n` +
    `• 🤖 Bot Feature Inspector: <code>/checkbot &lt;@bot&gt;</code> (100% Free!)\n` +
    `• 💌 Girlfriend Shayari & Flirt: <code>/shayari</code>, <code>/flirt</code>\n` +
    `• 🎭 Girlfriend Moods: <code>/setmood</code> (100% Free!)\n` +
    `• 💬 Unlimited Sassy AI Girlfriend Chat\n\n` +
    `👉 <i>Dosto ko invite karke tokens pao:</i> <code>/refer</code>`
  );
}

export function shopText(points: number, isBoss = false) {
  return (
    `🛍️ <b>ANAYRA PREMIUM STORE & REWARDS</b> 💎\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `💰 <b>Aapka Current Balance:</b> ${isBoss ? "<b>∞ INFINITY TOKENS (Supreme Boss)</b>" : `<b>${points} Tokens</b>`}\n\n` +
    `💎 <b>PREMIUM TOKEN EXCHANGE:</b>\n` +
    `• 🎨 <b>AI Image Studio (5 Tokens):</b>\n` +
    `  Realistic HD 1024x1024 AI photos render karein: <code>/image &lt;prompt&gt;</code>\n\n` +
    `• 🖼️ <b>Group VIP Welcome Board Pass (20 Tokens):</b>\n` +
    `  Apne group ke liye Cyberpunk Neon HUD Welcome Boards unlock karein: <code>/buywelcome</code>\n\n` +
    `• 🤖 <b>Bot Cloner & Creator (50 Tokens):</b>\n` +
    `  Apna khud ka 24/7 AI Telegram bot create karein: <code>/clone &lt;token&gt;</code>\n\n` +
    `• 💎 <b>VIP Member Badge (50 Tokens):</b>\n` +
    `  Group chat me VIP Member title and priority reactions: <code>/buyvip</code>\n\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `🎁 <b>100% FREE PERMANENT TOOLS:</b>\n` +
    `✅ <b>Auto Reactions:</b> <code>/myreact &lt;emoji&gt;</code> (Bilkul Muft!)\n` +
    `✅ <b>Phonk Track Finder & Audio Cutter:</b> <code>/phonk</code>, <code>/cut</code>\n` +
    `✅ <b>Avee Player .viz Presets:</b> <code>/viz</code> (Direct document download)\n` +
    `✅ <b>Bot Feature Inspector:</b> <code>/checkbot &lt;@bot&gt;</code>\n` +
    `✅ <b>Unlimited AI Girlfriend Chat:</b> 24/7 Free!\n\n` +
    `💡 <b>Tokens kamane ke liye:</b> <code>/refer</code> (+10 Tokens har dost par!)\n` +
    `📬 <b>Boss se tokens mangne ke liye:</b> <code>/requesttokens &lt;amount&gt; [reason]</code>`
  );
}

export async function leaderboardText(myId?: number) {
  const top = await leaderboard(10);
  if (!top.length) return "🏆 Leaderboard abhi khali hai. /refer se dosto ko bulao aur tokens kamao! 🏁";
  const medals = ["🥇", "🥈", "🥉", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"];
  let text = "🏆 <b>Community Leaderboard (Top 10)</b>\n\n" + top.map((u, i) => `${medals[i] ?? `${i + 1}.`} <b>${who(u)}</b> — ${u.points} Tokens`).join("\n");
  if (myId && !top.some((u) => u.id === myId)) {
    const p = await profile(myId);
    if (p.rank) text += `\n\n👤 <b>Aapka Rank:</b> #${p.rank} (${p.points} Tokens)`;
  }
  return text;
}

const shareButton = (url: string) =>
  ({
    inline_keyboard: [
      [{ text: "📤 Dosto ko Bhejo (+1 Token)", url: `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent("Anayra (@AnayGirl_Bot) se baatein karo, join karo 💕")}`, style: "primary" }],
    ],
  }) as any;

export function registerReferral(bot: Bot) {
  // 1) Deep link /start ref_<id> in DM: credit points to both immediately.
  // 2) Chatting in any group earns +1 point per message (up to daily cap).
  bot.use(async (ctx, next) => {
    try {
      const text = ctx.message?.text ?? "";
      if (ctx.chat?.type === "private" && ctx.from) {
        const m = text.match(/^\/start(?:@\w+)?\s+ref_(\d+)/);
        if (m) {
          const inviterId = Number(m[1]);
          const ok = await setReferrer(ctx.from.id, inviterId);
          if (ok) {
            await ctx.reply(
              `🎉 <b>Welcome!</b> Aap apne dost ke referral link se aaye hain.\n` +
                `Aapko aur aapke dost ko <b>+${REF_POINTS} Token</b> mil gaya hai! 🎁\n\n` +
                `Apne tokens dekhne ke liye <code>/points</code> aur VIP store ke liye <code>/shop</code> dabayein.`,
              { parse_mode: "HTML" },
            ).catch(() => {});
          }
        }
      } else if (ctx.chat && ctx.from && !ctx.from.is_bot && ctx.message && text && !text.startsWith("/") && (ctx.chat.type === "group" || ctx.chat.type === "supergroup")) {
        await activityPoint(ctx.from.id);
      }
    } catch (e) {
      console.error("referral tracking failed:", e);
    }
    await next();
  });

  bot.command(["refer", "invite", "mylink"], async (ctx) => {
    const link = referralLink(ctx.me.username, ctx.from!.id);
    await ctx.reply(await referText(ctx.me.username, ctx.from!.id), {
      parse_mode: "HTML",
      reply_markup: shareButton(link),
      link_preview_options: { is_disabled: true },
    });
  });

  bot.command(["points", "mypoints", "me", "wallet", "checktokens", "checkmytokens", "mytoken", "balance", "tokens"], async (ctx) => {
    await ctx.reply(await pointsText(ctx.from!.id), { parse_mode: "HTML" });
  });

  bot.command(["rewards", "shop", "tokenshop", "premium", "store"], async (ctx) => {
    const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
    const p = await profile(ctx.from!.id);
    const kb = new InlineKeyboard()
      .text("🎨 AI Image (5)", "shop:image")
      .text("🖼️ Welcome Pass (20)", "shop:welcome")
      .row()
      .text("🤖 Clone Bot (50)", "shop:clone")
      .text("💎 Auto-React (Free)", "buy:react")
      .row()
      .text("📬 Request Tokens", "shop:request")
      .text("🏆 Leaderboard", "ref:lb")
      .row()
      .text("🔗 Invite Link (+10)", "ref:link");

    await ctx.reply(shopText(p.points, !!isBoss), { parse_mode: "HTML", reply_markup: kb });
  });

  bot.command(["buyvip", "vip"], async (ctx) => {
    const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
    if (isBoss) {
      return ctx.reply("👑 <b>Aap toh Supreme Creator & Empire Owner hain!</b> Aapko kisi VIP badge ki zaroorat nahi, aap hi iske Maalik hain!", { parse_mode: "HTML" });
    }
    const res = await buyVip(ctx.from!.id, 50);
    if (!res.ok) {
      return ctx.reply(`❌ <b>VIP Badge activate nahi hua:</b> ${res.reason}\n\nTokens kamane ke liye <code>/refer</code> karein ya <code>/requesttokens</code> karein!`, { parse_mode: "HTML" });
    }
    return ctx.reply("💎 <b>Badhai Ho!</b> Aapka VIP Member Badge activate ho gaya hai! Group me aapke messages par special VIP status dikhega!", { parse_mode: "HTML" });
  });

  // Auto reactions are 100% FREE for all users (Boss Hukum)
  bot.command(["buyreact", "vipreact", "myreact", "react"], async (ctx) => {
    const emoji = String(ctx.match ?? "").trim() || "💎";
    const res = await buyReaction(ctx.from!.id, emoji, 0);
    if (!res.ok) {
      return ctx.reply(`❌ <b>Auto-Reaction set nahi hua:</b> ${res.reason}`, { parse_mode: "HTML" });
    }
    return ctx.reply(
      `🎉 <b>Success!</b> Aapke messages par Anayra ab <b>${emoji}</b> auto-reaction degi!\n\n` +
        `🎁 <i>Auto-reactions are 100% Free for everyone!</i> ✨\n` +
        `Badalne ke liye likhein: <code>/myreact 🔥</code>`,
      { parse_mode: "HTML" },
    );
  });

  bot.command(["requesttokens", "asktokens", "reqtokens"], async (ctx) => {
    const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
    if (isBoss) {
      return ctx.reply("👑 <b>Aap toh Supreme Boss hain!</b> Aapke paas pehle se hi ∞ INFINITY TOKENS hain! ⚡", { parse_mode: "HTML" });
    }

    const match = String(ctx.match ?? "").trim();
    const parts = match.split(/\s+/).filter(Boolean);
    const amount = Number(parts[0]);
    const reason = parts.slice(1).join(" ") || "No reason specified";

    if (!amount || isNaN(amount) || amount <= 0 || amount > 1000) {
      return ctx.reply(
        `📬 <b>Boss se Tokens Request Karne Ka Tarika:</b>\n\n` +
          `Aise likho: <code>/requesttokens 20 AI Image aur Welcome Board ke liye</code>\n` +
          `• Limit: 1 se 1000 Tokens\n\n` +
          `<i>Aapki request seedha Supreme Boss ke private Telegram par bhej di jayegi!</i>`,
        { parse_mode: "HTML" },
      );
    }

    const userName = ctx.from!.first_name || ctx.from!.username || String(ctx.from!.id);
    const req = await createTokenRequest(ctx.from!.id, userName, amount, reason);

    // Notify Boss in private DM
    const ownerId = process.env.OWNER_ID ? Number(process.env.OWNER_ID) : null;
    if (ownerId) {
      const bossKb = new InlineKeyboard()
        .text(`✅ Approve (+${amount})`, `tr_app:${req.id}`)
        .text("❌ Reject", `tr_rej:${req.id}`);

      await ctx.api.sendMessage(
        ownerId,
        `📬 <b>NAYI TOKEN REQUEST AAYI HAI BOSS!</b> ⚡\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `👤 <b>User:</b> ${userName} (ID: <code>${ctx.from!.id}</code>${ctx.from!.username ? `, @${ctx.from!.username}` : ""})\n` +
          `💰 <b>Requested Tokens:</b> ${amount} Tokens\n` +
          `📝 <b>Reason:</b> <i>"${reason}"</i>\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `<i>Hukum kijiye Boss, kya approve karna hai?</i>`,
        { parse_mode: "HTML", reply_markup: bossKb },
      ).catch((e) => console.error("Could not notify boss of token request:", e));
    }

    await ctx.reply(
      `📬 <b>Request Sent to Supreme Boss!</b> ⚡\n\n` +
        `Aapki <b>${amount} Tokens</b> ki request Supreme Boss ko bhej di gayi hai.\n` +
        `📝 <b>Reason:</b> <i>"${reason}"</i>\n\n` +
        `<i>Jaise hi Boss approve karenge, aapke account mein tokens add ho jayenge!</i> ✨`,
      { parse_mode: "HTML" },
    );
  });

  bot.command("setmood", async (ctx) => {
    const m = String(ctx.match ?? "").trim().toLowerCase();
    const valid = ["romantic", "teasing", "caring", "savage"];
    if (!valid.includes(m)) {
      return ctx.reply(`Aise likho: <code>/setmood romantic</code>\nOptions: <code>romantic</code>, <code>teasing</code>, <code>caring</code>, <code>savage</code> (Cost: 100% Free! ✨)`, { parse_mode: "HTML" });
    }
    const res = await setMood(ctx.from!.id, m);
    if (!res.ok) {
      return ctx.reply(`❌ <b>Mood change nahi hua:</b> ${res.reason}`, { parse_mode: "HTML" });
    }
    return ctx.reply(`💖 <b>Anayra Mood Set:</b> Ab Anayra aapse <b>${m}</b> andaaz me baat karegi! ✨`, { parse_mode: "HTML" });
  });

  bot.command(["shoutout", "announce"], async (ctx) => {
    const text = String(ctx.match ?? "").trim();
    if (!text) {
      return ctx.reply("Aise likho: <code>/shoutout Hello group members!</code> (Cost: 100% Free! ✨)", { parse_mode: "HTML" });
    }
    const sender = ctx.from!.first_name ?? "Member";
    return ctx.reply(
      `📢 <b>GROUP HIGHLIGHT SHOUTOUT</b> 🌟\n\n` +
        `👤 <b>From:</b> <b>${sender}</b>\n` +
        `💬 <i>"${text}"</i>\n\n` +
        `⚡ <i>Powered by Anayra Group Engine</i>`,
      { parse_mode: "HTML" },
    );
  });

  bot.command(["leaderboard", "lb", "top"], async (ctx) => {
    await ctx.reply(await leaderboardText(ctx.from!.id), { parse_mode: "HTML" });
  });

  // Inline button callbacks
  bot.callbackQuery("shop:clone", async (ctx) => {
    await ctx.answerCallbackQuery();
    await ctx.reply(
      `🤖 <b>Bot Cloner / Creator:</b>\n\n` +
        `1. @BotFather par jakar <code>/newbot</code> se naya bot banayein aur token lein.\n` +
        `2. Yahan likhein: <code>/clone &lt;BOT_TOKEN&gt;</code>\n\n` +
        `💰 <b>Cost:</b> 50 Tokens (Boss ke liye Free!)`,
      { parse_mode: "HTML" },
    );
  });

  bot.callbackQuery("shop:welcome", async (ctx) => {
    await ctx.answerCallbackQuery();
    await ctx.reply(
      `🖼️ <b>Group VIP Welcome Board Pass:</b>\n\n` +
        `Apne group mein Cyberpunk Neon HUD Welcome Boards hamesha ke liye unlock karne ke liye apne group me likhein:\n` +
        `<code>/buywelcome</code>\n\n` +
        `💰 <b>Cost:</b> 20 Tokens (Lifetime Unlimited Welcome Images for your group!)\n` +
        `👑 <i>Boss ke liye 100% Free!</i>`,
      { parse_mode: "HTML" },
    );
  });

  bot.callbackQuery("shop:request", async (ctx) => {
    await ctx.answerCallbackQuery();
    await ctx.reply(
      `📬 <b>Supreme Boss se Tokens Mangein:</b>\n\n` +
        `Aise likhein:\n` +
        `<code>/requesttokens 25 AI Image aur Welcome Board ke liye</code>\n\n` +
        `<i>Aapki request seedha Boss ke Telegram DM me jayegi aur Boss ke approve karte hi tokens mil jayenge!</i>`,
      { parse_mode: "HTML" },
    );
  });

  bot.callbackQuery("shop:voice", async (ctx) => {
    await ctx.answerCallbackQuery();
    await ctx.reply(
      `🎙️ <b>VIP Voice Note:</b>\n\n` +
        `Anayra se realistic voice note sunne ke liye likhein:\n` +
        `<code>/askvoice Mujhe ek sweet love note sunao</code>\n\n` +
        `🎁 <b>Cost:</b> 100% Free! ✨`,
      { parse_mode: "HTML" },
    );
  });

  bot.callbackQuery("shop:image", async (ctx) => {
    await ctx.answerCallbackQuery();
    await ctx.reply(
      `🎨 <b>AI Image Studio:</b>\n\n` +
        `Realistic AI image banwane ke liye likhein:\n` +
        `<code>/image cyber city neon lights anime style</code>\n\n` +
        `💰 <b>Cost:</b> 5 Tokens per image (Boss ke liye Free!)`,
      { parse_mode: "HTML" },
    );
  });

  bot.callbackQuery("buy:react", async (ctx) => {
    await ctx.answerCallbackQuery();
    const res = await buyReaction(ctx.from.id, "💎", 0);
    if (!res.ok) {
      return ctx.reply(`❌ ${res.reason}`, { parse_mode: "HTML" });
    }
    await ctx.reply(`💎 <b>Active!</b> Ab Anayra aapke har message par 💎 react karegi! (100% Free for everyone) ✨`, { parse_mode: "HTML" });
  });

  bot.callbackQuery("buy:mood:romantic", async (ctx) => {
    await ctx.answerCallbackQuery();
    const res = await setMood(ctx.from.id, "romantic");
    if (!res.ok) return ctx.reply(`❌ ${res.reason}`, { parse_mode: "HTML" });
    await ctx.reply(`💕 <b>Romantic Mood ON!</b> Ab Anayra aapke saath behad romantic aur sweet baatein karegi! (100% Free)`, { parse_mode: "HTML" });
  });

  bot.callbackQuery("buy:mood:teasing", async (ctx) => {
    await ctx.answerCallbackQuery();
    const res = await setMood(ctx.from.id, "teasing");
    if (!res.ok) return ctx.reply(`❌ ${res.reason}`, { parse_mode: "HTML" });
    await ctx.reply(`😏 <b>Teasing Mood ON!</b> Ab Anayra thoda nakhre aur masti bhare andaaz me baat karegi! (100% Free)`, { parse_mode: "HTML" });
  });

  bot.callbackQuery("ref:link", async (ctx) => {
    await ctx.answerCallbackQuery();
    const link = referralLink(ctx.me.username, ctx.from.id);
    await ctx.reply(await referText(ctx.me.username, ctx.from.id), {
      parse_mode: "HTML",
      reply_markup: shareButton(link),
      link_preview_options: { is_disabled: true },
    });
  });

  bot.callbackQuery("ref:lb", async (ctx) => {
    await ctx.answerCallbackQuery();
    await ctx.reply(await leaderboardText(ctx.from.id), { parse_mode: "HTML" });
  });

  // Boss Token Request Approval / Rejection Handlers
  bot.callbackQuery(/^tr_app:(.+)$/, async (ctx) => {
    await ctx.answerCallbackQuery();
    const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
    if (!isBoss) return ctx.reply("Sirf Supreme Boss approve kar sakte hain! 🚫");

    const reqId = ctx.match[1];
    const req = await resolveTokenRequest(reqId, "approved");
    if (!req) {
      return ctx.editMessageText("⚠️ Ye request pehle hi process ya expire ho chuki hai.");
    }

    await ctx.editMessageText(
      `✅ <b>REQUEST APPROVED BY BOSS!</b> ⚡\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `👤 <b>User:</b> ${req.userName} (ID: <code>${req.userId}</code>)\n` +
        `💰 <b>Tokens Granted:</b> +${req.amount} Tokens\n` +
        `📝 <b>Reason:</b> <i>"${req.reason || "None"}"</i>\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `<i>Tokens user ke wallet mein add ho chuke hain! 💎</i>`,
      { parse_mode: "HTML" },
    );

    // Notify user in DM
    await ctx.api.sendMessage(
      req.userId,
      `🎉 <b>SHAHI KHABAR! REQUEST APPROVED!</b> ⚡\n\n` +
        `Supreme Boss ne aapki <b>+${req.amount} Tokens</b> ki request approve kar di hai! 🎁\n` +
        `Check your balance: <code>/points</code>\n` +
        `AI Image Studio aur features ka aanand lein! 💕`,
      { parse_mode: "HTML" },
    ).catch(() => {});
  });

  bot.callbackQuery(/^tr_rej:(.+)$/, async (ctx) => {
    await ctx.answerCallbackQuery();
    const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
    if (!isBoss) return ctx.reply("Sirf Supreme Boss reject kar sakte hain! 🚫");

    const reqId = ctx.match[1];
    const req = await resolveTokenRequest(reqId, "rejected");
    if (!req) {
      return ctx.editMessageText("⚠️ Ye request pehle hi process ho chuki hai.");
    }

    await ctx.editMessageText(
      `❌ <b>REQUEST REJECTED BY BOSS</b>\n\n` +
        `👤 <b>User:</b> ${req.userName} (ID: <code>${req.userId}</code>)\n` +
        `💰 <b>Amount:</b> ${req.amount} Tokens\n` +
        `<i>Request reject kar di gayi hai.</i>`,
      { parse_mode: "HTML" },
    );

    // Notify user in DM
    await ctx.api.sendMessage(
      req.userId,
      `❌ <b>Token Request Update:</b>\n\n` +
        `Aapki <b>${req.amount} Tokens</b> ki request Supreme Boss dwara reject kar di gayi hai.\n` +
        `Aap dosto ko invite karke <code>/refer</code> se free tokens kama sakte hain!`,
      { parse_mode: "HTML" },
    ).catch(() => {});
  });
}
