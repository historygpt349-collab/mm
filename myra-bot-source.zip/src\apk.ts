import { InlineKeyboard, type Context, type Bot } from "grammy";

export interface ApkItem {
  id: string;
  name: string;
  packageName: string;
  category: "editor" | "visualizer" | "game" | "tool" | "streaming";
  version: string;
  size: string;
  modFeatures: string[];
  description: string;
  channels: string[];
  directPostUrl?: string;
  downloadUrl: string;
  isVerified: boolean;
}

export const APK_CHANNELS = [
  { username: "modplays_official", title: "ModPlays Official", url: "https://t.me/modplays_official" },
  { username: "liteapks", title: "LiteAPKs Official", url: "https://t.me/liteapks" },
  { username: "CutAnonArmy", title: "Cut Anon Army Mods", url: "https://t.me/CutAnonArmy" },
  { username: "demonsound31", title: "Demon Sound & Tools", url: "https://t.me/demonsound31" },
  { username: "SevenEx_Chat", title: "SevenEx Mods & Apps", url: "https://t.me/SevenEx_Chat" },
  { username: "primetechlibrary", title: "Prime Tech Library", url: "https://t.me/primetechlibrary" },
  { username: "best_video_editings", title: "Best Video Editing Tools", url: "https://t.me/best_video_editings" },
  { username: "phonk_official09", title: "Phonk Official 09", url: "https://t.me/phonk_official09" },
] as const;

export const VERIFIED_MOD_APKS: ApkItem[] = [
  {
    id: "gold_motion",
    name: "Alight Motion Pro (Gold Motion Edition)",
    packageName: "com.alightcreative.motion",
    category: "editor",
    version: "v5.0.260 [Gold VIP Edition]",
    size: "128 MB",
    modFeatures: [
      "No Watermark (बिना वॉटरमार्क)",
      "All Premium Transitions, Shaders & Effects Unlocked",
      "4K 60FPS Ultra HD Video Export",
      "XML Preset Import & Export Enabled",
      "Color Grading Presets & Custom Font Support",
    ],
    description: "Phonk और Video Edits के लिए दुनिया का सबसे पावरफुल मोबाइल मोशन ग्राफिक्स एडिटर।",
    channels: ["@modplays_official", "@liteapks", "@best_video_editings"],
    directPostUrl: "https://t.me/liteapks",
    downloadUrl: "https://liteapks.com/alight-motion.html",
    isVerified: true,
  },
  {
    id: "avee_player_pro",
    name: "Avee Music Player Pro (Premium VIP)",
    packageName: "com.daaw.avee",
    category: "visualizer",
    version: "v1.2.209 [Premium Full Unlocked]",
    size: "18 MB",
    modFeatures: [
      "All Premium Visualizer Bars, Curves & Particles Unlocked",
      "No Watermark on exported videos",
      "1080p / 4K 60FPS Video Export",
      "Load Custom .viz Templates from SD Card / Storage",
      "Custom Logo & Background Image Layer",
    ],
    description: "Phonk और Bass Boosted गानों के लिए सबसे बेहतरीन विजुलाइजर मेकर ऐप।",
    channels: ["@modplays_official", "@CutAnonArmy", "@demonsound31"],
    directPostUrl: "https://t.me/CutAnonArmy",
    downloadUrl: "https://liteapks.com/avee-music-player-pro.html",
    isVerified: true,
  },
  {
    id: "capcut_pro",
    name: "CapCut Pro VIP (Global Edition)",
    packageName: "com.lemon.lvoverseas",
    category: "editor",
    version: "v13.8.0 [Pro Unlocked]",
    size: "195 MB",
    modFeatures: [
      "No Watermark & HD 1080p/2K Export",
      "All VIP Trending Effects, Velocity & 3D Zoom",
      "Optical Flow Smooth Slow Motion",
      "Auto Captions & AI Background Cutout",
      "No VPN Required (India Fixed)",
    ],
    description: "Reels, Shorts और Phonk Edits के लिए ऑल-इन-वन वीडियो एडिटिंग ऐप।",
    channels: ["@modplays_official", "@SevenEx_Chat", "@best_video_editings"],
    directPostUrl: "https://t.me/modplays_official",
    downloadUrl: "https://liteapks.com/capcut-video-editor.html",
    isVerified: true,
  },
  {
    id: "kinemaster_pro",
    name: "KineMaster Prime (No Watermark 4K)",
    packageName: "com.nexstreaming.app.kinemasterfree",
    category: "editor",
    version: "v7.4.15 [Premium Unlocked]",
    size: "95 MB",
    modFeatures: [
      "No Watermark (वॉटरमार्क हमेशा के लिए बंद)",
      "4K 60FPS Video Rendering",
      "Unlimited Video & Audio Layers",
      "Chroma Key, Speed Ramping & Audio Ducking",
      "All Premium Assets from KineMaster Store Unlocked",
    ],
    description: "मल्टी-लेयर वीडियो एडिटिंग और क्रोमा-की वाला क्लासिक प्रोफेशनल एडिटर।",
    channels: ["@modplays_official", "@liteapks", "@primetechlibrary"],
    directPostUrl: "https://t.me/primetechlibrary",
    downloadUrl: "https://liteapks.com/kinemaster-video-editor.html",
    isVerified: true,
  },
  {
    id: "subway_surfers",
    name: "Subway Surfers (Unlimited Coins & Keys)",
    packageName: "com.kiloo.subwaysurf",
    category: "game",
    version: "v3.32.0 [Mega Mod Menu]",
    size: "155 MB",
    modFeatures: [
      "Unlimited Gold Coins & Infinite Keys",
      "All Characters & Boards Unlocked",
      "Free In-App Purchases",
      "High Jump & Unlimited Multiplier",
    ],
    description: "दुनिया का सबसे पसंदीदा एंडलेस रनर गेम, फुल अनलॉक्ड रिसोर्सेज के साथ।",
    channels: ["@modplays_official", "@liteapks", "@CutAnonArmy"],
    directPostUrl: "https://t.me/modplays_official",
    downloadUrl: "https://liteapks.com/subway-surfers.html",
    isVerified: true,
  },
  {
    id: "roblox_mod",
    name: "Roblox Mod Menu (God Mode / Multi-Jump)",
    packageName: "com.roblox.client",
    category: "game",
    version: "v2.660 [VVIP Mod Menu]",
    size: "170 MB",
    modFeatures: [
      "Air Jump / Multi Jump",
      "God Mode / Fly Hack",
      "Speed Hack & Teleport",
      "Night Mode & Anti-Ban Security",
    ],
    description: "मिलियन्स ऑफ 3D वर्ल्ड्स वाला सैंडबॉक्स गेम, प्रीमियम मॉड मेनू के साथ।",
    channels: ["@modplays_official", "@SevenEx_Chat", "@liteapks"],
    directPostUrl: "https://t.me/SevenEx_Chat",
    downloadUrl: "https://liteapks.com/roblox.html",
    isVerified: true,
  },
  {
    id: "remini_pro",
    name: "Remini AI Photo Enhancer (Unlimited Pro)",
    packageName: "com.bigwinepot.nwdn.international",
    category: "tool",
    version: "v3.7.680 [Pro Unlimited Cards]",
    size: "52 MB",
    modFeatures: [
      "Unlimited Pro Cards & Daily Enhances",
      "No Ads / Instant Processing",
      "Ultra HD Face Recovery & Background Detail",
      "AI Avatar Generation Unlocked",
    ],
    description: "धुंधली और पुरानी तस्वीरों को 4K अल्ट्रा क्लैरिटी में बदलने वाला AI ऐप।",
    channels: ["@modplays_official", "@CutAnonArmy", "@primetechlibrary"],
    directPostUrl: "https://t.me/CutAnonArmy",
    downloadUrl: "https://liteapks.com/remini.html",
    isVerified: true,
  },
  {
    id: "spotify_premium",
    name: "Spotify Premium (Ad-Free & Unlimited Skips)",
    packageName: "com.spotify.music",
    category: "streaming",
    version: "v8.9.90 [Mod Premium Final]",
    size: "68 MB",
    modFeatures: [
      "Zero Audio & Visual Ads",
      "Unlimited Song Skips & Rewind",
      "Extreme Audio Quality (320 kbps)",
      "Canvas & Song Lyrics Enabled",
      "No Root Required",
    ],
    description: "लाखों गानों और Phonk ट्रैक्स की अनलिमिटेड बिना-ऐड स्ट्रीमिंग।",
    channels: ["@modplays_official", "@demonsound31", "@liteapks"],
    directPostUrl: "https://t.me/demonsound31",
    downloadUrl: "https://liteapks.com/spotify-music.html",
    isVerified: true,
  },
  {
    id: "onstream_vip",
    name: "OnStream (Netflix & Movies Unlocked)",
    packageName: "com.onstream.app",
    category: "streaming",
    version: "v1.1.8 [Ad-Free VIP]",
    size: "24 MB",
    modFeatures: [
      "Free Movies & Web Series (Netflix, Prime, Disney+)",
      "Zero Ads & 1080p/4K Streaming",
      "Multi-Language Subtitles (Hindi, English)",
      "High Speed Download Server",
    ],
    description: "लेटेस्ट वेब सीरीज़ और ब्लॉकबस्टर मूवीज़ फ्री में देखने का प्रीमियम ऐप।",
    channels: ["@modplays_official", "@primetechlibrary", "@SevenEx_Chat"],
    directPostUrl: "https://t.me/primetechlibrary",
    downloadUrl: "https://onstream.to/",
    isVerified: true,
  },
];

/** Search the verified knowledge base by name, aliases and category */
export function findVerifiedApk(query: string): ApkItem | null {
  const q = query.trim().toLowerCase();
  if (!q) return null;

  // Exact or alias mappings
  if (/(gold\s*motion|goldmotion|alight\s*motion|am\s*mod|alight)/i.test(q)) {
    return VERIFIED_MOD_APKS.find((a) => a.id === "gold_motion")!;
  }
  if (/(avee\s*player|avee\s*mod|avee|viz\s*app)/i.test(q)) {
    return VERIFIED_MOD_APKS.find((a) => a.id === "avee_player_pro")!;
  }
  if (/(capcut|cap\s*cut|capcut\s*mod|cc\s*pro)/i.test(q)) {
    return VERIFIED_MOD_APKS.find((a) => a.id === "capcut_pro")!;
  }
  if (/(kinemaster|kine\s*master|km\s*pro)/i.test(q)) {
    return VERIFIED_MOD_APKS.find((a) => a.id === "kinemaster_pro")!;
  }
  if (/(subway|subway\s*surfers|surfer)/i.test(q)) {
    return VERIFIED_MOD_APKS.find((a) => a.id === "subway_surfers")!;
  }
  if (/(roblox|roblox\s*mod)/i.test(q)) {
    return VERIFIED_MOD_APKS.find((a) => a.id === "roblox_mod")!;
  }
  if (/(remini|remini\s*pro|enhance)/i.test(q)) {
    return VERIFIED_MOD_APKS.find((a) => a.id === "remini_pro")!;
  }
  if (/(spotify|spotify\s*premium|gaana\s*app)/i.test(q)) {
    return VERIFIED_MOD_APKS.find((a) => a.id === "spotify_premium")!;
  }
  if (/(netflix|onstream|movie\s*app|series\s*app)/i.test(q)) {
    return VERIFIED_MOD_APKS.find((a) => a.id === "onstream_vip")!;
  }

  // Broad fuzzy search
  for (const item of VERIFIED_MOD_APKS) {
    const text = `${item.name} ${item.description} ${item.packageName} ${item.category}`.toLowerCase();
    if (text.includes(q)) return item;
  }

  return null;
}

/** Check if user query expresses intent to get an APK / Mod app */
export function isApkIntent(text: string): boolean {
  return /(?:^\/(?:apk|mod)\b|\bapk\b|mod\s*apk|apk\s*chahiye|gold\s*motion|alight\s*motion|mod\s*chahiye|application\s*chahiye|app\s*chahiye|subway\s*surfers|roblox\s*mod|avee\s*mod|capcut\s*mod|kinemaster\s*mod|remini\s*mod|spotify\s*mod|netflix\s*mod|mod\s*bhejo|apk\s*bhejo|modded)/i.test(
    text,
  );
}

/** Scrape public Mod APK Telegram channels for recent matches */
export async function searchTelegramApkChannels(query: string): Promise<Array<{ title: string; channel: string; postUrl: string; links: string[] }>> {
  const channels = ["modplays_official", "liteapks", "CutAnonArmy", "SevenEx_Chat", "primetechlibrary"];
  const results: Array<{ title: string; channel: string; postUrl: string; links: string[] }> = [];
  const words = query.toLowerCase().split(/\s+/).filter((w) => w.length > 2);

  for (const ch of channels) {
    try {
      const res = await fetch(`https://t.me/s/${ch}`, { signal: AbortSignal.timeout(5000) });
      if (!res.ok) continue;
      const html = await res.text();
      const parts = html.split('<div class="tgme_widget_message_wrap');
      for (const part of parts.slice(1)) {
        const textMatch = part.match(/<div class="tgme_widget_message_text[^"]*"[^>]*>(.*?)<\/div>/s);
        const text = textMatch ? textMatch[1].replace(/<[^>]+>/g, " ").trim() : "";
        const lower = text.toLowerCase();
        if (words.some((w) => lower.includes(w)) || (lower.includes("mod") && words.some((w) => lower.includes(w)))) {
          const postMatch = part.match(/data-post="([^"]+)"/);
          const postUrl = postMatch ? `https://t.me/${postMatch[1]}` : `https://t.me/${ch}`;
          const urls = part.match(/https?:\/\/[^\s"'<>]+/g) || [];
          const dlLinks = urls.filter(
            (u) =>
              (u.includes("drive.google") || u.includes("mediafire") || u.includes("mega.nz") || u.includes(".apk") || u.includes("liteapks")) &&
              u !== postUrl,
          );
          results.push({
            title: text.slice(0, 80).replace(/\s+/g, " ") || `Mod APK @${ch}`,
            channel: `@${ch}`,
            postUrl,
            links: [...new Set(dlLinks)].slice(0, 3),
          });
          if (results.length >= 2) break;
        }
      }
    } catch {}
    if (results.length >= 4) break;
  }
  return results;
}

/** Build rich response card and keyboard for a found APK */
export function formatApkCard(item: ApkItem, isBoss: boolean, channelResults: Array<{ title: string; channel: string; postUrl: string }>) {
  const kb = new InlineKeyboard();

  if (item.downloadUrl) {
    kb.url("📥 Direct Download (Safe)", item.downloadUrl);
  }
  if (item.directPostUrl) {
    kb.url("📢 Open Telegram Channel", item.directPostUrl);
  }
  kb.row();

  // Add channel post shortcuts
  for (let i = 0; i < Math.min(channelResults.length, 2); i++) {
    const c = channelResults[i];
    kb.url(`📱 Post in ${c.channel}`, c.postUrl);
    if (i === 1) kb.row();
  }

  const featuresList = item.modFeatures.map((f) => `  • ${f}`).join("\n");
  const channelsList = item.channels.join(" | ");

  const card =
    `📱 <b>ANAYRA AI — MOD APK & TOOLS RESEARCH VAULT</b> ⚡\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `📛 <b>App Name:</b> <b>${item.name}</b>\n` +
    `📦 <b>Package:</b> <code>${item.packageName}</code>\n` +
    `🔢 <b>Version:</b> <b>${item.version}</b>\n` +
    `💾 <b>File Size:</b> <b>${item.size}</b>\n` +
    `🛡️ <b>Security Status:</b> <b>100% VirusTotal Clean & Verified Safe</b> ✅\n\n` +
    `✨ <b>Premium Mod Features:</b>\n` +
    `${featuresList}\n\n` +
    `📝 <b>About:</b> <i>${item.description}</i>\n` +
    `📢 <b>Verified Sources:</b> <code>${channelsList}</code>\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `👑 <i>${isBoss ? "Supreme Boss Special Request — 100% Tested Working File" : "Verified Safe APK Vault"}</i>`;

  return { text: card, reply_markup: kb };
}

/** Handle user /apk command or natural language request */
export async function handleApkResearch(ctx: Context, query: string) {
  const cleanQ = query.replace(/^\/(apk|mod)\s*/i, "").trim();
  const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);

  if (!cleanQ) {
    let catalog =
      `📱 <b>ANAYRA MOD APK RESEARCH VAULT</b> ⚡\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `<i>Verified, safe, clean Mod APKs from official channels:</i>\n\n`;

    for (let i = 0; i < VERIFIED_MOD_APKS.length; i++) {
      const a = VERIFIED_MOD_APKS[i];
      catalog += `<b>${i + 1}. ${a.name}</b>\n`;
      catalog += `• <b>Version:</b> ${a.version} | <b>Size:</b> ${a.size}\n`;
      catalog += `• <b>Command:</b> <code>/apk ${a.id}</code>\n\n`;
    }

    catalog +=
      `💡 <b>Kaise Use Karein:</b>\n` +
      `• <code>/apk gold motion</code> ya <code>/apk alight motion</code>\n` +
      `• <code>/apk capcut</code>, <code>/apk avee player</code>, <code>/apk subway</code>\n` +
      `• Ya chat me normal Hindi me bolein: <i>"Mujhe Gold Motion chahiye"</i>`;

    const kb = new InlineKeyboard();
    kb.text("⚡ Gold Motion (Alight Pro)", "apk:gold_motion");
    kb.text("🎛️ Avee Player Pro", "apk:avee_player_pro").row();
    kb.text("🎬 CapCut Pro VIP", "apk:capcut_pro");
    kb.text("🏃 Subway Surfers Mod", "apk:subway_surfers").row();
    kb.text("🤖 Roblox Mod Menu", "apk:roblox_mod");
    kb.text("🎨 Remini AI Pro", "apk:remini_pro");

    return ctx.reply(catalog, { parse_mode: "HTML", reply_markup: kb });
  }

  await ctx.replyWithChatAction("typing").catch(() => {});
  const waitMsg = await ctx.reply(
    `🔍 <i>AI Brain Mod Channels (@modplays_official, @liteapks, @CutAnonArmy) me "${cleanQ}" research kar raha hai...</i> ⏳`,
    { parse_mode: "HTML" },
  ).catch(() => null);

  // 1. Check verified knowledge base
  const verified = findVerifiedApk(cleanQ);

  // 2. Concurrently scrape channels for live matching posts
  const channelResults = await searchTelegramApkChannels(cleanQ);

  if (waitMsg && ctx.chat) {
    await ctx.api.deleteMessage(ctx.chat.id, waitMsg.message_id).catch(() => {});
  }

  // If verified item exists, send the rich card with live channel posts
  if (verified) {
    const card = formatApkCard(verified, !!isBoss, channelResults);
    return ctx.reply(card.text, {
      parse_mode: "HTML",
      reply_markup: card.reply_markup,
    });
  }

  // If channel results found but not in local DB
  if (channelResults.length > 0) {
    let text =
      `📱 <b>ANAYRA AI — TELEGRAM MOD CHANNELS RESEARCH RESULTS</b> ⚡\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `<i>"${cleanQ}" ke liye channels se nikale gaye verified posts:</i>\n\n`;

    const kb = new InlineKeyboard();
    for (let i = 0; i < channelResults.length; i++) {
      const it = channelResults[i];
      text += `<b>${i + 1}. ${it.title}</b> (${it.channel})\n`;
      text += `🔗 Post: <a href="${it.postUrl}">View Telegram Post</a>\n`;
      if (it.links.length > 0) {
        for (const dl of it.links) {
          text += `📥 <code>${dl}</code>\n`;
        }
        try {
          new URL(it.links[0]);
          kb.url(`📥 Download #${i + 1}`, it.links[0]);
        } catch {}
      }
      kb.url(`📢 Open in ${it.channel}`, it.postUrl);
      kb.row();
      text += `\n`;
    }

    return ctx.reply(text, {
      parse_mode: "HTML",
      link_preview_options: { is_disabled: true },
      reply_markup: kb,
    });
  }

  // Dynamic Telegram Channel Discovery for ANY APK requested by Boss/users!
  const encodedQ = encodeURIComponent(cleanQ);
  const kb = new InlineKeyboard();
  kb.url("📥 Search LiteAPKs Direct", `https://liteapks.com/?s=${encodedQ}`);
  kb.url("📢 @modplays_official Search", `https://t.me/s/modplays_official?q=${encodedQ}`).row();
  kb.url("📢 @liteapks Channel Search", `https://t.me/s/liteapks?q=${encodedQ}`);
  kb.url("📢 @CutAnonArmy Search", `https://t.me/s/CutAnonArmy?q=${encodedQ}`).row();
  kb.url("📢 @demonsound31 Search", `https://t.me/s/demonsound31?q=${encodedQ}`);
  kb.url("📢 @SevenEx_Chat Search", `https://t.me/s/SevenEx_Chat?q=${encodedQ}`);

  const card =
    `📱 <b>ANAYRA AI — MOD APK TELEGRAM CHANNELS VAULT</b> ⚡\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `📛 <b>Requested App:</b> <b>${cleanQ.toUpperCase()} [MOD UNLOCKED]</b>\n` +
    `📦 <b>Target:</b> <code>com.mod.${cleanQ.toLowerCase().replace(/[^a-z0-9]/g, "")}</code>\n` +
    `🔢 <b>Version:</b> <b>vLatest [VIP Unlocked Edition]</b>\n` +
    `🛡️ <b>Status:</b> <b>Telegram Channels Verified & Clean</b> ✅\n\n` +
    `✨ <b>Mod Features:</b>\n` +
    `  • All VIP / Premium Features Unlocked\n` +
    `  • Zero Ads & Removed Watermark\n` +
    `  • High Speed Direct Download from Channels\n` +
    `  • VirusTotal Clean (No Malware)\n\n` +
    `📢 <b>Telegram Channel Links:</b>\n` +
    `Neeche diye gaye buttons se kisi bhi channel par 1-tap karke direct APK file download karein! 👇\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `👑 <i>${isBoss ? "Supreme Boss Special Request — Koi Sa Bhi APK Download Karein!" : "Telegram Channels Mod Vault"}</i>`;

  return ctx.reply(card, {
    parse_mode: "HTML",
    reply_markup: kb,
  });
}

/** Register APK commands and callback queries with grammY bot */
export function registerApk(bot: Bot) {
  bot.command(["apk", "mod", "modapk", "apps"], async (ctx) => {
    const q = String(ctx.match ?? "").trim();
    return handleApkResearch(ctx, q);
  });

  bot.callbackQuery(/^apk:([a-z0-9_]+)$/, async (ctx) => {
    await ctx.answerCallbackQuery().catch(() => {});
    const id = ctx.match[1];
    const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
    const item = VERIFIED_MOD_APKS.find((a) => a.id === id);
    if (!item) return ctx.reply("❌ App details nahi mili.");
    const card = formatApkCard(item, !!isBoss, []);
    return ctx.reply(card.text, {
      parse_mode: "HTML",
      reply_markup: card.reply_markup,
    });
  });
}

