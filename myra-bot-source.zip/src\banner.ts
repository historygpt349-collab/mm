import { createRequire } from "node:module";
import { readFileSync } from "node:fs";
import { initWasm, Resvg } from "@resvg/resvg-wasm";
import satori from "satori";
import { FONT_DEVANAGARI_600, FONT_INTER_500, FONT_INTER_600, FONT_INTER_700, FONT_PLAYFAIR_800 } from "./fonts.js";

// High-Tech Cyberpunk & Royal Neon HUD Welcome Board (1280x720 HD)
const W = 1280;
const H = 720;
const buf = (b64: string) => Buffer.from(b64, "base64");

let wasmReady: Promise<void> | null = null;
function initResvg() {
  wasmReady ??= initWasm(readFileSync(createRequire(import.meta.url).resolve("@resvg/resvg-wasm/index_bg.wasm")));
  return wasmReady;
}

const FONTS = [
  { name: "Inter", data: buf(FONT_INTER_700), weight: 700 as const, style: "normal" as const },
  { name: "Inter", data: buf(FONT_INTER_600), weight: 600 as const, style: "normal" as const },
  { name: "Inter", data: buf(FONT_INTER_500), weight: 500 as const, style: "normal" as const },
  { name: "Playfair", data: buf(FONT_PLAYFAIR_800), weight: 800 as const, style: "normal" as const },
  { name: "NotoDeva", data: buf(FONT_DEVANAGARI_600), weight: 600 as const, style: "normal" as const },
];

const h = (type: string, style: Record<string, unknown>, children?: unknown): any => ({ type, props: { style, children } });
const clip = (s: string, n: number) => (s.length > n ? s.slice(0, n - 1) + "…" : s);

export type BannerInput = {
  name: string;
  group: string;
  avatar?: { data: Buffer; mime: string } | null;
  memberNo?: number | null;
};

/**
 * Generate a Powerful, Futuristic Cyberpunk Neon HUD Welcome Board
 */
export async function welcomeBanner(i: BannerInput): Promise<Buffer> {
  await initResvg();

  const printable = (s: string) =>
    s
      .replace(/[^\p{Script=Latin}\p{Script=Devanagari}\p{N}\p{P}\p{Zs}]/gu, "")
      .replace(/\s+/g, " ")
      .trim();

  const name = clip(printable(i.name) || "New Operative", 26);
  const group = clip(printable(i.group) || "The Empire", 28);
  const initial = [...name][0]?.toUpperCase() ?? "A";
  const memberText = i.memberNo ? `👑 Member #${i.memberNo.toLocaleString("en-US")}` : "👑 New Operative";

  const D = 250;
  const photo = i.avatar
    ? h("img", {
        width: D,
        height: D,
        borderRadius: D / 2,
        objectFit: "cover",
        src: `data:${i.avatar.mime};base64,${i.avatar.data.toString("base64")}`,
      })
    : h(
        "div",
        {
          width: D,
          height: D,
          borderRadius: D / 2,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: "linear-gradient(135deg, #1e1b4b, #0f172a)",
        },
        [
          h(
            "div",
            {
              fontFamily: "Playfair",
              fontSize: 120,
              fontWeight: 800,
              color: "#ffffff",
              textShadow: "0 0 25px #00f0ff",
            },
            initial,
          ),
        ],
      );

  const tree = h(
    "div",
    {
      width: W,
      height: H,
      display: "flex",
      position: "relative",
      backgroundColor: "#060813",
      backgroundImage:
        "radial-gradient(circle at 18% 35%, rgba(0, 240, 255, 0.22) 0%, transparent 48%), radial-gradient(circle at 82% 65%, rgba(255, 0, 127, 0.22) 0%, transparent 48%)",
      fontFamily: "Inter, NotoDeva",
      overflow: "hidden",
    },
    [
      // Futuristic Border Frame with Neon Glow
      h(
        "div",
        {
          position: "absolute",
          left: 24,
          top: 24,
          width: W - 48,
          height: H - 48,
          border: "2px solid rgba(0, 240, 255, 0.65)",
          borderRadius: 16,
          boxShadow: "0 0 35px rgba(0, 240, 255, 0.35), inset 0 0 35px rgba(0, 240, 255, 0.12)",
          display: "flex",
          flexDirection: "column",
        },
        [
          // Top Header Bar
          h(
            "div",
            {
              height: 64,
              width: "100%",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              paddingLeft: 32,
              paddingRight: 32,
              borderBottom: "1px solid rgba(0, 240, 255, 0.35)",
              backgroundColor: "rgba(0, 240, 255, 0.06)",
            },
            [
              h("div", { color: "#00f0ff", fontWeight: 700, fontSize: 18, letterSpacing: 2 }, "⚡ SYSTEM ACCESS // NEW OPERATIVE DETECTED"),
              h("div", { color: "#ff007f", fontWeight: 600, fontSize: 16, letterSpacing: 1 }, "STATUS: ONLINE • 24/7 AUTO-GUARD ACTIVE"),
            ],
          ),

          // Main Center Area (Left Avatar + Right Info)
          h(
            "div",
            {
              flex: 1,
              display: "flex",
              alignItems: "center",
              paddingLeft: 64,
              paddingRight: 64,
            },
            [
              // Left Holographic Avatar Portal
              h(
                "div",
                {
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  marginRight: 64,
                },
                [
                  h(
                    "div",
                    {
                      width: D + 8,
                      height: D + 8,
                      borderRadius: (D + 8) / 2,
                      border: "4px solid #00f0ff",
                      boxShadow: "0 0 45px rgba(0, 240, 255, 0.85), inset 0 0 25px rgba(255, 0, 127, 0.65)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      background: "#080b18",
                    },
                    photo,
                  ),
                  h(
                    "div",
                    {
                      marginTop: 18,
                      paddingLeft: 22,
                      paddingRight: 22,
                      paddingTop: 6,
                      paddingBottom: 6,
                      borderRadius: 20,
                      backgroundColor: "rgba(0, 240, 255, 0.15)",
                      border: "1px solid #00f0ff",
                      color: "#00f0ff",
                      fontSize: 14,
                      fontWeight: 700,
                      letterSpacing: 1,
                    },
                    "OPERATIVE ID: VERIFIED",
                  ),
                ],
              ),

              // Right Dossier Card
              h(
                "div",
                {
                  display: "flex",
                  flexDirection: "column",
                  flex: 1,
                },
                [
                  h(
                    "div",
                    {
                      color: "#facc15",
                      fontSize: 24,
                      fontWeight: 700,
                      letterSpacing: 3,
                      marginBottom: 8,
                    },
                    "WELCOME TO THE EMPIRE",
                  ),
                  h(
                    "div",
                    {
                      color: "#ffffff",
                      fontSize: name.length > 18 ? 48 : 58,
                      fontWeight: 700,
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      marginBottom: 14,
                      textShadow: "0 0 25px rgba(255, 255, 255, 0.4)",
                    },
                    name,
                  ),
                  h(
                    "div",
                    {
                      display: "flex",
                      alignItems: "center",
                      marginBottom: 22,
                    },
                    [
                      h("div", { color: "#94a3b8", fontSize: 22, marginRight: 12 }, "Joining:"),
                      h("div", { color: "#00f0ff", fontSize: 26, fontWeight: 700 }, group),
                    ],
                  ),
                  // Badges Row
                  h(
                    "div",
                    {
                      display: "flex",
                      alignItems: "center",
                    },
                    [
                      h(
                        "div",
                        {
                          paddingLeft: 22,
                          paddingRight: 22,
                          paddingTop: 8,
                          paddingBottom: 8,
                          borderRadius: 8,
                          backgroundColor: "rgba(255, 0, 127, 0.18)",
                          border: "1px solid #ff007f",
                          color: "#ffffff",
                          fontSize: 18,
                          fontWeight: 600,
                          marginRight: 16,
                        },
                        memberText,
                      ),
                      h(
                        "div",
                        {
                          paddingLeft: 22,
                          paddingRight: 22,
                          paddingTop: 8,
                          paddingBottom: 8,
                          borderRadius: 8,
                          backgroundColor: "rgba(0, 240, 255, 0.12)",
                          border: "1px solid #00f0ff",
                          color: "#00f0ff",
                          fontSize: 18,
                          fontWeight: 600,
                        },
                        "🛡️ 24/7 Security Active",
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),

          // Bottom Footer Bar
          h(
            "div",
            {
              height: 52,
              width: "100%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              borderTop: "1px solid rgba(0, 240, 255, 0.25)",
              backgroundColor: "rgba(0, 0, 0, 0.35)",
              color: "#64748b",
              fontSize: 14,
              letterSpacing: 2,
            },
            "⚡ POWERED BY ANAYRA AI GUARDIAN • HUKUM BY SUPREME BOSS ⚡",
          ),
        ],
      ),
    ],
  );

  const svg = await satori(tree, { width: W, height: H, fonts: FONTS });
  return Buffer.from(new Resvg(svg, { fitTo: { mode: "width", value: 1280 } }).render().asPng());
}
