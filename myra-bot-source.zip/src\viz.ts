import fs from "node:fs";
import path from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { InlineKeyboard, InputFile, type Context, type Bot } from "grammy";
import { chatAllowed } from "./gate.js";
import { geminiMedia } from "./ai.js";

const execFileAsync = promisify(execFile);

export interface VizTemplate {
  id: string;
  filename: string;
  name: string;
  style: string;
  bpm: string;
  features: string;
  vibe: string;
  guide: string;
}

export const VIZ_TEMPLATES: VizTemplate[] = [
  {
    id: "drift_neon_rgb",
    filename: "drift_neon_rgb.viz",
    name: "🏎️ Drift Monster Neon RGB",
    style: "Drift Phonk / Aggressive",
    bpm: "150-165 BPM",
    vibe: "Best for JDM, Drift Cars, RX-7, Supra, R34, GTR Wallpapers",
    features: "Dynamic Camera Shake on 808s, Neon Underglow, Audio-Reactive Smoke & Sparks, 64-bar Cyan/Magenta Equalizer",
    guide: "Avee Player -> Visualizer -> Load from file -> Select 'drift_neon_rgb.viz' -> Image layer me Car lagayein!",
  },
  {
    id: "brazilian_hyper_drop",
    filename: "brazilian_hyper_drop.viz",
    name: "⚡ Brazilian Phonk Hyper-Drop",
    style: "Brazilian Funk / Montagem",
    bpm: "130-145 BPM",
    vibe: "Best for Cyberpunk, Anime Edits, High Intensity Drops",
    features: "Screen Glitch, Hard Drop Distortion, Strobe Flash on heavy Kicks, Chromatic Aberration (RGB Split)",
    guide: "Avee Player -> Load from file -> Select 'brazilian_hyper_drop.viz' -> Strobe shake 60Hz punch par set karein!",
  },
  {
    id: "vhs_retro_drift",
    filename: "vhs_retro_drift.viz",
    name: "📼 90s Retro VHS Driftline",
    style: "Memphis / Wave Phonk",
    bpm: "135-155 BPM",
    vibe: "Best for Tokyo Night Drives, Low-fi Phonk, Vintage Street Racing",
    features: "CRT Scanlines, Analog Glitch, Horizontal Audio Waves, Muted Vignette, Tape Noise",
    guide: "Avee Player -> Load from file -> Select 'vhs_retro_drift.viz' -> 85% opacity CRT scanline enjoy karein!",
  },
  {
    id: "circle_audio_orbit",
    filename: "circle_audio_orbit.viz",
    name: "🌌 360° Circular Audio Orbit",
    style: "All Phonk Subgenres / Branding",
    bpm: "140-160 BPM",
    vibe: "Best for Phonk FX Vault Branding, Producer Logos, Circle Album Art",
    features: "Circular Bar Equalizer (120 bars), Center Logo/Emblem Pulsing, Reactive Starfield Particles",
    guide: "Avee Player -> Load from file -> Select 'circle_audio_orbit.viz' -> Center mask me apna logo dalein!",
  },
  {
    id: "memphis_skull_pulse",
    filename: "memphis_skull_pulse.viz",
    name: "💀 Memphis Dark Skull Pulser",
    style: "Raw Memphis Rap / Cowbell Phonk",
    bpm: "145-160 BPM",
    vibe: "Best for Dark Aesthetic, Horrorcore, Grim Phonk Edits",
    features: "Skull/Demon Vibration on Kicks, Blood Red Bloom, Ash Dust Particles, Jagged Spikes",
    guide: "Avee Player -> Load from file -> Select 'memphis_skull_pulse.viz' -> Cowbell bloom 2.2x active!",
  },
  {
    id: "wave_horizon_neon",
    filename: "wave_horizon_neon.viz",
    name: "🌊 Wave Phonk Neon Horizon",
    style: "Atmospheric Wave Phonk",
    bpm: "120-140 BPM",
    vibe: "Best for Chill Phonk, Night Drive, Aesthetic Synthwave",
    features: "Flowing 3D Grid Terrain, Smooth Ribbon Waveform, Ambient Color Shift (Cyan -> Violet -> Peach)",
    guide: "Avee Player -> Load from file -> Select 'wave_horizon_neon.viz' -> 60FPS export for silky smooth waves!",
  },
  {
    id: "cyberpunk_car_bass",
    filename: "cyberpunk_car_bass.viz",
    name: "🏎️ Cyberpunk JDM Bass Machine",
    style: "High-tech Phonk / Speed Drift",
    bpm: "155-170 BPM",
    vibe: "Best for Supercars, Lambo, Porsche, Koenigsegg, Night Highway Drifts",
    features: "Speedometer Tachometer dual arc meters, Supercar HUD overlay, Neon boost glow, Bass thumping needle",
    guide: "Avee Player -> Load from file -> Select 'cyberpunk_car_bass.viz' -> Tachometer meters auto-sync to sub-bass!",
  },
];

export function getVizAssetsDir(): string {
  const primary = path.resolve(process.cwd(), "assets", "viz");
  if (fs.existsSync(primary)) return primary;
  const secondary = path.resolve(import.meta.dirname, "..", "assets", "viz");
  return secondary;
}

export function findTemplate(query: string): VizTemplate | null {
  const q = query.trim().toLowerCase().replace(/[^a-z0-9]/g, "");
  if (!q) return null;

  for (const t of VIZ_TEMPLATES) {
    const tid = t.id.toLowerCase().replace(/[^a-z0-9]/g, "");
    const tname = t.name.toLowerCase().replace(/[^a-z0-9]/g, "");
    if (tid.includes(q) || tname.includes(q)) return t;
  }

  // Keywords matching
  if (/(car|drift|rx7|supra|r34|gtr|jdm|nissan|toyota)/i.test(query)) {
    return VIZ_TEMPLATES.find((t) => t.id === "drift_neon_rgb")!;
  }
  if (/(brazil|funk|montagem|strobe|drop|glitch|anime)/i.test(query)) {
    return VIZ_TEMPLATES.find((t) => t.id === "brazilian_hyper_drop")!;
  }
  if (/(vhs|retro|90s|vintage|tape|crt)/i.test(query)) {
    return VIZ_TEMPLATES.find((t) => t.id === "vhs_retro_drift")!;
  }
  if (/(circle|orbit|round|logo|brand|360)/i.test(query)) {
    return VIZ_TEMPLATES.find((t) => t.id === "circle_audio_orbit")!;
  }
  if (/(skull|demon|dark|blood|horror|memphis|cowbell)/i.test(query)) {
    return VIZ_TEMPLATES.find((t) => t.id === "memphis_skull_pulse")!;
  }
  if (/(wave|horizon|chill|relax|synth|grid)/i.test(query)) {
    return VIZ_TEMPLATES.find((t) => t.id === "wave_horizon_neon")!;
  }
  if (/(cyber|speed|hud|lambo|supercar|gauge)/i.test(query)) {
    return VIZ_TEMPLATES.find((t) => t.id === "cyberpunk_car_bass")!;
  }

  return null;
}

/** Check if text expresses visualizer intent */
export function isVisualizerIntent(text: string): boolean {
  return /(?:viz|visualizer|विज़ुअलाइज़र|विजुअलाइजर|avee\s*player|avee\s*template|template\s*chahiye|aisa\s*visualizer|mujhe.*visualizer|visualizer.*bhejo|viz.*file)/i.test(
    text,
  );
}

/** Build inline keyboard for instant 1-click .viz file download */
export function vizDownloadKeyboard(): InlineKeyboard {
  const kb = new InlineKeyboard();
  for (let i = 0; i < VIZ_TEMPLATES.length; i++) {
    const t = VIZ_TEMPLATES[i];
    kb.text(t.name, `vizdl:${t.id}`);
    if (i % 2 === 1) kb.row();
  }
  kb.row().text("🔍 Search YouTube (.viz Links)", "viz:ytsearch");
  return kb;
}

/** Send actual .viz file document to Telegram */
export async function sendVizDocument(ctx: Context, template: VizTemplate, extraTitle?: string) {
  const dir = getVizAssetsDir();
  const filePath = path.join(dir, template.filename);

  if (!fs.existsSync(filePath)) {
    // Proactively generate if missing
    try {
      await execFileAsync("python", ["scripts/generate_viz_templates.py"], { timeout: 10000 });
    } catch (e) {
      console.error("Failed to generate viz templates on demand:", e);
    }
  }

  if (!fs.existsSync(filePath)) {
    return ctx.reply(`❌ Template file "${template.filename}" taiyar nahi ho payi. Dobara koshish karein!`);
  }

  const fileData = fs.readFileSync(filePath);
  const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);

  const caption =
    `🎛️ <b>${extraTitle || "Phonk FX Vault — Avee Player Visualizer"}</b> ⚡\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `📛 <b>Preset:</b> ${template.name}\n` +
    `🎚️ <b>Style:</b> ${template.style} (${template.bpm})\n` +
    `✨ <b>Features:</b> ${template.features}\n` +
    `🖼️ <b>Best Fit:</b> ${template.vibe}\n\n` +
    `📲 <b>Avee Player Kaise Use Karein (Android & PC):</b>\n` +
    `1️⃣ Ye <code>${template.filename}</code> download karke apne phone me save karein.\n` +
    `2️⃣ <b>Avee Player</b> app kholein (Google Play / App Store / PC).\n` +
    `3️⃣ Top-right corner me <b>Visualizer (bars/pencil)</b> icon dabayein.\n` +
    `4️⃣ <b>'Load from file'</b> select karein aur ye <code>.viz</code> file chun lein!\n` +
    `5️⃣ Image layer me jakar apni Car/Anime/Custom Photo lagayein.\n` +
    `6️⃣ Export: <b>1080p 60fps</b> with 15 Mbps bitrate for ultra-crisp drops! 🔥\n\n` +
    `👑 <i>${isBoss ? "Supreme Boss Special Delivery (100% Free!)" : "100% Free Visualizer Vault"}</i>`;

  await ctx.replyWithDocument(new InputFile(fileData, template.filename), {
    caption,
    parse_mode: "HTML",
    reply_markup: vizDownloadKeyboard(),
  });
}

/** Send full visualizer catalog with 1-click download buttons */
export async function sendVizCatalog(ctx: Context) {
  let text =
    `🎛️ <b>ANAYRA PHONK FX VAULT — AVEE PLAYER VISUALIZERS (.VIZ)</b> ⚡\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `<i>Real, ready-to-import Avee Player (.viz) templates — 100% Free for everyone!</i> 🎁\n\n`;

  for (let i = 0; i < VIZ_TEMPLATES.length; i++) {
    const t = VIZ_TEMPLATES[i];
    text += `<b>${i + 1}. ${t.name}</b>\n`;
    text += `• <b>Style:</b> ${t.style} | <b>BPM:</b> ${t.bpm}\n`;
    text += `• <b>FX:</b> ${t.features}\n`;
    text += `• <b>Command:</b> <code>/viz ${t.id.split("_")[0]}</code>\n\n`;
  }

  text +=
    `💡 <b>Doosre Tarike:</b>\n` +
    `• <b>Photo bhejein:</b> Apni Car ya Anime photo bhej kar bolein <i>"Aisa visualizer chahiye"</i> ya caption me <code>/viz</code> likhein!\n` +
    `• <b>YouTube Search:</b> <code>/findviz &lt;query&gt;</code> se YouTube video descriptions se direct Google Drive & Mediafire template links nikaalein!\n\n` +
    `👇 <b>Direct .viz File download karne ke liye neeche button dabayein:</b>`;

  await ctx.reply(text, {
    parse_mode: "HTML",
    reply_markup: vizDownloadKeyboard(),
  });
}

/** Curated Visualizer Telegram Channels provided by Boss */
export const VIZ_CHANNELS = [
  "Phonkyworlds",
  "kj_funk",
  "motnahp123",
  "BLUE_PHONK_23",
  "Shadow_Phonk_Editz1",
  "MR_PHONK_99",
  "lkphonk011",
  "phonk_official09",
  "best_video_editings",
  "phonksong777",
  "aveeplayertemplates",
] as const;

/** Scrape public Telegram channels for Avee Player template posts & links */
export async function searchTelegramChannels(query: string): Promise<Array<{ title: string; channel: string; url: string; dl_links: string[] }>> {
  const results: Array<{ title: string; channel: string; url: string; dl_links: string[] }> = [];
  const words = query.toLowerCase().split(/\s+/).filter((w) => w.length > 2);

  for (const ch of VIZ_CHANNELS) {
    try {
      const res = await fetch(`https://t.me/s/${ch}`, { signal: AbortSignal.timeout(5000) });
      if (!res.ok) continue;
      const html = await res.text();
      const parts = html.split('<div class="tgme_widget_message_wrap');
      for (const part of parts.slice(1)) {
        const textMatch = part.match(/<div class="tgme_widget_message_text[^"]*"[^>]*>(.*?)<\/div>/s);
        const text = textMatch ? textMatch[1].replace(/<[^>]+>/g, " ").trim() : "";
        const lower = text.toLowerCase();
        if (words.some((w) => lower.includes(w)) || lower.includes("template") || lower.includes("viz")) {
          const postMatch = part.match(/data-post="([^"]+)"/);
          const postUrl = postMatch ? `https://t.me/${postMatch[1]}` : `https://t.me/${ch}`;
          const urls = part.match(/https?:\/\/[^\s"'<>]+/g) || [];
          const dlLinks = urls.filter(
            (u) =>
              (u.includes("drive.google") || u.includes("mediafire") || u.includes("mega.nz") || u.includes(".viz") || u.includes(".zip")) &&
              u !== postUrl,
          );
          results.push({
            title: text.slice(0, 75).replace(/\s+/g, " ") || `Avee Player Template @${ch}`,
            channel: `@${ch}`,
            url: postUrl,
            dl_links: [...new Set(dlLinks)].slice(0, 3),
          });
          if (results.length >= 2) break;
        }
      }
    } catch {}
    if (results.length >= 5) break;
  }
  return results;
}

/** Gemini Vision Visualizer Analyzer: Inspects image style and matches to .viz template */
export async function analyzeVisualizerPhotoWithGemini(
  imageBuf: Buffer,
  mime: string,
  userCaption?: string,
): Promise<{ template: VizTemplate; aiAnalysis: string }> {
  const prompt =
    `You are an expert Avee Player Visualizer & Phonk Video Producer AI.
Analyze this visualizer image/screenshot in detail.
Identify:
1. Equalizer / Spectrum style (e.g. 360 Circular Orbit, Cyberpunk Speedometer/Bars, Drift Neon smoke, Brazilian Hyper drop, VHS 90s scanlines, Memphis Skull pulse, Wave horizon)
2. Color Palette & Lighting (Neon cyan/magenta, Blood red, Golden flare, Dark monochrome, Vaporwave)
3. Particles & Effects (Sparks, Smoke, Strobe flash, Chromatic aberration, CRT glitch)
4. Central Subject (JDM Car like RX-7/GTR/Supra, Demon/Skull, Anime, Producer Logo, Abstract)

Choose the BEST match from these template IDs:
- drift_neon_rgb (for JDM cars, drift, smoke, cyan/magenta equalizer)
- brazilian_hyper_drop (for high intensity drops, strobe flash, anime, screen shake)
- vhs_retro_drift (for 90s CRT scanlines, retro tape, lo-fi aesthetic)
- circle_audio_orbit (for 360 circle logo, round spectrum, brand emblem)
- memphis_skull_pulse (for horror, skull, demon, dark cowbell, blood red)
- wave_horizon_neon (for synthwave, chill grid, ambient waves)
- cyberpunk_car_bass (for supercars, dual gauges, tachometer, futuristic HUD)

Output in this exact format:
ANALYSIS: <2-3 sentences in Hinglish summarizing what you see in the visualizer style>
MATCH: <one of the exact template IDs above>`;

  let matchedId = "drift_neon_rgb";
  let aiText = "Image me dynamic audio reactive equalizer aur Phonk aesthetic visualizer detect hua hai.";

  try {
    const raw = await geminiMedia(prompt, imageBuf, mime);
    if (raw) {
      const matchLine = raw.match(/MATCH:\s*([a-z0-9_]+)/i);
      if (matchLine) {
        matchedId = matchLine[1].trim().toLowerCase();
      }
      const analysisLine = raw.match(/ANALYSIS:\s*(.+?)(?=\nMATCH:|$)/is);
      if (analysisLine) {
        aiText = analysisLine[1].trim();
      } else {
        aiText = raw.slice(0, 200).trim();
      }
    }
  } catch (e) {
    console.error("Gemini visualizer analysis error:", e);
  }

  let template = VIZ_TEMPLATES.find((t) => t.id === matchedId);
  if (!template && userCaption) {
    template = findTemplate(userCaption) || VIZ_TEMPLATES[0];
  } else if (!template) {
    template = VIZ_TEMPLATES[0];
  }

  return { template, aiAnalysis: aiText };
}

/** Handle visualizer photo upload with Gemini Vision and channel matches */
export async function handleVisualizerPhoto(ctx: Context, photoBuffer: Buffer, mime: string, caption: string) {
  const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
  await ctx.replyWithChatAction("typing").catch(() => {});
  const waitMsg = await ctx.reply("🧠 <i>Gemini Vision se visualizer photo analyze ho rahi hai aur perfect .viz template khoja ja raha hai...</i> ⏳", {
    parse_mode: "HTML",
  }).catch(() => null);

  const { template, aiAnalysis } = await analyzeVisualizerPhotoWithGemini(photoBuffer, mime, caption);
  const channelMatches = await searchTelegramChannels(template.style.split("/")[0].trim());

  if (waitMsg && ctx.chat) {
    await ctx.api.deleteMessage(ctx.chat.id, waitMsg.message_id).catch(() => {});
  }

  const dir = getVizAssetsDir();
  const filePath = path.join(dir, template.filename);
  if (!fs.existsSync(filePath)) {
    try {
      await execFileAsync("python", ["scripts/generate_viz_templates.py"], { timeout: 10000 });
    } catch {}
  }

  const fileData = fs.readFileSync(filePath);

  const fullCaption =
    `👁️ <b>GEMINI VISION — VISUALIZER ANALYZER</b> ⚡\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `🔍 <b>AI Analysis:</b> <i>${aiAnalysis}</i>\n\n` +
    `🎯 <b>Matched Preset:</b> <b>${template.name}</b>\n` +
    `🎚️ <b>Style:</b> ${template.style} (${template.bpm})\n` +
    `✨ <b>Features:</b> ${template.features}\n\n` +
    `📲 <b>Avee Player me Load Kaise Karein:</b>\n` +
    `1️⃣ Ye <code>${template.filename}</code> download karein.\n` +
    `2️⃣ <b>Avee Player</b> app kholein -> Top Right <b>Visualizer (bars)</b> icon.\n` +
    `3️⃣ <b>'Load from file'</b> dabayein aur ye file select karein!\n` +
    `4️⃣ Image Layer me jakar apni photo set karein. Ready! 🔥\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `👑 <i>${isBoss ? "Supreme Boss Special Delivery (100% Free!)" : "100% Free Avee Player Vault"}</i>`;

  const kb = new InlineKeyboard();
  for (let i = 0; i < Math.min(channelMatches.length, 2); i++) {
    const c = channelMatches[i];
    kb.url(`📢 Post in ${c.channel}`, c.url);
    if (i === 1) kb.row();
  }
  kb.row();
  for (let i = 0; i < VIZ_TEMPLATES.length; i++) {
    const t = VIZ_TEMPLATES[i];
    kb.text(t.name.split(" ")[0] + " " + t.name.split(" ")[1], `vizdl:${t.id}`);
    if (i % 2 === 1) kb.row();
  }

  await ctx.replyWithDocument(new InputFile(fileData, template.filename), {
    caption: fullCaption,
    parse_mode: "HTML",
    reply_markup: kb,
  });
}

/** Search YouTube and Telegram for Avee Player templates and extract download links */
export async function searchAndSendOnlineTemplates(ctx: Context, query: string) {
  const cleanQ = query.trim() || "phonk drift car";
  await ctx.replyWithChatAction("typing").catch(() => {});
  const waitMsg = await ctx.reply(`🔍 <i>YouTube aur Telegram channels se Avee Player (.viz) templates dhoondh rahe hain: "${cleanQ}"...</i> ⏳`, {
    parse_mode: "HTML",
  }).catch(() => null);

  try {
    // 1. YouTube description search
    const ytPromise = execFileAsync("python", ["scripts/search_viz_templates.py", cleanQ], { timeout: 25000 })
      .then((r) => JSON.parse(r.stdout.trim() || "[]"))
      .catch(() => []);

    // 2. Public Telegram channels search
    const tgPromise = searchTelegramChannels(cleanQ);

    const [ytItems, tgItems] = await Promise.all([ytPromise, tgPromise]);

    if (waitMsg && ctx.chat) await ctx.api.deleteMessage(ctx.chat.id, waitMsg.message_id).catch(() => {});

    if (!ytItems.length && !tgItems.length) {
      await ctx.reply(`❌ "${cleanQ}" ke liye koi direct template download links nahi mile. Kripya doosra keyword try karein!`);
      return;
    }

    let text =
      `🔍 <b>Avee Player Templates Search Results:</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `<i>YouTube descriptions aur Telegram channels se nikale gaye direct template links:</i>\n\n`;

    const kb = new InlineKeyboard();

    // Add Telegram channel results first if found
    if (tgItems.length > 0) {
      text += `📢 <b>Telegram Channels Se:</b>\n`;
      for (let i = 0; i < tgItems.length; i++) {
        const it = tgItems[i];
        text += `• <b>${it.title}</b> (${it.channel})\n`;
        text += `  🔗 Post: <a href="${it.url}">Telegram Post</a>\n`;
        if (it.dl_links.length > 0) {
          for (const dl of it.dl_links) {
            text += `  📥 <code>${dl}</code>\n`;
          }
          try {
            new URL(it.dl_links[0]);
            kb.url(`📥 TG Template #${i + 1}`, it.dl_links[0]);
            kb.row();
          } catch {}
        }
      }
      text += `\n`;
    }

    // Add YouTube results
    if (ytItems.length > 0) {
      text += `📺 <b>YouTube Videos Se:</b>\n`;
      for (let i = 0; i < Math.min(ytItems.length, 3); i++) {
        const it = ytItems[i];
        text += `<b>${i + 1}. ${it.title}</b> (${it.channel})\n`;
        text += `🔗 Video: <a href="${it.url}">Watch Video</a>\n`;
        if (it.download_links && it.download_links.length > 0) {
          for (const dl of it.download_links) {
            text += `📥 <code>${dl}</code>\n`;
          }
          try {
            new URL(it.download_links[0]);
            kb.url(`📥 YT Template #${i + 1}`, it.download_links[0]);
            kb.row();
          } catch {}
        }
        text += `\n`;
      }
    }

    text += `💡 <i>Humare built-in vault se ready-made .viz file paane ke liye <code>/viz</code> dabayein!</i>`;

    await ctx.reply(text, {
      parse_mode: "HTML",
      link_preview_options: { is_disabled: true },
      reply_markup: kb,
    });
  } catch (e: any) {
    if (waitMsg && ctx.chat) await ctx.api.deleteMessage(ctx.chat.id, waitMsg.message_id).catch(() => {});
    console.error("searchAndSendOnlineTemplates error:", e?.message ?? e);
    await ctx.reply("❌ Template search mein samay lag gaya. Kripya built-in vault ke liye <code>/viz</code> use karein!", {
      parse_mode: "HTML",
    });
  }
}

/** Register all visualizer commands and callback queries */
export function registerVisualizer(bot: Bot) {
  // Command: /viz or /visualizer or /avee
  bot.command(["viz", "visualizer", "avee", "template", "viztemplate"], async (ctx) => {
    if (!chatAllowed(ctx)) return;
    const match = String(ctx.match ?? "").trim();

    // If no argument, deliver the primary .viz file directly!
    if (!match) {
      const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
      const title = isBoss ? "Supreme Boss — Flagship Avee Player .viz File" : "Phonk FX Vault — Avee Player .viz Preset";
      return sendVizDocument(ctx, VIZ_TEMPLATES[0], title);
    }

    // Check if user said "search <query>"
    if (/^search\s+/i.test(match)) {
      const q = match.replace(/^search\s+/i, "");
      return searchAndSendOnlineTemplates(ctx, q);
    }

    // Search in local vault
    const tmpl = findTemplate(match);
    if (tmpl) {
      return sendVizDocument(ctx, tmpl);
    }

    // Fallback: search online
    return searchAndSendOnlineTemplates(ctx, match);
  });

  // Command: /findviz or /searchviz
  bot.command(["findviz", "searchviz", "vizsearch", "getviz"], async (ctx) => {
    if (!chatAllowed(ctx)) return;
    const q = String(ctx.match ?? "").trim() || "phonk drift car";
    return searchAndSendOnlineTemplates(ctx, q);
  });

  // Callback query: instant download of .viz file
  bot.callbackQuery(/^vizdl:([a-z0-9_]+)$/, async (ctx) => {
    await ctx.answerCallbackQuery({ text: "Avee Player .viz file upload ho rahi hai... ⏳" }).catch(() => {});
    const id = ctx.match[1];
    const tmpl = VIZ_TEMPLATES.find((t) => t.id === id) || VIZ_TEMPLATES[0];
    await sendVizDocument(ctx, tmpl);
  });

  // Callback query: trigger YouTube search
  bot.callbackQuery("viz:ytsearch", async (ctx) => {
    await ctx.answerCallbackQuery().catch(() => {});
    await ctx.reply(
      `🔍 <b>Avee Player YouTube Template Search</b>\n\n` +
        `YouTube descriptions se download links nikaalne ke liye aise likhein:\n` +
        `👉 <code>/findviz drift phonk car</code>\n` +
        `👉 <code>/findviz brazilian phonk</code>\n` +
        `👉 <code>/findviz 360 circle spectrum</code>\n\n` +
        `⚡ <i>Main turant Google Drive aur Mediafire links nikaal kar doongi!</i>`,
      { parse_mode: "HTML" },
    );
  });
}
