import test from "node:test";
import assert from "node:assert/strict";
import { analyzeBotFeatures, formatBotAnalysisCard } from "../src/bot-analyzer.js";

test("analyzeBotFeatures: returns structured report with full features list", async () => {
  const report = await analyzeBotFeatures("Riya89_bot");
  assert.equal(report.username, "Riya89_bot");
  assert.ok(report.features.length >= 6, `Expected at least 6 features, got ${report.features.length}`);
  assert.ok(report.category.length > 0);
  assert.ok(report.features.some((f) => f.includes("AI Chat") || f.includes("Voice") || f.includes("Command")));
});

test("formatBotAnalysisCard: formats rich card with feature list and clone button", async () => {
  const report = await analyzeBotFeatures("MissRose_bot");
  const card = formatBotAnalysisCard(report);
  assert.ok(card.text.includes("COMPLETE FEATURE LIST"));
  assert.ok(card.text.includes("MissRose_bot"));
  assert.ok(card.reply_markup);
});
