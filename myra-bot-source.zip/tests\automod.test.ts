process.env.MYRA_MEM_STORE = "1";
process.env.BOT_TOKEN = "123:TEST";
process.env.OWNER_ID = "1";

import test from "node:test";
import assert from "node:assert/strict";
import { addAbuseWarn, addLinkWarn } from "../src/moderation.js";

test("AutoMod: addAbuseWarn enforces exactly 4 warnings limit", async () => {
  const replies: string[] = [];
  const fakeCtx: any = {
    chat: { id: -100991, type: "supergroup", title: "Test Group" },
    from: { id: 8001, first_name: "Abuser" },
    me: { id: 123 },
    api: {
      sendMessage: async () => {},
    },
    restrictChatMember: async () => {},
    banChatMember: async () => {},
    reply: async (text: string) => {
      replies.push(text);
    },
  };

  // Warning 1, 2, 3
  await addAbuseWarn(fakeCtx, 8001, "Abuser", "Gaali");
  assert.ok(replies[0].includes("1/4"));

  await addAbuseWarn(fakeCtx, 8001, "Abuser", "Gaali");
  assert.ok(replies[1].includes("2/4"));

  await addAbuseWarn(fakeCtx, 8001, "Abuser", "Gaali");
  assert.ok(replies[2].includes("3/4"));

  // Warning 4 (limit reached -> punish)
  await addAbuseWarn(fakeCtx, 8001, "Abuser", "Gaali");
  assert.ok(replies[3].includes("4/4 warnings poori ho gayi"));
});

test("AutoMod: addLinkWarn enforces exactly 10 warnings limit", async () => {
  const replies: string[] = [];
  const fakeCtx: any = {
    chat: { id: -100992, type: "supergroup", title: "Test Group" },
    from: { id: 8002, first_name: "Linker" },
    me: { id: 123 },
    api: {
      sendMessage: async () => {},
    },
    restrictChatMember: async () => {},
    banChatMember: async () => {},
    reply: async (text: string) => {
      replies.push(text);
    },
  };

  for (let i = 1; i <= 9; i++) {
    await addLinkWarn(fakeCtx, 8002, "Linker", "Link Violation");
    assert.ok(replies[i - 1].includes(`${i}/10`));
  }

  // Warning 10 (limit reached -> punish)
  await addLinkWarn(fakeCtx, 8002, "Linker", "Link Violation");
  assert.ok(replies[9].includes("10/10 warnings poori ho gayi"));
});
