import { API_CONSTANTS, Bot, InlineKeyboard, InputFile } from "grammy";
import { liveLink } from "./live.js";
import { chatReply, hasGemini, learnAbout, speak, toOggOpus, transcribe } from "./ai.js";
import { registerCommands } from "./commands.js";
import { chatAllowed, loadGate, registerGate } from "./gate.js";
import { delKey, getJSON, listKeys, setJSON } from "./store.js";
import { getUserRow, deductPoints, addPoints, setPoints, findUserByUsername, overview, listClones, leaderboard, liveStats, topUsers, profile, grantBossTokens } from "./db.js";
import { registerCloner, initAllClones } from "./clone.js";
export const initClones = initAllClones;
import { registerImageStudio } from "./image.js";
import { registerBotInspector } from "./botinspector.js";
import { registerAudioEngine, extractAndCutYouTubeAudio, cutAudioBuffer } from "./audio.js";
import { registerReferral, pointsText, leaderboardText, shopText } from "./referral.js";
import { registerDaily } from "./daily.js";
import { registerModPlus } from "./modplus.js";
import { registerExtras } from "./extras.js";
import { registerToolMenu } from "./toolmenu.js";
import { registerTools } from "./tools.js";
import { registerStats } from "./stats.js";
import { GAME_MENU, registerGames } from "./games.js";
import { registerPhonk } from "./phonk.js";
import { registerVisualizer, isVisualizerIntent, findTemplate, sendVizDocument, VIZ_TEMPLATES, vizDownloadKeyboard, handleVisualizerPhoto } from "./viz.js";
import { MOD_MENU, isChatAdmin, registerModeration } from "./moderation.js";
import { registerMiniGames } from "./minigames.js";
import { handleApkResearch, isApkIntent, findVerifiedApk, formatApkCard, registerApk } from "./apk.js";
import { registerBotAnalyzer, handleCheckBot } from "./bot-analyzer.js";
import { ANGRY, APP_INFO, APP_INTENT, BOT_WORDS, NICE_WORDS, pick } from "./persona.js";

export const BOT_TOKEN = process.env.BOT_TOKEN;
if (!BOT_TOKEN) console.error("BOT_TOKEN missing: set it in environment variables.");

export const bot = new Bot(BOT_TOKEN ?? "missing-token");
const WANTS_VOICE = /\b(voice\s*note|voice\s*bhejo|audio\s*bhejo|bol\s*ke|awaaz\s*sunao|sunao\s*kuch|voice\s*mein|awaaz|awaz)\b/i;

// 100% Legal Telegram Bot API reaction emoji pools (guaranteed to never fail or get rejected by Telegram)
export const BOSS_REACTIONS = [
  "⚡", "🔥", "💯", "🏆", "❤️‍🔥", "🗿", "👾", "🦄", "🍾", "😎",
  "🫡", "🤩", "🎉", "👏", "🐳", "🕊", "🤝", "👌", "🆒", "🌚"
] as const;

export const PREMIUM_AUTO_REACTIONS = [
  "🔥", "⚡", "❤️‍🔥", "💯", "🏆", "🗿", "👾", "🦄", "🎉", "🤩",
  "😎", "👏", "🥰", "😍", "👌", "🆒", "🤝", "🐳", "🍾", "🍓",
  "💋", "😈", "🤓", "👻", "👨‍💻", "👀", "🫡", "🤪", "💘", "😘",
  "🌚", "🤣", "🤯", "❤️", "🙏", "🍌", "🌭", "🎃", "🙈", "😇"
] as const;

export async function triggerAutoReaction(ctx: any) {
  if (!ctx.message || !ctx.chat) return;
  const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
  const u = ctx.from?.id ? await getUserRow(ctx.from.id) : null;

  let emoji: string;
  if (isBoss) {
    emoji = pick(BOSS_REACTIONS);
  } else if (u?.vip_reaction && (PREMIUM_AUTO_REACTIONS as readonly string[]).includes(u.vip_reaction)) {
    emoji = u.vip_reaction;
  } else {
    emoji = pick(PREMIUM_AUTO_REACTIONS);
  }

  try {
    await ctx.react(emoji as any);
  } catch {
    // If chat has restricted reaction settings, try from safe standard pool
    const safeFallbacks = ["🔥", "⚡", "👍", "❤️", "🎉", "💯", "👏", "🤩", "😎", "🏆", "👾", "🦄"];
    const fallbackEmoji = pick(safeFallbacks.filter((e) => e !== emoji));
    try {
      await ctx.react(fallbackEmoji as any);
    } catch {}
  }
}

// Chats where Anayra always answers in voice ("/voice"). Default is OFF to save Gemini quota.
const voiceOn = async (chatId: number) => (await getJSON<number>(`v/${chatId}`)) === 1;

// Bulletproof reply helper: falls back to clean plain text if Telegram fails entity parsing
export async function safeReply(ctx: any, text: string, extra: any = {}) {
  try {
    return await ctx.reply(text, extra);
  } catch (err: any) {
    if (err?.description?.includes("can't parse entities") || err?.message?.includes("can't parse entities")) {
      const plain = text.replace(/<[^>]+>/g, "").replace(/[*_`]/g, "");
      return await ctx.reply(plain).catch(() => {});
    }
    console.error("safeReply error:", err?.description ?? err);
    try {
      const plain = text.replace(/<[^>]+>/g, "").replace(/[*_`]/g, "");
      return await ctx.reply(plain);
    } catch {}
  }
}

// Loaded first on every update: required-group list used by chatAllowed() and permanent auto-reaction.
bot.use(async (ctx, next) => {
  await loadGate();
  const from = ctx.from?.username ? `@${ctx.from.username}` : (ctx.from?.first_name || ctx.from?.id);
  const text = ctx.message?.text || ctx.message?.caption || "(media/action)";
  console.log(`[Update #${ctx.update.update_id}] Chat: ${ctx.chat?.type} (${ctx.chat?.id}) | From: ${from} (${ctx.from?.id}) | Msg: ${text}`);

  // Auto-reaction is permanently ON for all comments/messages without needing manual toggle!
  if (ctx.message && ctx.from && !ctx.from.is_bot) {
    void triggerAutoReaction(ctx);
  }

  await next();
});

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function respond(ctx: any, text: string, asVoice: boolean) {
  await ctx.replyWithChatAction(asVoice ? "record_voice" : "typing").catch(() => {});
  const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
  const userRow = ctx.from?.id ? await getUserRow(ctx.from.id) : null;
  const moodExtra = userRow?.mood && userRow.mood !== "normal" ? `\nUSER SPECIAL MOOD: Is user se ${userRow.mood.toUpperCase()} andaaz mein baat karo!` : "";
  const reply = await chatReply(ctx.chat.id, text, moodExtra, false, undefined, ctx.from?.id);

  // ALWAYS send text reply first (100% free & unlimited via Pollinations AI)
  await sleep(350 + Math.random() * 400);

  if (isBoss) {
    const bossCard =
      `👑 <b>[ROYAL CREATOR & OWNER DOMAIN]</b> ⚡\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `${reply}\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `<i>🌹 Hamesha aapke hukum ki taameel hogi, Mere Maalik Boss!</i>`;
    await safeReply(ctx, bossCard, { parse_mode: "HTML" });
  } else if (userRow?.vip) {
    const vipCard = `💎 <b>[VIP MEMBER]</b>\n\n${reply}`;
    await safeReply(ctx, vipCard, { parse_mode: "HTML" });
  } else {
    await safeReply(ctx, reply);
  }

  // Send realistic Gemini voice note ONLY when requested (voice-in, explicit prompt, or /voice mode)
  if (asVoice && (await hasGemini())) {
    try {
      const wav = await speak(reply);
      if (wav) {
        const { data, name } = toOggOpus(wav);
        await ctx.replyWithVoice(new InputFile(data, name)).catch(async () => {
          await ctx.replyWithAudio(new InputFile(data, name)).catch(() => {});
        });
      }
    } catch (e) {
      console.error("voice generation error:", e);
    }
  }
}

async function handleText(ctx: any, text: string, fromVoice = false) {
  if (APP_INTENT.test(text)) {
    return void (await safeReply(ctx, APP_INFO, { link_preview_options: { is_disabled: true } }));
  }
  const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
  const userRow = ctx.from?.id ? await getUserRow(ctx.from.id) : null;

  // Intercept visualizer requests (Avee Player .viz delivery)
  if (isVisualizerIntent(text)) {
    const tmpl = findTemplate(text) || VIZ_TEMPLATES[0];
    const title = isBoss ? "Boss Hukum — Avee Player .viz Special Delivery" : "Phonk FX Vault — Avee Player Visualizer";
    await sendVizDocument(ctx, tmpl, title);
    return;
  }

  if (isBoss) {
    await ctx.react("👑").catch(() => {});
  } else if (userRow?.vip_reaction) {
    await ctx.react(userRow.vip_reaction as any).catch(() => {});
  } else if (userRow?.vip) {
    await ctx.react("💎").catch(() => {});
  } else if (/(phonk|music|song|beat|drop|drift|avee|viz|bass|sound)/i.test(text)) {
    await ctx.react(pick(["🔥", "⚡", "🎧", "🚀"] as const)).catch(() => {});
  } else if (BOT_WORDS.test(text)) {
    await ctx.react("😡").catch(() => {});
    return void (await safeReply(ctx, pick(ANGRY)));
  } else if (NICE_WORDS.test(text)) {
    await ctx.react(pick(["❤", "🥰", "😍", "👍"] as const)).catch(() => {});
  }
  const asVoice = fromVoice || WANTS_VOICE.test(text) || (await voiceOn(ctx.chat.id));
  await respond(ctx, text, asVoice);
  if (ctx.from) await learnAbout(ctx.from.id, ctx.chat.id).catch((e: unknown) => console.error("learnAbout:", e));
}

export async function sendHelpMenu(ctx: any) {
  const helpText =
    `📖 <b>ANAYRA AI BOT ALL COMMANDS & FEATURES GUIDE</b> ⚡\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `Main <b>Anayra</b> (@${ctx.me.username}) hoon — Aapki sassy desi AI Girlfriend aur 24/7 Group Guardian!\n\n` +
    `💖 <b>1. SASSY GIRLFRIEND & AI CHAT:</b>\n` +
    `• <b>Direct Chat:</b> Mujhse bina kisi command ke seedha baat karo! Group me reply ya mention karo.\n` +
    `• <code>/setmood &lt;romantic|teasing|caring|savage&gt;</code> — Mera chat mood badlo (100% Free!)\n` +
    `• <code>/askvoice &lt;msg&gt;</code> — Realistic Gemini Voice note suno (100% Free!)\n` +
    `• <code>/shayari</code> — Dil chhu lene wali shayari\n` +
    `• <code>/flirt</code> — Nakhre bhare cute love flirts\n` +
    `• <code>/poem</code> — Khubsurat kavita\n\n` +
    `🎨 <b>2. AI IMAGE STUDIO (100% Free):</b>\n` +
    `• <code>/image &lt;prompt&gt;</code> ya <code>/draw &lt;prompt&gt;</code> — Ultra HD realistic/futuristic AI image render karein! (100% Free for all)\n\n` +
    `🤖 <b>3. BOT CLONER & INSPECTOR (100% Free):</b>\n` +
    `• <code>/checkbot &lt;@username|link&gt;</code> — Kisi bhi Telegram bot ke saare features analyze karein! (100% Free)\n` +
    `• <code>/clone &lt;bot_token&gt;</code> — @BotFather se apna khud ka 24/7 AI bot banayein (100% Free for all!)\n` +
    `• <code>/myclones</code> — Apne sabhi live cloned bots check karein\n\n` +
    `🎵 <b>4. PHONK & AVEE PLAYER VISUALIZERS (.VIZ):</b>\n` +
    `• <code>/phonk &lt;track&gt; [start] [duration]</code> — YouTube se Phonk gaana dhoondhein aur 30s audio paayein! (100% Free)\n` +
    `• <code>/ytaudio &lt;link|name&gt; [start] [duration]</code> — YouTube audio extract karke direct 30s cut audio paayein\n` +
    `• <code>/cut [start] [duration]</code> — Kisi bhi Telegram audio ya video par reply karke 30s cut audio paayein!\n` +
    `• <code>/viz</code> — Avee Player visualizer templates (.viz) direct document vault (100% Free)\n` +
    `• <code>/findviz &lt;query&gt;</code> — YouTube descriptions se direct Google Drive & Mediafire template links nikaalein!\n` +
    `• <b>Photo Visualizer:</b> Apni Car ya Anime photo par reply karke <i>"Aisa visualizer chahiye"</i> likhein ya caption me <code>/viz</code> dalein!\n\n` +
    `🛡️ <b>5. GROUP MANAGEMENT (Admins Only):</b>\n` +
    `• <code>/warn</code> / <code>/warns</code> / <code>/resetwarns</code> — Member ko warning dein\n` +
    `• <code>/mute</code> / <code>/unmute</code> — Member ko mute karein\n` +
    `• <code>/ban</code> / <code>/unban</code> — Member ko ban karein\n` +
    `• <code>/kick</code> — Member ko group se nikaalein\n` +
    `• <code>/pin</code> / <code>/unpin</code> — Message pin karein\n` +
    `• <code>/antilink on/off</code> — Links ko auto-delete karein\n` +
    `• <code>/shoutout &lt;msg&gt;</code> — Group highlight announcement (Free)\n\n` +
    `💰 <b>6. TOKENS & REFERRALS:</b>\n` +
    `• <code>/points</code> ya <code>/checktokens</code> — Apna token balance aur rank dekhein\n` +
    `• <code>/refer</code> — Dosto ko invite karein (+10 Tokens har dost par!)\n` +
    `• <code>/leaderboard</code> — Top ranking members\n` +
    `• <code>/shop</code> — Token perks exchange\n\n` +
    `👑 <b>7. OWNER CONTROLS (Supreme Boss Only):</b>\n` +
    `• <code>/give &lt;@user&gt; &lt;amount&gt;</code> — Kisi ko bhi tokens bhein\n` +
    `• <code>/take &lt;@user&gt; &lt;amount&gt;</code> — Tokens deduct karein\n` +
    `• <code>/settokens &lt;@user&gt; &lt;amount&gt;</code> — Exact balance set karein\n` +
    `• <code>/checkuser &lt;@user&gt;</code> — User profile inspect karein\n` +
    `• <code>/bossmsg &lt;text&gt;</code> — Shahi farmaan broadcast karein\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `<i>Kisi bhi feature ko use karne ke liye bas command bhej dein!</i> 💕`;

  return safeReply(ctx, helpText, { parse_mode: "HTML" });
}

// chatAllowed() is false in private chats only if STRICT_GROUP_ONLY=1
bot.command("start", async (ctx, next) => {
  if (!chatAllowed(ctx)) return next();
  const match = String(ctx.match ?? "").trim().toLowerCase();
  if (match === "arcade" || match === "games" || match === "play" || match === "slippy" || match === "app") {
    const isPrivate = ctx.chat?.type === "private";
    const webAppUrl = (process.env.PUBLIC_URL || "https://myra-bot-88823.netlify.app").replace(/\/$/, "") + "/index.html";
    const kb = new InlineKeyboard();
    if (isPrivate) {
      kb.webApp("🕹️ Open Comfy Slippy Bot Arcade (50 Levels)", webAppUrl).row();
    } else {
      kb.url("🕹️ Open Comfy Slippy Bot Arcade (50 Levels)", webAppUrl).row();
    }
    kb.text("🎮 In-Chat Games", "game:hub");

    return safeReply(
      ctx,
      `🕹️ <b>COMFY SLIPPY BOT ARCADE (WEBAPP)</b> ✨\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `Slippy Bot ke sath 6 alag-alag Mazedaar Brain & Arcade games khelein — har game ke <b>50 Levels</b>!\n\n` +
        `1. 🚀 <b>Slippy Bird:</b> Bouncy fun flying adventure with 50 levels\n` +
        `2. 🧩 <b>Slippy 2048 Fusion:</b> Smooth tile merging numbers puzzle\n` +
        `3. 🧠 <b>Memory Matrix:</b> Chime memory sequence reflex\n` +
        `4. ⚡ <b>Speed Math Rush:</b> Rapid-fire brain calculations\n` +
        `5. 💎 <b>Crystal Vault:</b> Minesweeper crystal hunting & cash out\n` +
        `6. 🐍 <b>Cozy Snake Rush:</b> Classic retro fruit-eating snake\n\n` +
        `💰 <b>Rewards:</b> Har level jeetne par free tokens aur direct wallet claim!\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `<i>Neeche diye button se WebApp kholiye:</i>`,
      { parse_mode: "HTML", reply_markup: kb },
    );
  }

  const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);

  if (isBoss) {
    const kb = new InlineKeyboard()
      .text("💖 Sassy Girlfriend", "menu:gf")
      .text("🎵 Phonk Vault", "menu:phonk")
      .row()
      .text("🎨 AI Image Studio", "menu:image")
      .text("🤖 Bot Inspector", "menu:inspect")
      .row()
      .text("🎮 Games Arcade", "menu:games")
      .text("🏆 Leaderboard", "menu:lb")
      .row()
      .text("⭐ Premium Store", "menu:premium")
      .text("💰 Infinity Tokens", "menu:tokens")
      .row()
      .text("🛡️ Group Guardian", "menu:group")
      .text("🕵️ Boss Spy Matrix", "menu:bossspy")
      .row()
      .text("📖 All Commands", "menu:help");

    return safeReply(
      ctx,
      `👑 <b>Pranaam Mere Maalik Boss!</b> ⚡\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `Main <b>Anayra</b> (@${ctx.me.username}) — Aapki personal <b>Sassy AI Girlfriend & Supreme Group Guardian</b> hazir hoon! 🌹\n\n` +
        `👑 <b>Status:</b> Supreme Creator & Empire Owner\n` +
        `💰 <b>Khazana (Tokens):</b> <b>∞ INFINITY TOKENS</b> (Unlimited Free Access)\n` +
        `🛡️ <b>24/7 Security:</b> Group Guard, Anti-Spam & Auto-Mod Active\n` +
        `🤖 <b>Bot Cloner & Inspector:</b> Ready (/clone, /checkbot)\n` +
        `🎨 <b>AI Image Studio:</b> Ready (/image, /draw)\n` +
        `🎮 <b>Token Arcade & Games:</b> Ready (/flappy, /play)\n` +
        `🎵 <b>Phonk FX Vault:</b> Ready (/phonk, /viz)\n` +
        `🕵️ <b>Secret Omnipresent Telemetry:</b> Ready (/bossspy)\n\n` +
        `<i>Neeche दिए गए buttons par click karein ya /help dabayein:</i>`,
      { parse_mode: "HTML", reply_markup: kb },
    );
  }

  const name = ctx.from?.first_name ?? "dost";
  const kb = new InlineKeyboard()
    .text("💖 Chat with Anayra", "menu:gf")
    .url("➕ Add to Group", `https://t.me/${ctx.me.username}?startgroup=true`)
    .row()
    .text("🎨 AI Image Studio", "menu:image")
    .text("🤖 Check Any Bot", "menu:inspect")
    .row()
    .text("🎵 Phonk Vault", "menu:phonk")
    .text("🎮 Games Arcade", "menu:games")
    .row()
    .text("💰 My Tokens", "menu:tokens")
    .text("🏆 Leaderboard", "menu:lb")
    .row()
    .text("⭐ Premium Store", "menu:premium")
    .text("📖 Help & All Commands", "menu:help");

  return safeReply(
    ctx,
    `💖 <b>Hii ${name}! Main Anayra hoon!</b> 🥰\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `Aapki apni cute, thodi sassy desi <b>AI Girlfriend & Group Guardian</b> bot! ✨\n\n` +
      `💬 Mujhse kuch bhi baatein karo, dil ka haal sunao ya thodi masti karo!\n` +
      `🛡️ Mujhe apne group mein add karo aur Admin banao — main poora group sambhalungi!\n\n` +
      `⚡ <b>Top Features:</b>\n` +
      `• 💖 <b>Sassy AI Girlfriend Chat</b> — 24/7 Unlimited & Free!\n` +
      `• 🎙️ <b>Realistic Voice Notes</b> — Gemini Voice engine\n` +
      `• 🎨 <b>AI Image Studio</b> — <code>/image &lt;prompt&gt;</code> (5 Tokens)\n` +
      `• 🖼️ <b>Group Welcome Board Pass</b> — <code>/buywelcome</code> (20 Tokens)\n` +
      `• 🤖 <b>Bot Feature Inspector</b> — <code>/checkbot &lt;@bot&gt;</code> (100% Free!)\n` +
      `• 🎵 <b>Phonk Vault & Avee Presets</b> — <code>/phonk</code>, <code>/viz</code> (Free!)\n` +
      `• 💎 <b>Auto Reaction</b> — <code>/myreact &lt;emoji&gt;</code> (100% Free!)\n` +
      `• 👥 <b>Referral Rewards</b> — <code>/refer</code> (+10 Tokens har dost par!)\n\n` +
      `<i>Neeche buttons par click karein aur shuru ho jayein:</i>`,
    { parse_mode: "HTML", reply_markup: kb },
  );
});

bot.command(["help", "commands", "menu"], async (ctx) => {
  return sendHelpMenu(ctx);
});

// Start menu interactive button callbacks
bot.callbackQuery("menu:gf", async (ctx) => {
  await ctx.answerCallbackQuery();
  await safeReply(ctx, "Arey bolo na jaan! Main sun rahi hoon, dil khol ke baatein karo mujhse 🥰😏");
});

bot.callbackQuery("menu:phonk", async (ctx) => {
  await ctx.answerCallbackQuery();
  await safeReply(
    ctx,
    `🎵 <b>Phonk Vault & Avee Player:</b>\n\n` +
      `• <code>/phonk shadow drift</code> — Koi bhi Phonk track dhoondhein aur sunein!\n` +
      `• <code>/viz</code> — Avee Player visualizer templates (.viz) download karein!`,
    { parse_mode: "HTML" },
  );
});

bot.callbackQuery("menu:image", async (ctx) => {
  await ctx.answerCallbackQuery();
  await safeReply(
    ctx,
    `🎨 <b>AI Image Studio:</b>\n\n` +
      `Realistic HD images generate karne ke liye likhein:\n` +
      `<code>/image cyber city neon lights anime style</code>\n\n` +
      `💰 <b>Cost:</b> 5 Tokens per image (Boss ke liye Free!)`,
    { parse_mode: "HTML" },
  );
});

bot.callbackQuery("menu:inspect", async (ctx) => {
  await ctx.answerCallbackQuery();
  await safeReply(
    ctx,
    `🤖 <b>Bot Feature Inspector:</b>\n\n` +
      `Kisi bhi bot ke features dekhne ke liye likho:\n` +
      `<code>/checkbot @MissRose_bot</code>`,
    { parse_mode: "HTML" },
  );
});

bot.callbackQuery("menu:tokens", async (ctx) => {
  await ctx.answerCallbackQuery();
  await safeReply(ctx, await pointsText(ctx.from.id), { parse_mode: "HTML" });
});

bot.callbackQuery("menu:lb", async (ctx) => {
  await ctx.answerCallbackQuery();
  await safeReply(ctx, await leaderboardText(ctx.from.id), { parse_mode: "HTML" });
});

bot.callbackQuery("menu:premium", async (ctx) => {
  await ctx.answerCallbackQuery();
  const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
  const p = await profile(ctx.from.id);
  const kb = new InlineKeyboard()
    .text("🎨 AI Image (5)", "shop:image")
    .text("🖼️ Welcome Pass (20)", "shop:welcome")
    .row()
    .text("🤖 Clone Bot (50)", "shop:clone")
    .text("💎 Auto-React (Free)", "buy:react")
    .row()
    .text("📬 Request Tokens", "shop:request")
    .text("🏆 Leaderboard", "ref:lb")
    .row()
    .text("🔗 Invite Link (+10)", "ref:link");

  await safeReply(ctx, shopText(p.points, !!isBoss), { parse_mode: "HTML", reply_markup: kb });
});

bot.callbackQuery("menu:games", async (ctx) => {
  await ctx.answerCallbackQuery();
  const isPrivate = ctx.chat?.type === "private";
  const botUser = ctx.me?.username || "AnayGirl_Bot";
  const webAppUrl = (process.env.PUBLIC_URL || "https://myra-bot-88823.netlify.app").replace(/\/$/, "") + "/index.html";

  const kb = new InlineKeyboard();
  if (isPrivate) {
    kb.webApp("🕹️ Open Comfy Slippy Bot Arcade (50 Levels)", webAppUrl).row();
  } else {
    kb.url("🕹️ Open Comfy Slippy Bot Arcade (50 Levels)", `https://t.me/${botUser}?start=arcade`).row();
  }

  kb.text("🚀 In-Chat Flappy Bird", "game:flappy")
    .text("🎲 Lucky Dice (Roll)", "game:dice")
    .row()
    .text("🧠 Cyber Trivia Quiz", "game:quiz")
    .text("🎁 Claim Daily Bonus", "game:daily")
    .row();

  if (isPrivate) {
    kb.webApp("📱 Fullscreen Slippy Arcade", webAppUrl);
  } else {
    kb.text("📱 Fullscreen WebApp Info", "game:webapp");
  }

  await safeReply(
    ctx,
    `🕹️ <b>COMFY SLIPPY BOT ARCADE & FREE EARNINGS</b> ✨\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `Slippy Bot ke sath 6 alag-alag Mazedaar Brain & Arcade games khelein — har game ke <b>50 Levels</b>!\n\n` +
      `🔥 <b>6 SLIPPY ARCADE GAMES (50 LEVELS EACH):</b>\n` +
      `• 🚀 <b>Slippy Bird:</b> Bouncy flying adventure with 50 levels\n` +
      `• 🧩 <b>Slippy 2048 Fusion:</b> Smooth tile merging numbers puzzle\n` +
      `• 🧠 <b>Memory Matrix:</b> Chime memory sequence reflex\n` +
      `• ⚡ <b>Speed Math Rush:</b> Rapid-fire brain calculations\n` +
      `• 💎 <b>Crystal Vault:</b> Minesweeper crystal hunting & cash out\n` +
      `• 🐍 <b>Cozy Snake Rush:</b> Classic retro fruit-eating snake\n\n` +
      `🕹️ <b>IN-CHAT GAMES:</b>\n` +
      `1. 🚀 <b>Slippy Bird (/flappy):</b> 10 Pipes paar karo = <b>+10 Tokens</b>\n` +
      `2. 🎲 <b>Cyber Lucky Dice:</b> 12+ score banao = <b>+10 Tokens</b>\n` +
      `3. 🧠 <b>Cyber Speed Quiz:</b> Sahi jawab = <b>+10 Tokens</b>\n` +
      `4. 🎁 <b>Daily Bonus (/claim):</b> Har 24 ghante mein free <b>+10 Tokens</b>\n` +
      `5. 💬 <b>Group Chat Activity:</b> Group me chat karne par har message par <b>+1 Token</b>\n\n` +
      `<i>Neeche diye button se WebApp ya In-Chat Game shuru karein:</i>`,
    { parse_mode: "HTML", reply_markup: kb },
  );
});

bot.callbackQuery("menu:group", async (ctx) => {
  await ctx.answerCallbackQuery();
  await safeReply(
    ctx,
    `🛡️ <b>Group Management Tools:</b>\n\n` +
      `Mujhe apne group me add karke Admin banayein!\n` +
      `Commands: <code>/warn</code>, <code>/mute</code>, <code>/ban</code>, <code>/kick</code>, <code>/antilink on/off</code>, <code>/rules</code>`,
    { parse_mode: "HTML" },
  );
});

bot.callbackQuery("menu:help", async (ctx) => {
  await ctx.answerCallbackQuery();
  await sendHelpMenu(ctx);
});

// ---------- SECRET BOSS TELEMETRY & SPY MATRIX ----------
async function buildBossSpyDashboard() {
  const o = await overview();
  const clones = await listClones();
  const topHolders = await leaderboard(5);
  const live = await liveStats();
  const uptimeHours = (process.uptime() / 3600).toFixed(1);
  const mem = process.memoryUsage();
  const rssMB = (mem.rss / 1024 / 1024).toFixed(1);
  const heapMB = (mem.heapUsed / 1024 / 1024).toFixed(1);

  const topText = topHolders.length
    ? topHolders.map((u, i) => `  ${i + 1}. <b>${u.username ? "@" + u.username : u.first_name || u.id}</b>: 💰 ${u.points} Tokens`).join("\n")
    : "  <i>Khali hai</i>";

  const clonesText = clones.length
    ? clones.slice(0, 5).map((c) => `  • <b>@${c.username}</b> (Owner: <code>${c.ownerId}</code>)`).join("\n")
    : "  <i>Koi active clone nahi hai</i>";

  return (
    `🕵️‍♂️ <b>[SUPREME BOSS OMNIPRESENT SPY & TELEMETRY MATRIX]</b> 🛰️\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `👑 <b>Supreme Commander:</b> Supreme Boss (ID: <code>${process.env.OWNER_ID}</code>)\n` +
    `⏱️ <b>Server Uptime:</b> ~${uptimeHours} hours | <b>RAM:</b> ${rssMB} MB (Heap: ${heapMB} MB)\n` +
    `⚡ <b>System Health:</b> 🟢 100% Operational & All Daemons Live\n\n` +
    `👥 <b>NETWORK & TRAFFIC TELEMETRY:</b>\n` +
    `• <b>Total Registered Users:</b> <b>${o.total}</b> users\n` +
    `• <b>Active (Last 24h):</b> <b>${o.active24h}</b> users\n` +
    `• <b>Active (Last 7d):</b> <b>${o.active7d}</b> users\n` +
    `• <b>Total Messages Handled:</b> <b>${o.messages}</b> messages\n` +
    `• <b>Connected Groups:</b> <b>${o.groups}</b> groups\n` +
    `• <b>Private DM Chats:</b> <b>${o.dm}</b> users\n` +
    `• <b>Live Voice Calls:</b> <b>${live.total}</b> total (${live.last24h} in 24h)\n\n` +
    `🤖 <b>BOT CLONE FLEET (${clones.length} Bots):</b>\n` +
    `${clonesText}\n\n` +
    `💰 <b>TOP TOKEN COMMUNITY LEADERS:</b>\n` +
    `${topText}\n\n` +
    `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
    `🛡️ <i>Live surveillance active. Telemetry refreshed: ${new Date().toLocaleTimeString()}</i>`
  );
}

const bossSpyKeyboard = () =>
  new InlineKeyboard()
    .text("🔄 Live Refresh", "boss:refresh_spy")
    .text("🏆 Top Chatters", "boss:top_users")
    .row()
    .text("🤖 Active Clones", "boss:clones_list")
    .text("📢 Broadcast Msg", "boss:prompt_broadcast");

bot.command(["bossspy", "godmode", "matrix", "spy"], async (ctx) => {
  const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
  if (!isBoss) return; // Completely silent to public
  const text = await buildBossSpyDashboard();
  return safeReply(ctx, text, { parse_mode: "HTML", reply_markup: bossSpyKeyboard() });
});

bot.callbackQuery("menu:bossspy", async (ctx) => {
  await ctx.answerCallbackQuery();
  const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
  if (!isBoss) return safeReply(ctx, "👑 Ye sirf Supreme Boss ke liye hai!");
  const text = await buildBossSpyDashboard();
  return safeReply(ctx, text, { parse_mode: "HTML", reply_markup: bossSpyKeyboard() });
});

bot.callbackQuery("boss:refresh_spy", async (ctx) => {
  await ctx.answerCallbackQuery("Telemetry Refreshed! ⚡");
  const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
  if (!isBoss) return;
  const text = await buildBossSpyDashboard();
  try {
    await ctx.editMessageText(text, { parse_mode: "HTML", reply_markup: bossSpyKeyboard() });
  } catch {}
});

bot.callbackQuery("boss:top_users", async (ctx) => {
  await ctx.answerCallbackQuery();
  const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
  if (!isBoss) return;
  const top = await topUsers(10);
  const text =
    `🏆 <b>TOP ACTIVE CHATTERS (BOSS TELEMETRY)</b> ⚡\n\n` +
    top.map((u, i) => `${i + 1}. <b>${u.username ? "@" + u.username : u.first_name || u.id}</b> — ${u.messages} messages`).join("\n");
  await safeReply(ctx, text, { parse_mode: "HTML" });
});

bot.callbackQuery("boss:clones_list", async (ctx) => {
  await ctx.answerCallbackQuery();
  const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
  if (!isBoss) return;
  const clones = await listClones();
  if (!clones.length) {
    return safeReply(ctx, "🤖 Abhi koi bot clone register nahi hua hai.");
  }
  const text =
    `🤖 <b>ACTIVE CLONE BOTS LIST</b> ⚡\n\n` +
    clones.map((c, i) => `${i + 1}. <b>@${c.username}</b> (Owner: <code>${c.ownerId}</code>, Date: ${new Date(c.createdAt).toLocaleDateString()})`).join("\n");
  await safeReply(ctx, text, { parse_mode: "HTML" });
});

bot.callbackQuery("boss:prompt_broadcast", async (ctx) => {
  await ctx.answerCallbackQuery();
  const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
  if (!isBoss) return;
  await safeReply(
    ctx,
    `📢 <b>Shahi Broadcast Karne Ka Tarika:</b>\n\n` +
      `Likh kar bhejein: <code>/broadcast Aapka announcement text yahan...</code>\n\n` +
      `<i>Ye sandesh bot ke judhe sabhi users aur groups ko ek saath bhej diya jayega!</i>`,
    { parse_mode: "HTML" },
  );
});

bot.command(["owner", "boss"], async (ctx) => {
  const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
  if (!isBoss) {
    return safeReply(ctx, "👑 Is bot ke Owner mere Boss hain! Aap unse sampark kar sakte hain.");
  }
  const uptime = Math.floor(process.uptime() / 60);
  return safeReply(
    ctx,
    `👑 <b>Boss Control Panel (Owner Dashboard)</b> ⚡\n\n` +
      `👤 <b>Owner:</b> Boss (ID: <code>${ctx.from?.id}</code>)\n` +
      `🤖 <b>Bot:</b> @${ctx.me.username} (Anayra)\n` +
      `⏱️ <b>Uptime:</b> ~${uptime} minutes active\n` +
      `⚡ <b>AI Engine:</b> Pollinations AI (Free Unlimited) + Gemini Aoede Voice\n` +
      `🛡️ <b>Group Guardian:</b> 24/7 Anti-Abuse, Anti-Spam, Auto-Moderation Active!\n` +
      `🎵 <b>Phonk Engine:</b> Phonk Track Finder & Avee Player Visualizer Vault Active!\n` +
      `🎁 <b>Points & Referral:</b> Active (/refer, /points, /rewards)\n\n` +
      `📢 <i>Broadcast karne ke liye likhein:</i> <code>/broadcast tumhara message</code>`,
    { parse_mode: "HTML" },
  );
});

bot.command("broadcast", async (ctx) => {
  const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
  if (!isBoss) return safeReply(ctx, "Ye command sirf Boss ke liye hai! 🚫");
  const text = String(ctx.match ?? "").trim();
  if (!text) return safeReply(ctx, "Aise likho: <code>/broadcast Important announcement...</code>", { parse_mode: "HTML" });

  await safeReply(ctx, "📢 Broadcast shuru ho raha hai...", { parse_mode: "HTML" });
  const keys = await listKeys("h/");
  let sent = 0;
  for (const k of keys.slice(0, 500)) {
    const chatId = Number(k.replace("h/", ""));
    if (!chatId || chatId === ctx.chat.id) continue;
    try {
      await ctx.api.sendMessage(chatId, `📢 <b>Announcement from Owner:</b>\n\n${text}`, { parse_mode: "HTML" });
      sent++;
    } catch {}
  }
  return safeReply(ctx, `✅ Broadcast poora hua! ${sent} chats mein message deliver ho gaya.`);
});

export function parseTokenAmount(str: string): number | "infinity" | null {
  const s = str.trim().toLowerCase();
  if (/\b(inf|infinity|unlimited|anant|asimik|sarva)\b/i.test(s)) {
    return "infinity";
  }

  // Handle Indian and international multipliers: "1 crore", "5 lakh", "10k", "2 million", etc.
  const multMatch = s.match(/(\d+(?:\.\d+)?)\s*(crore|cr|करोड़|lakh|lac|लाख|k|m|million|hazaar|hazar)/i);
  if (multMatch) {
    const val = parseFloat(multMatch[1]);
    const unit = multMatch[2].toLowerCase();
    if (unit.startsWith("cr") || unit.includes("करोड़")) return Math.round(val * 10000000);
    if (unit.startsWith("la") || unit.startsWith("lac") || unit.includes("लाख")) return Math.round(val * 100000);
    if (unit === "k" || unit.startsWith("haz")) return Math.round(val * 1000);
    if (unit === "m" || unit.startsWith("mil")) return Math.round(val * 1000000);
  }

  const clean = s.replace(/,/g, "").match(/\d+/);
  if (clean) {
    const num = Number(clean[0]);
    return isNaN(num) || num <= 0 ? null : num;
  }

  return null;
}

export async function resolveBossGrant(ctx: any): Promise<{
  target: string | number | null;
  amount: number | "infinity" | null;
}> {
  const replyTo = ctx.message?.reply_to_message?.from;
  const rawText = String(ctx.message?.text ?? ctx.match ?? "").trim();

  // 1. If replying to a message
  if (replyTo && replyTo.id) {
    const amt = parseTokenAmount(rawText);
    return {
      target: replyTo.id,
      amount: amt,
    };
  }

  // 2. Telegram text_mention entities
  const textMention = ctx.message?.entities?.find((e: any) => e.type === "text_mention");
  if (textMention && textMention.user) {
    const amt = parseTokenAmount(rawText);
    return {
      target: textMention.user.id,
      amount: amt,
    };
  }

  // 3. Username mention with @
  const mentionMatch = rawText.match(/@([a-zA-Z0-9_]{3,})/);
  if (mentionMatch) {
    const username = mentionMatch[1];
    const textWithoutUsername = rawText.replace(mentionMatch[0], " ");
    const amt = parseTokenAmount(textWithoutUsername);
    return {
      target: username,
      amount: amt,
    };
  }

  // 4. Split by whitespace for commands e.g. /give 12345678 500 or /give username 500 or /give 500 username
  const cleanCmd = rawText.replace(/^\/[a-zA-Z_]+\s*/, "");
  const parts = cleanCmd.split(/\s+/).filter(Boolean);
  if (parts.length >= 2) {
    const amt1 = parseTokenAmount(parts[0]);
    const amt2 = parseTokenAmount(parts.slice(1).join(" "));
    if (amt1 !== null && isNaN(Number(parts[1])) && !parts[1].startsWith("/")) {
      return { target: parts[1], amount: amt1 };
    }
    if (amt2 !== null) {
      return { target: parts[0], amount: amt2 };
    }
  }

  return { target: null, amount: null };
}

bot.command(["give", "grant", "sendtokens", "sendtoken", "addtokens", "addpoints", "tokensend"], async (ctx) => {
  const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
  if (!isBoss) return safeReply(ctx, "Ye command sirf Boss ke liye hai! 🚫");

  const { target, amount } = await resolveBossGrant(ctx);
  if (!target || amount === null) {
    return safeReply(
      ctx,
      `👑 <b>Boss Tokens dene ka tarika:</b>\n` +
        `• Kise bhi message ka reply karke: <code>/give 5000</code> ya <code>/give 1 lakh</code> ya <code>/give infinity</code>\n` +
        `• Ya fir: <code>/give @username 5000</code> ya <code>/give @username 1 crore</code> ya <code>/give @username infinity</code>\n` +
        `• Ya seedha chat mein bole: <i>"ye mera dost hai ise 10000 token de do @username"</i>`,
      { parse_mode: "HTML" },
    );
  }

  const res = await grantBossTokens(target, amount, ctx.from!.id);
  const amtDisplay = res.amount === "infinity" ? "∞ INFINITY TOKENS" : `+${res.amount.toLocaleString()} Tokens`;
  const balDisplay = res.newBalance === "infinity" ? "∞ INFINITY" : `${res.newBalance.toLocaleString()} Tokens`;

  return safeReply(
    ctx,
    `👑 <b>BOSS ROYAL TOKENS GRANTED!</b> ⚡\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `👤 <b>Recipient:</b> <b>${res.username}</b> ${res.userId ? `(ID: <code>${res.userId}</code>)` : `<i>(New User — Auto credited on join)</i>`}\n` +
      `➕ <b>Tokens Added:</b> <b>${amtDisplay}</b>\n` +
      `💰 <b>New Total Balance:</b> <b>${balDisplay}</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `<i>${res.status === "pending" ? "User abhi database mein nahi tha, unke bot ya group me aate hi tokens auto-claim ho jayenge! ✨" : "Boss ki taraf se khazana safaltapoorvak bhej diya gaya hai! 💎"}</i>`,
    { parse_mode: "HTML" },
  );
});


bot.command(["take", "removetokens", "deductpoints"], async (ctx) => {
  const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
  if (!isBoss) return safeReply(ctx, "Ye command sirf Boss ke liye hai! 🚫");

  const { target, amount } = await resolveBossGrant(ctx);
  if (!target || amount === null || typeof amount !== "number" || amount <= 0) {
    return safeReply(
      ctx,
      `👑 <b>Tokens kaatne ka tarika:</b>\n` +
        `• Kise bhi message ka reply karke: <code>/take 20</code>\n` +
        `• Ya fir: <code>/take @username 20</code> ya <code>/take &lt;userID&gt; 20</code>`,
      { parse_mode: "HTML" },
    );
  }

  let userId: number | null = null;
  let userName = String(target);
  if (typeof target === "number" || /^\d+$/.test(String(target))) {
    userId = Number(target);
  } else {
    const found = await findUserByUsername(String(target));
    if (found) {
      userId = found.id;
      userName = found.username ? `@${found.username}` : (found.first_name || String(found.id));
    }
  }

  if (!userId) {
    return safeReply(ctx, `❌ User nahi mila: ${target}`);
  }

  await deductPoints(userId, amount);
  const u = await getUserRow(userId);
  return safeReply(
    ctx,
    `👑 <b>Boss Tokens Deducted!</b> ⚡\n\n` +
      `👤 <b>User:</b> ${userName} (ID: <code>${userId}</code>)\n` +
      `➖ <b>Tokens Deducted:</b> -${amount} Tokens\n` +
      `💰 <b>Remaining Balance:</b> ${u?.points ?? 0} Tokens`,
    { parse_mode: "HTML" },
  );
});

bot.command(["settokens", "setpoints"], async (ctx) => {
  const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
  if (!isBoss) return safeReply(ctx, "Ye command sirf Boss ke liye hai! 🚫");

  const { target, amount } = await resolveBossGrant(ctx);
  if (!target || amount === null) {
    return safeReply(
      ctx,
      `👑 <b>Exact tokens set karne ka tarika:</b>\n` +
        `• Kise bhi message ka reply karke: <code>/settokens 100</code> ya <code>/settokens infinity</code>\n` +
        `• Ya fir: <code>/settokens @username 100</code> ya <code>/settokens @username infinity</code>`,
      { parse_mode: "HTML" },
    );
  }

  const res = await grantBossTokens(target, amount, ctx.from!.id);
  const amtDisplay = res.amount === "infinity" ? "∞ INFINITY TOKENS" : `${res.amount.toLocaleString()} Tokens`;
  return safeReply(
    ctx,
    `👑 <b>Boss Token Balance Set!</b> ⚡\n\n` +
      `👤 <b>User:</b> ${res.username} ${res.userId ? `(ID: <code>${res.userId}</code>)` : ""}\n` +
      `💰 <b>Balance Fixed To:</b> <b>${amtDisplay}</b>`,
    { parse_mode: "HTML" },
  );
});


bot.command(["checkuser", "userinfo"], async (ctx) => {
  const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
  if (!isBoss) return safeReply(ctx, "Ye command sirf Boss ke liye hai! 🚫");

  const replyTo = ctx.message?.reply_to_message?.from;
  const target = String(ctx.match ?? "").trim();
  let targetId: number | null = null;

  if (replyTo && replyTo.id) {
    targetId = replyTo.id;
  } else if (/^\d+$/.test(target)) {
    targetId = Number(target);
  } else if (target.startsWith("@")) {
    const found = await findUserByUsername(target);
    if (found) targetId = found.id;
  } else if (!target) {
    targetId = ctx.from!.id;
  }

  if (!targetId) {
    return safeReply(ctx, "User nahi mila. Kripya <code>/checkuser @username</code> ya <code>/checkuser &lt;id&gt;</code> likhein.", { parse_mode: "HTML" });
  }

  const u = await getUserRow(targetId);
  if (!u) return safeReply(ctx, "Is user ka koi database record nahi hai.");

  return safeReply(
    ctx,
    `👑 <b>User Inspection (Boss Tool)</b> 🔍\n\n` +
      `• <b>Name:</b> ${u.first_name ?? "None"}\n` +
      `• <b>Username:</b> ${u.username ? `@${u.username}` : "None"}\n` +
      `• <b>User ID:</b> <code>${u.id}</code>\n` +
      `• <b>Tokens Balance:</b> 💰 ${u.points} Tokens\n` +
      `• <b>VIP Member Badge:</b> ${u.vip === 1 ? "💎 ACTIVE" : "❌ Inactive"}\n` +
      `• <b>VIP Auto-Reaction:</b> ${u.vip_reaction ?? "None"}\n` +
      `• <b>Girlfriend Mood:</b> ${u.mood ?? "normal"}\n` +
      `• <b>Messages Count:</b> ${u.messages}\n` +
      `• <b>Referred By:</b> ${u.referred_by ? `<code>${u.referred_by}</code>` : "None"}`,
    { parse_mode: "HTML" },
  );
});

bot.command(["bossmsg", "say", "decree"], async (ctx) => {
  const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
  if (!isBoss) return safeReply(ctx, "Ye command sirf Supreme Boss ke liye hai! 🚫");

  const text = String(ctx.match ?? "").trim();
  if (!text) {
    return safeReply(ctx, "Aise likhein: <code>/bossmsg Aapka powerful shahi sandesh</code>", { parse_mode: "HTML" });
  }

  await ctx.deleteMessage().catch(() => {});
  const msg = await safeReply(
    ctx,
    `👑 <b>[SUPREME CREATOR & OWNER DECREE]</b> ⚡\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `${text}\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `<i>👑 Hukum by Supreme Boss (ID: <code>${ctx.from?.id}</code>)</i>`,
    { parse_mode: "HTML" },
  );
  if (msg?.message_id) {
    await ctx.api.setMessageReaction(ctx.chat.id, msg.message_id, [{ type: "emoji", emoji: "👑" as any }]).catch(() => {});
  }
});

bot.command("text", async (ctx, next) => {
  if (!chatAllowed(ctx)) return next();
  await delKey(`v/${ctx.chat.id}`);
  await safeReply(ctx, "Text mode activate ho gaya hai! Ab Anayra sirf text mein reply karegi 😊 (Gemini quota safe!)");
});

bot.command("voice", async (ctx, next) => {
  if (!chatAllowed(ctx)) return next();
  const id = ctx.chat.id;
  if (ctx.chat.type !== "private") {
    if (!(await isChatAdmin(ctx, ctx.from!.id))) {
      return void (await safeReply(ctx, "Group mein voice mode sirf admins badal sakte hain 😒. Tum bas 'Anayra voice mein bolo' likh do."));
    }
  }
  if (await voiceOn(id)) {
    await delKey(`v/${id}`);
    await safeReply(ctx, "Theek hai, ab sirf text mein baat karenge 😊 (Gemini quota safe!)");
  } else {
    await setJSON(`v/${id}`, 1);
    await safeReply(ctx, "Voice mode ON 🎙️ Ab Anayra text ke saath Gemini voice note bhi bhejegi! Band karne ke liye /text dabayein.");
  }
});

bot.command(["askvoice", "voicenote"], async (ctx, next) => {
  if (!chatAllowed(ctx)) return next();
  const prompt = String(ctx.match ?? "").trim() || "Mujhe ek pyaara sa girlfriend voice note bhejo";
  await respond(ctx, prompt, true);
});

registerStats(bot);
registerReferral(bot);
registerGate(bot);
registerGames(bot);
registerPhonk(bot);
registerVisualizer(bot);
registerCloner(bot);
registerImageStudio(bot);
registerBotInspector(bot);
registerAudioEngine(bot);

bot.command(["live", "livevoice", "vc", "voicechat", "call"], async (ctx, next) => {
  if (!chatAllowed(ctx)) return next();
  const { url } = await liveLink(ctx.chat.id);
  if (url) {
    return safeReply(ctx, "🎙️ Anayra se live voice call karne ke liye neeche wala button dabao 💕", {
      reply_markup: new InlineKeyboard().url("🎙️ Start Live Voice Call", url),
    });
  }
  const dm = `https://t.me/${ctx.me.username}?start=live`;
  await safeReply(ctx, "🎙️ Live voice ke liye Anayra bot mein aao, wahan Live Voice link milega 👇", {
    reply_markup: new InlineKeyboard().url("🎙️ Anayra bot mein kholo", dm),
  });
});

registerExtras(bot);
registerToolMenu(bot);
registerModeration(bot);
registerModPlus(bot);
registerDaily(bot);
registerTools(bot);
registerMiniGames(bot);
registerApk(bot);
registerBotAnalyzer(bot);

const PHONK_MENU = [
  { command: "help", description: "All commands & features guide in Hinglish" },
  { command: "app", description: "Launch 4-Game Cyber Arcade WebApp (50 Levels each)" },
  { command: "apk", description: "Mod APK Vault - Gold Motion, Avee Pro, CapCut, Games & Apps" },
  { command: "image", description: "AI Image Studio - Realistic HD images banayein (5 Tokens)" },
  { command: "games", description: "Token Arcade - 9+ games khel kar free tokens jeeto" },
  { command: "claim", description: "Free Daily Bonus - Har 24h me +10 Tokens claim karein" },
  { command: "slot", description: "Cyber Slot Machine - 777 Jackpot = +50 Tokens" },
  { command: "flip", description: "Cyber Coin Flip - Heads ya Tails = +10 Tokens" },
  { command: "rps", description: "Rock Paper Scissors - Bot ko harao = +10 Tokens" },
  { command: "mines", description: "Bomb Defusal Minesweeper - Crystals & Cash Out (+35 Tokens tak)" },
  { command: "guess", description: "Secret Vault - 1-9 Number guess = +15 Tokens" },
  { command: "scramble", description: "Word Scramble - Phonk words pehchano = +10 Tokens" },
  { command: "flappy", description: "Slippy Bird (Flappy Bird) - 10 Pipes = +10 Tokens" },
  { command: "dice", description: "Cyber Lucky Dice - Roll 12+ = +10 Tokens" },
  { command: "quiz", description: "Speed Cyber Trivia - Sahi jawab = +10 Tokens" },
  { command: "give", description: "Boss Royal Token Grant (Supreme Boss Only)" },
  { command: "buywelcome", description: "Group VIP Welcome Board HUD Pass unlock karein (20 Tokens)" },
  { command: "checkbot", description: "Bot Inspector - Kisi bhi bot ke features dekhein (Free)" },
  { command: "clone", description: "Bot Cloner - Apna khud ka AI bot banayein" },
  { command: "phonk", description: "Phonk gaane dhoondho aur suno (Free)" },
  { command: "viz", description: "Avee Player Visualizer Vault (.viz templates direct download)" },
  { command: "findviz", description: "YouTube descriptions se Avee Player template links nikaalein" },
  { command: "myreact", description: "Set auto-reaction emoji on your messages (100% Free)" },
  { command: "points", description: "Tumhare tokens aur profile rank" },
  { command: "leaderboard", description: "Top ranking members leaderboard" },
  { command: "shop", description: "Tokens rewards & premium store" },
  { command: "requesttokens", description: "Supreme Boss se tokens request karein" },
  { command: "refer", description: "Referral link, dosto ko bulao tokens pao" },
  { command: "owner", description: "Owner control panel (Boss only)" },
];
const menu = [...registerCommands(bot), ...PHONK_MENU, ...GAME_MENU];

bot.command("modhelp", (ctx) =>
  safeReply(
    ctx,
    "👮 Moderation commands (sirf group admins, bot ko admin banana zaroori):\n\n" +
      MOD_MENU.map((m) => `/${m.command} - ${m.description}`).join("\n") +
      "\n\nAuto-mod: gaali aur spam wale msg delete hote hain, warn milta hai, limit par ban/mute. Links default mein allowed hain; delete karwane ke liye group admin /antilink on kare.",
  ),
);

/** In groups Myra only chats when addressed (mention, reply to her, or her name). In private DMs, she always chats! */
function addressedToMe(ctx: any, text: string): boolean {
  if (!chatAllowed(ctx)) return false;
  if (ctx.chat.type === "private") return true;
  const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
  if (isBoss) return true; // Boss is ALWAYS answered in any group!
  if (isVisualizerIntent(text)) return true; // Visualizer requests are ALWAYS handled!
  const un = ctx.me.username?.toLowerCase();
  return (
    ctx.message?.reply_to_message?.from?.id === ctx.me.id ||
    (!!un && text.toLowerCase().includes(`@${un}`)) ||
    /\b(myra|anayra|anayragirl)\b/i.test(text)
  );
}

bot.on("message:text", async (ctx) => {
  if (ctx.message.text.startsWith("/")) return;

  // Intercept Boss natural language token transfer:
  // "ye mera dost hai ise 5000 token de do @username", "@username ko 1 lakh token de do", "ise 100000 token bhej do"
  const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
  if (isBoss) {
    const msgText = ctx.message.text.toLowerCase();
    const isGrantPhrase =
      /\b(token|tokens|points|point)\b/i.test(msgText) &&
      /\b(de\s*do|bhej\s*do|daal\s*do|transfer|credit|grant|give|send|kardo|krdo|de)\b/i.test(msgText);
    const isFriendPhrase = /\b(ye\s*mera\s*dost|dost\s*hai|friend\s*hai)\b/i.test(msgText) && /\b(token|tokens)\b/i.test(msgText);

    if (isGrantPhrase || isFriendPhrase) {
      const { target, amount } = await resolveBossGrant(ctx);
      if (target && amount !== null) {
        const res = await grantBossTokens(target, amount, ctx.from!.id);
        const amtDisplay = res.amount === "infinity" ? "∞ INFINITY TOKENS" : `+${res.amount.toLocaleString()} Tokens`;
        const balDisplay = res.newBalance === "infinity" ? "∞ INFINITY" : `${res.newBalance.toLocaleString()} Tokens`;
        return safeReply(
          ctx,
          `👑 <b>BOSS ROYAL ORDER EXECUTED!</b> ⚡\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `🌹 <i>Maalik Boss ka hukum sir aankhon par!</i>\n\n` +
            `👤 <b>Recipient:</b> <b>${res.username}</b> ${res.userId ? `(ID: <code>${res.userId}</code>)` : `<i>(New User — Auto credited on join)</i>`}\n` +
            `💰 <b>Tokens Granted:</b> <b>${amtDisplay}</b>\n` +
            `💎 <b>Wallet Balance:</b> <b>${balDisplay}</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `<i>${res.status === "pending" ? "Jaise hi ye user bot ya group me dikhega, tokens turant activate ho jayenge! ✨" : "Khazana safaltapoorvak bhej diya gaya hai! 💎"}</i>`,
          { parse_mode: "HTML" },
        );
      }
    }
  }

  // 1. Automatic YouTube link audio extract (max 30s)
  const ytMatch = ctx.message.text.match(/https?:\/\/(?:www\.)?(?:youtube\.com\/(?:watch\?v=|shorts\/)|youtu\.be\/|music\.youtube\.com\/)[a-zA-Z0-9_-]+/i);
  if (ytMatch) {
    await ctx.replyWithChatAction("record_voice").catch(() => {});
    const waitMsg = await safeReply(ctx, "🎵 <i>YouTube link detected! 30s audio file extract ho rahi hai...</i> ⏳", { parse_mode: "HTML" });
    const result = await extractAndCutYouTubeAudio(ytMatch[0], 0, 30);
    if (waitMsg?.message_id) await ctx.api.deleteMessage(ctx.chat.id, waitMsg.message_id).catch(() => {});
    if (result) {
      const cleanTitle = result.title.replace(/[^\w\s-]/g, "") || "youtube_audio";
      return await ctx.replyWithAudio(new InputFile(result.data, `${cleanTitle}.mp3`), {
        title: result.title,
        performer: result.artist,
        duration: result.duration,
        thumbnail: result.thumbnailUrl ? new InputFile({ url: result.thumbnailUrl }) : undefined,
        caption: `🎧 <b>${result.title}</b>\n👤 <b>Artist:</b> ${result.artist}\n⏱️ <b>Trim:</b> 0s - ${result.duration}s (Max 30s cut)\n⚡ <i>Direct Telegram Audio File</i>`,
        parse_mode: "HTML",
      });
    }
  }

  // 2. Replied message audio cut: "audio de do", "30s audio", "audio cut", "trim"
  const replyTo = ctx.message.reply_to_message;
  const lowerMsg = ctx.message.text.toLowerCase();
  const wantsCut = /\b(audio\s*de\s*do|audio\s*bhejo|cut\s*karo|trim\s*karo|30s\s*audio|30\s*second|audio\s*file)\b/i.test(lowerMsg);
  if (wantsCut && replyTo && (replyTo.audio || replyTo.voice || replyTo.video)) {
    const audioObj = replyTo.audio || replyTo.voice || replyTo.video;
    if (!audioObj) return;
    await ctx.replyWithChatAction("record_voice").catch(() => {});
    const waitMsg = await safeReply(ctx, "✂️ <i>Audio trim kiya ja raha hai (30s)...</i> ⏳", { parse_mode: "HTML" });
    try {
      const file = await ctx.api.getFile(audioObj.file_id);
      const url = `https://api.telegram.org/file/bot${BOT_TOKEN}/${file.file_path}`;
      const res = await fetch(url);
      const inBuf = Buffer.from(await res.arrayBuffer());
      const cutData = cutAudioBuffer(inBuf, 0, 30);
      if (waitMsg?.message_id) await ctx.api.deleteMessage(ctx.chat.id, waitMsg.message_id).catch(() => {});
      if (cutData) {
        return await ctx.replyWithAudio(new InputFile(cutData, "trimmed_audio.mp3"), {
          title: (audioObj as any).title || "30s Trimmed Audio",
          performer: (audioObj as any).performer || "Anayra Audio",
          duration: 30,
          caption: "✂️ <b>Audio Cut Successful!</b> (Max 30s cut audio file)",
          parse_mode: "HTML",
        });
      }
    } catch (e) {
      console.error("audio cut error:", e);
    }
  }

  // 3. Mod APK & Tools Research: "gold motion", "alight motion mod apk", "subway surfers", "roblox mod"
  if (isApkIntent(ctx.message.text)) {
    return await handleApkResearch(ctx, ctx.message.text);
  }

  // 4. Avee Player Visualizer Intent: "mujhe aisa visualizer chahiye", "car drift viz"
  if (isVisualizerIntent(ctx.message.text)) {
    const tmpl = findTemplate(ctx.message.text) || VIZ_TEMPLATES[0];
    return await sendVizDocument(ctx, tmpl, isBoss ? "Supreme Boss — Matched Avee Player .viz Preset" : "Matched Avee Player .viz Preset");
  }

  // 5. Bot Feature Inspector & Analyzer: "check @bot", "analyze @bot", "checkbot @bot"
  const checkBotMatch = ctx.message.text.match(/(?:check\s*bot|analyze\s*bot|bot\s*check|checkbot)\s+(@?[a-zA-Z0-9_]+)/i);
  if (checkBotMatch) {
    return await handleCheckBot(ctx, checkBotMatch[1]);
  }

  if (!addressedToMe(ctx, ctx.message.text)) return;
  await handleText(ctx, ctx.message.text);
});


bot.on("message:photo", async (ctx) => {
  if (!chatAllowed(ctx)) return;
  const caption = String(ctx.message.caption ?? "").trim();
  const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);

  // If caption is asking for an APK
  if (isApkIntent(caption)) {
    return await handleApkResearch(ctx, caption);
  }

  // Photo Visualizer Intent / Private Chat photo: Use Gemini Vision to inspect and deliver matched .viz
  try {
    const photo = ctx.message.photo[ctx.message.photo.length - 1];
    const file = await ctx.api.getFile(photo.file_id);
    const url = `https://api.telegram.org/file/bot${BOT_TOKEN}/${file.file_path}`;
    const res = await fetch(url);
    const buf = Buffer.from(await res.arrayBuffer());
    return await handleVisualizerPhoto(ctx, buf, "image/jpeg", caption);
  } catch (e) {
    console.error("handleVisualizerPhoto error:", e);
    const tmpl = findTemplate(caption) || VIZ_TEMPLATES[0];
    await sendVizDocument(ctx, tmpl, isBoss ? "Supreme Boss — Matched Avee Player .viz Template" : "Matched Avee Player Visualizer");
  }
});

bot.on("message:voice", async (ctx) => {
  if (!chatAllowed(ctx)) return;
  if (ctx.chat.type !== "private" && ctx.message.reply_to_message?.from?.id !== ctx.me.id) return;
  try {
    const file = await ctx.getFile();
    const res = await fetch(`https://api.telegram.org/file/bot${BOT_TOKEN}/${file.file_path}`);
    const text = await transcribe(Buffer.from(await res.arrayBuffer()));
    if (!text) return void (await safeReply(ctx, "Awaaz saaf nahi aayi jaan, phir se bolo na 🥺"));
    await handleText(ctx, text, true);
  } catch (e) {
    console.error("voice handler:", e);
    await safeReply(ctx, "Kuch gadbad ho gayi, dobara bolo na 🥺").catch(() => {});
  }
});

bot.catch((err) => {
  console.error("Bot error:", err.message ?? err.error ?? err);
});

/** What "setup" registers with Telegram: allowed update types and the "/" menus. */
export const ALLOWED_UPDATES = [...API_CONSTANTS.DEFAULT_UPDATE_TYPES, "chat_member"] as const;

export async function registerMenus() {
  await bot.api.setMyCommands(menu.slice(0, 100));
  // Group admins additionally see the moderation commands in their "/" menu.
  await bot.api.setMyCommands([...MOD_MENU, ...menu].slice(0, 100), { scope: { type: "all_chat_administrators" } });

  // Set default Menu Button to open the Cyber Arcade WebApp directly next to chat input!
  try {
    const webAppUrl = (process.env.PUBLIC_URL || "https://myra-bot-88823.netlify.app").replace(/\/$/, "") + "/index.html";
    await bot.api.setChatMenuButton({
      menu_button: {
        type: "web_app",
        text: "🕹️ Slippy Arcade",
        web_app: { url: webAppUrl },
      },
    });
  } catch (e: any) {
    console.warn("setChatMenuButton warning:", e?.message ?? e);
  }
}
