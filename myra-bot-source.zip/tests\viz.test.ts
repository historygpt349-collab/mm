import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { VIZ_TEMPLATES, findTemplate, isVisualizerIntent, getVizAssetsDir } from "../src/viz.js";

test("VIZ_TEMPLATES: all 7 templates exist on disk with valid file size", () => {
  assert.equal(VIZ_TEMPLATES.length, 7);
  const dir = getVizAssetsDir();
  for (const t of VIZ_TEMPLATES) {
    const p = path.join(dir, t.filename);
    assert.ok(fs.existsSync(p), `File ${t.filename} must exist in ${dir}`);
    const stat = fs.statSync(p);
    assert.ok(stat.size > 500, `File ${t.filename} should be larger than 500 bytes (got ${stat.size})`);
  }
});

test("findTemplate: matches IDs and context keywords", () => {
  assert.equal(findTemplate("drift")?.id, "drift_neon_rgb");
  assert.equal(findTemplate("car")?.id, "cyberpunk_car_bass");
  assert.equal(findTemplate("brazilian")?.id, "brazilian_hyper_drop");
  assert.equal(findTemplate("vhs")?.id, "vhs_retro_drift");
  assert.equal(findTemplate("circle")?.id, "circle_audio_orbit");
  assert.equal(findTemplate("skull")?.id, "memphis_skull_pulse");
  assert.equal(findTemplate("wave")?.id, "wave_horizon_neon");
  assert.equal(findTemplate("cyberpunk")?.id, "cyberpunk_car_bass");
});

test("isVisualizerIntent: accurately identifies user requests in Hindi & English", () => {
  assert.ok(isVisualizerIntent("/viz"));
  assert.ok(isVisualizerIntent("mujhe visualizer chahiye"));
  assert.ok(isVisualizerIntent("मुझे ऐसा ही विज़ुअलाइज़र चाहिए"));
  assert.ok(isVisualizerIntent("Avee Player template do"));
  assert.ok(isVisualizerIntent("aisa visualizer"));
  assert.ok(isVisualizerIntent("viz file bhejo"));
  assert.ok(!isVisualizerIntent("kya haal hai kaise ho"));
});
