import { Bot, InputFile } from "grammy";
import { oneShot } from "./ai.js";
import { safeReply } from "./bot.js";

/** Extract clean bot username from @username, link, or plain text */
export function extractBotUsername(input: string): string | null {
  const clean = input.trim();
  const match = clean.match(/(?:https?:\/\/)?(?:t\.me\/|telegram\.me\/)?@?([a-zA-Z0-9_]{3,32}(?:bot|_bot))/i);
  if (match) return match[1].replace(/^@/, "");
  const fallback = clean.replace(/^@/, "").replace(/^https?:\/\/t\.me\//, "").split(/[\/\s]/)[0];
  if (/^[a-zA-Z0-9_]{3,32}$/i.test(fallback)) return fallback;
  return null;
}

/** Fetch public metadata from Telegram t.me page */
export async function fetchTelegramBotPage(username: string): Promise<{ title: string; desc: string; image: string | null } | null> {
  try {
    const res = await fetch(`https://t.me/${username}`, {
      headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" },
      signal: AbortSignal.timeout(10000),
    });
    if (!res.ok) return null;
    const html = await res.text();

    const titleMatch = html.match(/<meta\s+property=["']og:title["']\s+content=["'](.*?)["']/i);
    const descMatch = html.match(/<meta\s+property=["']og:description["']\s+content=["'](.*?)["']/i);
    const imgMatch = html.match(/<meta\s+property=["']og:image["']\s+content=["'](.*?)["']/i);

    const title = titleMatch ? titleMatch[1].replace(/Telegram:\s*Contact\s*/i, "").trim() : `@${username}`;
    const desc = descMatch ? descMatch[1].trim() : "Description uplabdh nahi hai.";
    const image = imgMatch ? imgMatch[1] : null;

    return { title, desc, image };
  } catch {
    return null;
  }
}

export function registerBotInspector(bot: Bot) {
  bot.command(["checkbot", "inspectbot", "botfeature", "botinfo"], async (ctx) => {
    const isBoss = ctx.from?.id && process.env.OWNER_ID && String(ctx.from.id) === String(process.env.OWNER_ID);
    const input = String(ctx.match ?? "").trim();

    if (!input) {
      return safeReply(
        ctx,
        `🤖 <b>Bot Feature Inspector & Analyzer</b> 🔍\n\n` +
          `Aap kisi bhi Telegram bot ka link ya username daal kar uske saare features analyze kar sakte hain!\n\n` +
          `👉 <b>Aise likho:</b>\n` +
          `<code>/checkbot @MissRose_bot</code>\n` +
          `<code>/checkbot https://t.me/GroupHelpBot</code>\n\n` +
          `⚡ <i>Anayra us bot ke features, commands aur strengths ko analyze karke poori report samne pesh karegi!</i>`,
        { parse_mode: "HTML" },
      );
    }

    const username = extractBotUsername(input);
    if (!username) {
      return safeReply(ctx, "❌ Sahi bot username ya link dalein, jaise: <code>/checkbot @MissRose_bot</code>", { parse_mode: "HTML" });
    }

    await ctx.replyWithChatAction("typing").catch(() => {});
    const waitMsg = await safeReply(ctx, `🔍 <i>@${username} ko scan kiya ja raha hai, features analyze ho rahe hain...</i> ⏳`, { parse_mode: "HTML" });

    const info = await fetchTelegramBotPage(username);
    const botTitle = info?.title || `@${username}`;
    const botDesc = info?.desc || "No public description found.";

    const prompt =
      `Analyze this Telegram bot for our Bot Creator Boss:\n` +
      `Bot Username: @${username}\n` +
      `Bot Title: ${botTitle}\n` +
      `Description/Bio: ${botDesc}\n\n` +
      `Task:\n` +
      `1. Category & Purpose (ye bot kis cheez ke liye mashhoor hai)\n` +
      `2. Top Features & Tools (Moderation, Anti-Spam, Economy, Games, Captcha, Utility)\n` +
      `3. Unique Strengths (is bot ki sabse badi taqat kya hai)\n` +
      `4. What Boss should copy/add into Anayra (Anayra ko aur tagda banane ke liye hum isme se kya implement kar sakte hain)\n\n` +
      `Language: Clear, smart, respectful Roman HINGLISH. Format with clean emojis and neat headings.`;

    const analysis = await oneShot(
      prompt,
      `• <b>Category:</b> Group Management & Utility\n• <b>Key Features:</b> Auto-mod, Filters, Welcome Cards, Admin Tools\n• <b>Boss ke liye Recommendation:</b> Iske custom welcome and filter rules Anayra me jod sakte hain!`,
    );

    if (waitMsg?.message_id) {
      await ctx.api.deleteMessage(ctx.chat.id, waitMsg.message_id).catch(() => {});
    }

    const dossier =
      `🤖 <b>BOT FEATURE ANALYSIS DOSSIER</b> 🔍\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `🏷️ <b>Target Bot:</b> ${botTitle} (<code>@${username}</code>)\n` +
      `📝 <b>Public Bio:</b> <i>"${botDesc.slice(0, 200)}"</i>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `${analysis}\n\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `👑 <i>Analysis compiled for Boss & Creators by Anayra AI</i>`;

    return safeReply(ctx, dossier, { parse_mode: "HTML" });
  });
}
