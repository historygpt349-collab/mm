import os
import json
import zipfile

ASSETS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "viz")
os.makedirs(ASSETS_DIR, exist_ok=True)

TEMPLATES = [
    {
        "id": "drift_neon_rgb",
        "filename": "drift_neon_rgb.viz",
        "name": "🏎️ Drift Monster Neon RGB",
        "style": "Drift Phonk / Aggressive",
        "bpm": "150-165 BPM",
        "vibe": "Best for JDM, Drift Cars, RX-7, Supra, R34, GTR Wallpapers",
        "features": "Dynamic Camera Shake on 808s, Neon Underglow, Audio-Reactive Smoke & Sparks",
        "scene": {
            "fileFormatVersion": 1,
            "appVersion": "1.2.160",
            "scene": {
                "name": "Drift Monster Neon RGB (Phonk Edition)",
                "author": "Anayra Phonk Vault & Boss",
                "background": {
                    "color": [0.03, 0.03, 0.05, 1.0],
                    "clearColor": True
                },
                "camera": {
                    "fov": 60.0,
                    "position": [0.0, 0.0, -10.0],
                    "target": [0.0, 0.0, 0.0]
                },
                "layers": [
                    {
                        "$type": "AudioProviderLayer",
                        "name": "AudioReactor",
                        "enabled": True,
                        "audioRange": [20, 20000],
                        "fftSize": 1024,
                        "smoothing": 0.75,
                        "bassMultiplier": 2.2
                    },
                    {
                        "$type": "GraphBarLayer",
                        "name": "SpectrumBars",
                        "enabled": True,
                        "blendMode": "Screen",
                        "barCount": 64,
                        "transform": {
                            "position": [0.0, -2.2, 0.0],
                            "scale": [1.4, 1.2, 1.0],
                            "rotation": 0.0
                        },
                        "appearance": {
                            "colorType": "Gradient",
                            "colorGradient": [
                                {"pos": 0.0, "color": "#00ffff"},
                                {"pos": 0.5, "color": "#7928ca"},
                                {"pos": 1.0, "color": "#ff007f"}
                            ],
                            "thickness": 6.0
                        },
                        "behavior": {
                            "reactionType": "Bass",
                            "multiplier": 1.8,
                            "smoothing": 0.72
                        }
                    },
                    {
                        "$type": "ImageLayer",
                        "name": "CarArtwork",
                        "enabled": True,
                        "imagePath": "internal://artwork",
                        "transform": {
                            "position": [0.0, 0.2, 0.0],
                            "scale": [1.0, 1.0, 1.0]
                        },
                        "audioShake": {
                            "enabled": True,
                            "frequencyRange": [40, 90],
                            "intensity": 1.85,
                            "shakeAxes": ["x", "y"]
                        }
                    },
                    {
                        "$type": "ParticleLayer",
                        "name": "NeonSparksAndSmoke",
                        "enabled": True,
                        "particleCount": 140,
                        "speed": 1.8,
                        "direction": [0.0, 1.0],
                        "spread": 45.0,
                        "color": "#00f0ff",
                        "audioReactiveRate": 2.5
                    },
                    {
                        "$type": "EffectLayer",
                        "name": "RgbSplitGlitch",
                        "enabled": True,
                        "effectType": "ChromaticAberration",
                        "intensity": 0.85,
                        "trigger": "BassTransient"
                    },
                    {
                        "$type": "TextLayer",
                        "name": "TrackInfo",
                        "enabled": True,
                        "text": "{Artist} - {Title}",
                        "fontSize": 24,
                        "position": [0.0, -3.2, 0.0],
                        "color": "#ffffff"
                    }
                ]
            }
        }
    },
    {
        "id": "brazilian_hyper_drop",
        "filename": "brazilian_hyper_drop.viz",
        "name": "⚡ Brazilian Phonk Hyper-Drop",
        "style": "Brazilian Funk / Montagem",
        "bpm": "130-145 BPM",
        "vibe": "Best for Cyberpunk, Anime Edits, High Intensity Drops",
        "features": "Screen Glitch, Hard Drop Distortion, Strobe Flash on heavy Kicks, Chromatic Aberration",
        "scene": {
            "fileFormatVersion": 1,
            "appVersion": "1.2.160",
            "scene": {
                "name": "Brazilian Phonk Hyper-Drop",
                "author": "Anayra Phonk Vault & Boss",
                "background": {
                    "color": [0.02, 0.01, 0.04, 1.0],
                    "clearColor": True
                },
                "layers": [
                    {
                        "$type": "AudioProviderLayer",
                        "name": "AudioReactor",
                        "enabled": True,
                        "audioRange": [30, 16000],
                        "fftSize": 512,
                        "smoothing": 0.65,
                        "bassMultiplier": 3.0
                    },
                    {
                        "$type": "GraphBarLayer",
                        "name": "StrobeSpectrum",
                        "enabled": True,
                        "barCount": 48,
                        "transform": {
                            "position": [0.0, -1.8, 0.0],
                            "scale": [1.5, 1.6, 1.0]
                        },
                        "appearance": {
                            "colorGradient": [
                                {"pos": 0.0, "color": "#a855f7"},
                                {"pos": 1.0, "color": "#22c55e"}
                            ],
                            "thickness": 8.0
                        },
                        "behavior": {
                            "reactionType": "HardKick",
                            "multiplier": 2.4
                        }
                    },
                    {
                        "$type": "ImageLayer",
                        "name": "HeavyPunchImage",
                        "enabled": True,
                        "audioShake": {
                            "enabled": True,
                            "frequencyRange": [50, 100],
                            "intensity": 2.6
                        }
                    },
                    {
                        "$type": "EffectLayer",
                        "name": "StrobeAndGlitch",
                        "enabled": True,
                        "effectType": "ScreenGlitchDistortion",
                        "intensity": 1.5,
                        "trigger": "HardDrop"
                    }
                ]
            }
        }
    },
    {
        "id": "vhs_retro_drift",
        "filename": "vhs_retro_drift.viz",
        "name": "📼 90s Retro VHS Driftline",
        "style": "Memphis / Wave Phonk",
        "bpm": "135-155 BPM",
        "vibe": "Best for Tokyo Night Drives, Low-fi Phonk, Vintage Street Racing",
        "features": "CRT Scanlines, Analog Glitch, Horizontal Audio Waves, Muted Vignette",
        "scene": {
            "fileFormatVersion": 1,
            "appVersion": "1.2.160",
            "scene": {
                "name": "90s Retro VHS Driftline",
                "author": "Anayra Phonk Vault & Boss",
                "background": {
                    "color": [0.04, 0.04, 0.05, 1.0]
                },
                "layers": [
                    {
                        "$type": "AudioProviderLayer",
                        "name": "AnalogAudio",
                        "fftSize": 512,
                        "smoothing": 0.8
                    },
                    {
                        "$type": "WaveformLayer",
                        "name": "AnalogHorizontalWave",
                        "enabled": True,
                        "waveType": "LinearOscilloscope",
                        "transform": {
                            "position": [0.0, -2.5, 0.0],
                            "scale": [2.0, 0.8, 1.0]
                        },
                        "color": "#facc15"
                    },
                    {
                        "$type": "EffectLayer",
                        "name": "CRTScanlines",
                        "enabled": True,
                        "scanlineCount": 240,
                        "scanlineSpeed": 0.5,
                        "vignette": 0.75
                    },
                    {
                        "$type": "ParticleLayer",
                        "name": "TapeNoise",
                        "particleCount": 80,
                        "color": "#ffffff"
                    }
                ]
            }
        }
    },
    {
        "id": "circle_audio_orbit",
        "filename": "circle_audio_orbit.viz",
        "name": "🌌 360° Circular Audio Orbit",
        "style": "All Phonk Subgenres / Branding",
        "bpm": "140-160 BPM",
        "vibe": "Best for Phonk FX Vault Branding, Producer Logos, Dark Trap",
        "features": "Circular Bar Equalizer, Center Logo/Emblem Pulsing, Reactive Starfield Particles",
        "scene": {
            "fileFormatVersion": 1,
            "appVersion": "1.2.160",
            "scene": {
                "name": "360° Circular Audio Orbit",
                "author": "Anayra Phonk Vault & Boss",
                "layers": [
                    {
                        "$type": "AudioProviderLayer",
                        "fftSize": 1024,
                        "smoothing": 0.7
                    },
                    {
                        "$type": "RoundBarLayer",
                        "name": "CircularSpectrumBars",
                        "enabled": True,
                        "barCount": 120,
                        "radius": 1.8,
                        "colorGradient": [
                            {"pos": 0.0, "color": "#38bdf8"},
                            {"pos": 1.0, "color": "#ec4899"}
                        ]
                    },
                    {
                        "$type": "ImageLayer",
                        "name": "CenterCircularLogo",
                        "mask": "Circle",
                        "audioPulse": {
                            "frequencyRange": [40, 80],
                            "scalePunch": 1.3
                        }
                    },
                    {
                        "$type": "ParticleLayer",
                        "name": "StarfieldOutward",
                        "direction": "Radial",
                        "speed": 2.0,
                        "particleCount": 150
                    }
                ]
            }
        }
    },
    {
        "id": "memphis_skull_pulse",
        "filename": "memphis_skull_pulse.viz",
        "name": "💀 Memphis Dark Skull Pulser",
        "style": "Raw Memphis Rap / Cowbell Phonk",
        "bpm": "145-160 BPM",
        "vibe": "Best for Dark Aesthetic, Horrorcore, Grim Phonk Edits",
        "features": "Skull/Demon Vibration on Kicks, Red Glow Bloom, Dust Particles",
        "scene": {
            "fileFormatVersion": 1,
            "appVersion": "1.2.160",
            "scene": {
                "name": "Memphis Dark Skull Pulser",
                "author": "Anayra Phonk Vault & Boss",
                "background": {
                    "color": [0.05, 0.0, 0.01, 1.0]
                },
                "layers": [
                    {
                        "$type": "AudioProviderLayer",
                        "subBassRange": [30, 90],
                        "cowbellTransientSense": True
                    },
                    {
                        "$type": "ImageLayer",
                        "name": "SkullDemonArt",
                        "audioShake": {
                            "intensity": 2.2,
                            "trigger": "CowbellAttack"
                        }
                    },
                    {
                        "$type": "GraphBarLayer",
                        "name": "JaggedSpikes",
                        "barCount": 50,
                        "color": "#ef4444"
                    },
                    {
                        "$type": "EffectLayer",
                        "name": "BloodRedBloom",
                        "bloomIntensity": 2.2,
                        "color": "#dc2626"
                    }
                ]
            }
        }
    },
    {
        "id": "wave_horizon_neon",
        "filename": "wave_horizon_neon.viz",
        "name": "🌊 Wave Phonk Neon Horizon",
        "style": "Atmospheric Wave Phonk",
        "bpm": "120-140 BPM",
        "vibe": "Best for Chill Phonk, Night Drive, Aesthetic Synthwave",
        "features": "Flowing 3D Grid Terrain, Smooth Ribbon Waveform, Ambient Color Shift",
        "scene": {
            "fileFormatVersion": 1,
            "appVersion": "1.2.160",
            "scene": {
                "name": "Wave Phonk Neon Horizon",
                "author": "Anayra Phonk Vault & Boss",
                "layers": [
                    {
                        "$type": "AudioProviderLayer",
                        "smoothing": 0.88
                    },
                    {
                        "$type": "GridTerrainLayer",
                        "name": "3DHorizonGrid",
                        "wireframeColor": "#06b6d4",
                        "speed": 1.2
                    },
                    {
                        "$type": "RibbonWaveLayer",
                        "name": "SmoothWaveform",
                        "colorGradient": [
                            {"pos": 0.0, "color": "#06b6d4"},
                            {"pos": 0.5, "color": "#8b5cf6"},
                            {"pos": 1.0, "color": "#f43f5e"}
                        ]
                    }
                ]
            }
        }
    },
    {
        "id": "cyberpunk_car_bass",
        "filename": "cyberpunk_car_bass.viz",
        "name": "🏎️ Cyberpunk JDM Bass Machine",
        "style": "High-tech Phonk / Speed Drift",
        "bpm": "155-170 BPM",
        "vibe": "Best for Supercars, Lambo, Porsche, Koenigsegg, Night Highway Drifts",
        "features": "Speedometer Tachometer dual arc meters, Supercar HUD overlay, Neon boost glow",
        "scene": {
            "fileFormatVersion": 1,
            "appVersion": "1.2.160",
            "scene": {
                "name": "Cyberpunk JDM Bass Machine",
                "author": "Anayra Phonk Vault & Boss",
                "layers": [
                    {
                        "$type": "AudioProviderLayer",
                        "fftSize": 1024,
                        "bassMultiplier": 2.5
                    },
                    {
                        "$type": "GaugeMeterLayer",
                        "name": "TachometerBars",
                        "meterType": "TwinArcMeters",
                        "color": "#38bdf8"
                    },
                    {
                        "$type": "ImageLayer",
                        "name": "SupercarHUD",
                        "audioShake": {
                            "intensity": 1.9
                        }
                    },
                    {
                        "$type": "ParticleLayer",
                        "name": "WarpSpeedLines",
                        "speed": 3.0,
                        "color": "#38bdf8"
                    }
                ]
            }
        }
    }
]

def build_viz_package(tmpl):
    out_path = os.path.join(ASSETS_DIR, tmpl["filename"])
    
    scene_json = json.dumps(tmpl["scene"], indent=2)
    comp_json = json.dumps({
        "composition": {
            "name": tmpl["name"],
            "version": 1,
            "author": "Anayra Phonk Vault & Boss",
            "style": tmpl["style"],
            "bpm": tmpl["bpm"],
            "elements": tmpl["scene"]["scene"]["layers"]
        }
    }, indent=2)
    
    manifest_json = json.dumps({
        "id": tmpl["id"],
        "title": tmpl["name"],
        "style": tmpl["style"],
        "bpm": tmpl["bpm"],
        "vibe": tmpl["vibe"],
        "features": tmpl["features"],
        "author": "Anayra Phonk Vault",
        "extension": "viz",
        "version": "1.0.0"
    }, indent=2)
    
    readme_txt = f"""=== Avee Player Template: {tmpl['name']} ===
Style: {tmpl['style']} ({tmpl['bpm']})
Vibe: {tmpl['vibe']}
Key Features: {tmpl['features']}

--- KAISE USE KAREIN (IMPORT IN AVEE PLAYER) ---
1. Apne phone ya PC mein Avee Player app kholein.
2. Top-right corner mein Visualizer icon (bars/pencil) par click karein.
3. 'Load from file' option dabayein aur ye '{tmpl['filename']}' select karein.
4. Visualizer load ho jayega!
5. Image layer mein jakar apni Car/Anime/Custom photo lagayein.
6. Export: 1080p 60fps, Bitrate: 15 Mbps for supreme YouTube/Reels quality!

Delivered with love by Anayra AI Bot & Supreme Boss!
"""

    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("scene.json", scene_json)
        zf.writestr("composition.json", comp_json)
        zf.writestr("manifest.json", manifest_json)
        zf.writestr("README.txt", readme_txt)
        
    print(f"Generated: {tmpl['filename']} ({os.path.getsize(out_path)} bytes)")

if __name__ == "__main__":
    for t in TEMPLATES:
        build_viz_package(t)
    print("All .viz templates successfully generated!")
