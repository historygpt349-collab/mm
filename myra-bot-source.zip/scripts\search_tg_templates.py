import sys
import json
import re
import urllib.request

CHANNELS = [
    "phonksong777",
    "fb_aveeplayer01",
    "aveeplayertemplates",
    "Avee_Player_Template_Official"
]

def search_telegram_channels(query="phonk"):
    q_words = [w.lower() for w in query.split() if len(w) > 2]
    results = []

    for chan in CHANNELS:
        url = f"https://t.me/s/{chan}"
        req = urllib.request.Request(
            url, 
            headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
        )
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                html = resp.read().decode("utf-8", errors="ignore")
                
                # Split into messages
                messages = html.split('<div class="tgme_widget_message_wrap')
                for msg in messages[1:]:
                    # Extract post link
                    post_link_m = re.search(r'data-post="([^"]+)"', msg)
                    post_id = post_link_m.group(1) if post_link_m else None
                    post_url = f"https://t.me/{post_id}" if post_id else f"https://t.me/{chan}"
                    
                    # Extract text content
                    text_m = re.search(r'<div class="tgme_widget_message_text[^"]*"[^>]*>(.*?)</div>', msg, re.DOTALL)
                    msg_text = re.sub(r'<[^>]+>', ' ', text_m.group(1)).strip() if text_m else ""
                    
                    # Check if relevant
                    text_lower = msg_text.lower()
                    if any(w in text_lower for w in q_words) or "template" in text_lower or "viz" in text_lower:
                        # Extract links
                        raw_urls = re.findall(r'(https?://[^\s"\'<>]+)', msg)
                        dl_links = []
                        for u in raw_urls:
                            u_clean = u.rstrip(".,)]\"'")
                            u_l = u_clean.lower()
                            if any(k in u_l for k in ["drive.google", "mediafire", "mega.nz", ".viz", ".zip", "t.me/"]):
                                if u_clean not in dl_links and u_clean != post_url:
                                    dl_links.append(u_clean)
                                    
                        title = msg_text[:80].replace("\n", " ").strip() or f"Avee Player Template from @{chan}"
                        results.append({
                            "source": "Telegram Channel",
                            "channel": f"@{chan}",
                            "title": title,
                            "post_url": post_url,
                            "download_links": dl_links[:3]
                        })
                        if len(results) >= 5:
                            break
        except Exception:
            continue
            
    print(json.dumps(results[:5]))

if __name__ == "__main__":
    q = "phonk"
    if len(sys.argv) > 1:
        q = " ".join(sys.argv[1:])
    search_telegram_channels(q)
